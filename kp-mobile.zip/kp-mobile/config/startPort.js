/**
 * http://usejsdoc.org/

 */
'use strict';
function startPort(){};
startPort.httpPort = "8880";
startPort.httpsPort = "3443";
startPort.projectUrl = "/";
module.exports = startPort;