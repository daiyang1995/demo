/**
 * http://usejsdoc.org/

 */
'use strict';
function redisConf(){};
redisConf.port = 6379;
redisConf.hostName = "127.0.0.1";
redisConf.passWord = "123";
redisConf.redisPrefix = "melktech-";
module.exports = redisConf;