/**
 * http://usejsdoc.org/

 */
'use strict';
function apiApplication() {};
apiApplication.baseHttpsDomain = "/kp-api/ssl/h5/";

module.exports=apiApplication;