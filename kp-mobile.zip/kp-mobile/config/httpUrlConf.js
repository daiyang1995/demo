/**
 * http://usejsdoc.org/

 */
'use strict';
function httpUrlConf(){};
httpUrlConf.httpsPort = "8443"
httpUrlConf.httpPort = "8080"
httpUrlConf.hostName = "192.168.1.93"
httpUrlConf.baseHttpsDomain = "/kp-api/ssl/h5/";
httpUrlConf.key = "zhengshu/client.key";
httpUrlConf.cert = "zhengshu/client.crt";
module.exports = httpUrlConf;
