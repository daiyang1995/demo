/**
 * http://usejsdoc.org/

 */
'use strict';
var html = document.querySelector('html');
var rem = html.offsetWidth / 6.4;
html.style.fontSize = rem + "px";