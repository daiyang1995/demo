/**
 * http://usejsdoc.org/

 */
'use strict';
var http = require('http');
var qs = require('querystring');
var port = 8080;
var method = "post";
/**
 * http请求
 * @param req
 * @param callback function()
 */
function ajaxHttp(req,callback){
    req.body.jsonpcallback = req.query.jsonpcallback;
    var options = {
        hostname: 'localhost',
        port: port,
        path: req.body.url,
        method: method,
        // rejectUnauthorized: false,
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
        }
        // key: fs.readFileSync('zhengshu/client.key'),
        // cert: fs.readFileSync('zhengshu/client.crt')
    };
    var content = qs.stringify(req.body);
    var req1 = http.request(options, callback);
    req1.on('error', function (e) {
        console.log('problem with request: ' + e.message);
    });
    req1.write(content);
    req1.end();
}

module.exports = ajaxHttp;
