/**
 * 用于上拉下刷加载，
 *   scroll: 内容器(默认  '.scroll' )
 *   outerScroller : 外容器  (默认  '.outerScroller' )
 *   loading : 正在加载标识(默认 "正在加载" )
 *   upLoading : 上拉语句(默认 "上拉加载" )
 *   downLoading : 下拉语句(默认 "下拉刷新" )
 *   upFinish : 上拉完成语句（默认 "没有更多了"）
 *   downFinish : 下拉完成语句（默认 "没有更多了"）
 *   triggerHeight : 触发高度 (默认 70)
 *   upFunction : 上拉加载方法 (function名称不带（）);
 *   downFunction : 下拉刷新方法  (function名称不带（）)
 *   remove() 方法 移除正在加载
 *   upFinish() 方法 上拉没有了
 *   downFinish() 方法 下刷没有了
 * @param json
 */

var upLoadingStatus = true;
var downLoadingStatus = true;
function updownloading(json){
	var scroll,outerScroller,loading,triggerHeight,upFunction,downFunction,upLoading,downFinish,upFinish,downFinish;
	var touchStart = 0;
	var touchDis = 0;
	if(json!=null){
		//内容器
		if(json.scroll!=null) 
			scroll = json.scroll;
		else
			scroll = '.scroll';
		//外容器
		if(json.outerScroller!=null)
			outerScroller = json.outerScroller;
		else
			outerScroller = '.outerScroller';
		//正在加载标识
		if(json.loading!=null)
			loading = json.loading;
		else
			loading = "正在加载……";
		//触发高度
		if(json.triggerHeight!=null)
			triggerHeight = json.triggerHeight;
		else
			triggerHeight = 70;
		// upFunction : 上拉加载方法 (function);
		if(json.upFunction!=null)
			upFunction = json.upFunction;
		else {
			upFunction = null;
			upLoadingStatus = false;
		}
		// downFunction : 下拉刷新方法  (function)
		if(json.downFunction!=null)
			downFunction = json.downFunction;
		else {
			downFunction = null;
			downLoadingStatus = false;
		}
		//upLoading : 上拉语句(默认 "上拉加载" )
		if(json.upLoading!=null)
			upLoading = json.upLoading;
		else
			upLoading = "上拉加载";
		//downLoading : 下拉语句(默认 "下拉刷新" )
		if(json.downLoading!=null)
			downLoading = json.downLoading;
		else
			downLoading = "下拉刷新";
		//upFinish : 上拉完成语句（）
		if(json.upFinish!=null)
			upFinish = json.upFinish;
		else
			upFinish = "没有更多了";
		//downFinish : 下拉完成语句（）
		if(json.downFinish!=null)
			downFinish = json.downFinish;
		else
			downFinish = "没有更多了";
		
	}else{
		scroll = '.scroll';
		outerScroller = '.outerScroller';
		loading = "正在加载……";
		triggerHeight = 70;
		upFunction = null;
		downFunction = null;
		upLoadingStatus = false;
		downLoadingStatus = false;
		upLoading = "上拉加载";
		downLoading = "下拉刷新";
		upFinish = "没有更多了";
		downFinish = "没有更多了";
	}
	$(scroll).css({"width":"100%","margin-top":"0px","position":"absolute","left":"0px","padding":"0px","top":"0px"});
	$(outerScroller).css({"position":"absolute","top":"0","bottom":"0","width":"100%","left":"0px","overflow":"hidden"});
	$(scroll).prepend("<div id='loading'>"+loading+"</div>");
	scroll = document.querySelector(scroll);
	outerScroller = document.querySelector(outerScroller);
	
	outerScroller.addEventListener('touchstart', function(event) { 
	     var touch = event.targetTouches[0]; 
	     // 把元素放在手指所在的位置 
	        touchStart = touch.pageY; 
	     }, false);
	outerScroller.addEventListener('touchmove', function(event) { 
        var touch = event.targetTouches[0]; 
        scroll.style.top = scroll.offsetTop + touch.pageY-touchStart + 'px';
        touchStart = touch.pageY;
        touchDis = touch.pageY-touchStart;
        var top = scroll.offsetTop;
        if(top>0 && downLoadingStatus){
        	console.log("1"+downLoadingStatus)
        	$('#loading').html(downLoading);
        	$('#loading').css("bottom","auto");
        	$('#loading').css("top","-20px");
        	$('#loading').show();
        }else if(top < 0 && upLoadingStatus){
        	console.log("2"+upLoadingStatus)
        	$('#loading').html(upLoading);
        	$('#loading').css("top","auto");
       	 	$('#loading').css("bottom","-20px");
        	$('#loading').show();
        }else if(top>0 && !(downLoadingStatus)){
        	console.log("3"+downLoadingStatus)
	    	$('#loading').html(upFinish);
	    	$('#loading').css("bottom","auto");
	    	$('#loading').css("top","-20px");
	    	$('#loading').show();
    	}else if(top < 0 && !(upLoadingStatus)){
    		console.log("4"+upLoadingStatus)
	    	$('#loading').html(downFinish);
	    	$('#loading').css("top","auto");
	   	 	$('#loading').css("bottom","-20px");
	    	$('#loading').show();
    	}
        }, false);
   outerScroller.addEventListener('touchend', function(event) { 
        touchStart = 0;
        var top = scroll.offsetTop;
        //下拉刷新
        if(top>triggerHeight && downLoadingStatus ){
        	$('#loading').html(loading)
        	$('#loading').show();
        	$('#loading').css("bottom",null);
        	$('#loading').css("top","-20px");
        	upFunction();
        }
        if(top>0){
            var time = setInterval(function(){
            	console.log(time)
              scroll.style.top = scroll.offsetTop -1+'px';
              if(scroll.offsetTop<=-1){$('#loading').hide();clearInterval(time);}
            },1)
        }
        
      //上拉加载
        var top1 = $(scroll).outerHeight(true)-$(window).outerHeight(true);
        var to2 = scroll.offsetTop-(top+top1);
        if( top+top1<-1*triggerHeight && upLoadingStatus){ 
        	 $('#loading').html(loading)
        	 $('#loading').show();
        	 $('#loading').css("top",null);
        	 $('#loading').css("bottom","-20px");
        	 downFunction();
        }
        if(scroll.offsetTop<to2){
        	var time1 = setInterval(function(){
                scroll.style.top = scroll.offsetTop +1+'px';
                if(scroll.offsetTop>=to2){clearInterval(time1);$('#loading').hide();}
                if(top1<0&&scroll.offsetTop>=1){$('#loading').hide();clearInterval(time1);}
              },1)
        }
    }, false);
}

	function remove(){
		 $('#loading').hide();
	}
	function upFinish(){
		upLoadingStatus = false;
	}
	function downFinish(){
		downLoadingStatus = false;
	}
