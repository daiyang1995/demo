//日期计算
function calDate(json){
	if(json!=null&&json.startDate!=null&&json.endDate!=null){
		var startDate = json.startDate;
		var endDate = json.endDate;
		if(endDate-startDate>4){//5年判断
			return defaultDate();
		}
		return calculateDate(startDate,endDate);
//		console.log(new Date("2012/12/25 20:11:11"));
	}else{ //什么都没给  now()-2 -> now()+2
		return defaultDate();
	}
}
function defaultDate(){ //什么都没给  now()-2 -> now()+2
	var year = new Date().getFullYear();
	var startDate =year - 2;
	var endDate = year + 2;
	return calculateDate(startDate,endDate);
}
function calculateDate(startDate,endDate){
	var s ="[";
	for (var i=startDate;i<=endDate;i++)
	{	
		var ss = "{id:'"+i+"',value:'"+i+"年',childs:[";
		for(var ii = 1 ; ii <= 12 ; ii++){
			ss+="{id:'"+ii+"',value:'"+ii+"月',childs:["
			switch(ii){
			case 1:case 3:case 5:case 7:case 8:case 10:case 12://31天
				for(var iii = 1 ; iii <= 31 ; iii++){
					ss+="{id:'"+iii+"',value:'"+iii+"日'},"
				}
				break;
			case 2:
				if(checkLeapYear(i)){//是闰年29天 
					for(var iii = 1 ; iii <= 29 ; iii++){
						ss+="{id:'"+iii+"',value:'"+iii+"日'},"
					} 
				   }else{//不是闰年 28天
					   for(var iii = 1 ; iii <= 28 ; iii++){
							ss+="{id:'"+iii+"',value:'"+iii+"日'},"
						}
				   }
				break; 
			case 4:case 6:case 9:case 11: //30天
				for(var iii = 1 ; iii <= 30 ; iii++){
					ss+="{id:'"+iii+"',value:'"+iii+"日'},"
				}
				break;
			}
			ss = ss.substring(0,ss.length-1);
			ss+="]},"
		}
		ss = ss.substring(0,ss.length-1);
		ss+="]},";
		s+=ss;
	}
	s =s.substring(0,s.length-1);
	s +="]";
	return eval(s);
}
function checkLeapYear(i){
	 var cond1 = i % 4 == 0;  //条件1：年份必须要能被4整除
	 var cond2 = i % 100 != 0;  //条件2：年份不能是整百数
	 var cond3 = i % 400 ==0;  //条件3：年份是400的倍数
	 var cond = cond1 && cond2 || cond3;
	 return cond;
}