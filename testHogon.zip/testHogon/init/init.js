var multipart = require('connect-multiparty');
var multipartMiddleware = multipart();

var redisTool = require('../tool/redisTool');
var ajaxHttp = require('../tool/ajaxHttp');
var ajaxHttps = require('../tool/ajaxHttps');
var co = require('co');

module.exports = (app) => {
    app.get('/', (req, res) => {
        req.body.creator = "asdf";
        let ipName = req.ip;
        co(function* () {
            if (req.body.creator) {
                yield new Promise((resolve1, reject1) => {
                    //如果body 里有creator字段 就看redis里有没有 没有就放进去
                    redisTool.get(ipName, (error, response) => {
                        if (!(response)) {
                            redisTool.set(ipName, req.body.creator, () => {
                                redisTool.expire(ipName, 60 * 30);
                            });
                        } else {
                            //延时半小时
                            redisTool.expire(ipName, 60 * 30);
                        }
                        console.log(response);
                        resolve1(response);
                    });
                });
            } else {
                yield new Promise((resolve1, reject1) => {
                    redisTool.get(ipName, (error, response) => {
                        if (!(response)) {
                            console.log("不知道");
                            //打回登陆页面 没有登陆记录
                            res.redirect("/../../../index");
                        } else {
                            console.log("回到");
                            req.body.creator = response;
                        }
                        resolve1(response);
                    });
                });
            }
            console.log(req.body);
            res.render("index", req.body);
        });
    });

    //以后登陆用
    app.get("/index", (req, res) => {
        res.render("index");
    });
    //拦截其他未定义的get方法
    app.get('*', (req, res) => {
        res.redirect("/");
    });
    //银行卡添加
    app.post('/CommonInformation/AddBankInformation', (req, res) => {
        req.body.url = "/kp-student-api/apiAccount/bankList";
        ajaxHttp(req, (res2) => {
            res2.setEncoding('utf8');
            // 响应体过大 自己拆分
            let body = "";
            res2.on('data', (chunk) => {
                body += chunk;
            });
            res2.on('end', () => {
                try {
                    req.body.bankList = body;
                    res.render('CommonInformation/AddBankInformation', req.body);
                }
                catch (e) {
                    console.log(e.message);
                }
            });
        });
    });
    //银行卡信息查看
    app.post('/CommonInformation/CheckBankInformation', (req, res) => {
        co(function* () {
            yield new Promise((resolve1, reject1) => {
                req.body.url = "/kp-student-api/apiAccount/bankList";
                ajaxHttp(req, (res2) => {
                    res2.setEncoding('utf8');
                    // 响应体过大 自己拆分
                    let body = "";
                    res2.on('data', (chunk) => {
                        body += chunk;
                    });
                    res2.on('end', () => {
                        try {
                            req.body.bankList = body;
                            console.log(body);
                            // if (req.body.bankInfo != null)
                            //     res.render("CommonInformation/CheckBankInformation", req.body);
                        }
                        catch (e) {
                            console.log(e.message);
                        }
                        finally {
                            resolve1(body);
                        }
                    });
                });
            });
            yield new Promise((resolve2, reject1) => {
                console.log("------------------------");
                req.body.url = "/kp-student-api/apiAccount/selectById";
                ajaxHttp(req, (res2) => {
                    res2.setEncoding('utf8');
                    // 响应体过大 自己拆分
                    let body = "";
                    res2.on('data', (chunk) => {
                        body += chunk;
                    });
                    res2.on('end', () => {
                        try {
                            req.body.bankInfo = body;
                            console.log(body);
                            res.render("CommonInformation/CheckBankInformation", req.body);
                        }
                        catch (e) {
                            console.log(e.message);
                        }
                        finally {
                            resolve2(body);
                        }
                    });
                });
            });
        });
    });
    //银行卡删除
    app.post('/CommonInformation/DelBankInformation', (req, res) => {
        req.body.url = "/kp-student-api/apiAccount/deleteUserBank";
        ajaxHttp(req, (res2) => {
            res2.setEncoding('utf8');
            // 响应体过大 自己拆分
            let body = "";
            res2.on('data', (chunk) => {
                body += chunk;
            });
            res2.on('end', () => {
                try {
                    req.body.bankList = body;
                    res.render('CommonInformation/BankInformation', req.body);
                }
                catch (e) {
                    console.log(e.message);
                }
            });
        });
    });
    //ajax提交
    app.post('/post', multipartMiddleware, (req, res) => {
        ajaxHttp(req, (res2) => {
            res2.setEncoding('utf8');
            // 响应体过大 自己拆分
            let body = "";
            res2.on('data', (chunk) => {
                body += chunk;
            });
            res2.on('end', () => {
                try {
                    res.send(body);
                }
                catch (e) {
                    console.log(e.message);
                }
            });
        });
    });
    //拦截除了 上面定义的以外的全部post
    app.post('*', (req, res) => {
        console.log(req.url);
        req.url = req.url.substring(1, req.url.length);
        console.log(req.url);
        res.render(req.url, req.body);
    });
};
