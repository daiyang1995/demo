/**
 * http://usejsdoc.org/

 */
'use strict';
var https = require('https');
var qs = require('querystring');
var fs = require('fs');
var port = 8043;
var method = "post";
/**
 * https请求
 * @param req
 * @param callback function()
 */
function ajaxHttps(req,callback){
    var options = {
        hostname: '192.168.74.128',
        port: port,
        path: req.body.url,
        method: method,
        rejectUnauthorized: false,
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
        },
        key: fs.readFileSync('zhengshu/client.key'),
        cert: fs.readFileSync('zhengshu/client.crt')
    };
    var content = qs.stringify(req.body);
    var req1 = https.request(options, callback);
    req1.on('error',  (e) => {
        console.log('problem with request: ' + e.message);
    });
    req1.write(content);
    req1.end();
}

module.exports = ajaxHttps;
