/**
 * http://usejsdoc.org/

 */
'use strict';
var http = require('http');
var qs = require('querystring');
var port = 8000;
var method = "post";
/**
 * http请求
 * @param req
 * @param callback function()
 */
function ajaxHttp(req,  callback){
    var options = {
        hostname: '192.168.74.128',
        port: port,
        path: req.body.url,
        method: method,
        // rejectUnauthorized: false,
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
            // 'Access-Control-Allow-Origin': "http://0" ,
            // 'Access-Control-Allow-Methods' : 'post',
            // 'Access-Control-Allow-Headers' : '*'
        }
    };
    var content = qs.stringify(req.body);
    var req1 = http.request(options, callback);
    req1.on('error',  (e) => {
        console.log('problem with request: ' + e.message);
    });
    req1.write(content);
    req1.end();
}

module.exports = ajaxHttp;
