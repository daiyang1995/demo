/**
 * http://usejsdoc.org/

 */
'use strict';


/**
 *
 * @type {Array}
 */
let array = [];
let i = 1229;
array[0] =i;

function Callback(id){
    $('#'+id+'screen').hide('fast');
    $('#'+id).hide('fast');
}
function  show(id) {
    $('#'+id+'screen').show('fast');
    $('#'+id).show('fast');
}
/**
 *  * 弹框
 *  init(json) 弹框初始化
 *  clearAll() 可以清除所有的弹框
 */
function popup(){}

/**
 *  * 弹框初始化
 * @param json
 * @param {{popup:jquery}} json 弹框内容 默认$('#popup')
 * @param {{cancel:function}} json 取消按钮 无默认
 * @param {{submit:function}} json 确定按钮  无默认
 * @param {{cancelCallback:function}} json 确认函数
 * @param {{submitCallback:function}} json 取消函数
 * @returns {number}
 */
popup.init = function(json){
    let index = array.length;
    let zindx =  array[--index];
    var popup,cancel,submit,cancelCallback,submitCallback;
    if( json ) {
        if (json.popup) {
            popup = json.popup;
        }
        else {
            popup = $('#popup');
        }
        if (json.cancel) {
            cancel = json.cancel;
        }
        else {
            cancel = null;
        }
        if (json.submit) {
            submit = json.submit;
        }
        else {
            submit = null;
        }
        if ( json.cancelCallback ) {
            cancelCallback = json.cancelCallback;
        }
        else {
            cancelCallback = null;
        }
        if (json.submitCallback ) {
            submitCallback = json.submitCallback;
        }
        else {
            submitCallback = null;
        }

    }
    else{
        popup = $('#popup');
        cancel = null;
        submit =  null;
        cancelCallback =  null;
        submitCallback =  null;
    }
    $(popup).show();
    $(popup).wrap('<div class="ui-popup-container pop in ui-popup-active popupDialog-popup"  id="'+zindx+'" ></div>');
    let content = $('#'+zindx);
    content.before('<div class="ui-popup-screen ui-overlay-a in popupDialog-screen" id="'+zindx+'screen"></div>');
    let contentScreen =  $('#'+zindx+'screen');

    contentScreen.on("tap",{zindx:zindx}, (e) => {
        let zindx =  e.data.zindx;
        Callback(zindx);
    });
    if(cancel){
        $(cancel).on('tap',{zindx:zindx}, (e) => {
            if(cancelCallback === null){
                let zindx =  e.data.zindx;
                Callback(zindx);
            }else{
                cancelCallback();
            }
        });
    }

    if(submit){
        $(submit).on('tap',{zindx:zindx}, (e) => {
            if(submitCallback === null){
                let zindx =  e.data.zindx;
                Callback(zindx);
            }else{
                submitCallback();
            }
        });
    }
    contentScreen.css('z-index',zindx);
    content.css('z-index',++zindx);
    zindx++;
    array[++index] =zindx;

    return zindx - 2;
};
/**
 *  清除所有弹框
 */
popup.clearAll =function(){
    for (let ii = 0  ;ii<array.length ; ii++){
        Callback(array[ii]);
    }
};
