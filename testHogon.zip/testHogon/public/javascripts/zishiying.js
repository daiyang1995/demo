$(document).ready(function(){
	
	$('.inputText').bind("focus", function(event){
		$('html, body').animate({
	        scrollTop: $(event.target).parent().offset().top - $(".header").outerHeight(true)
	    }, 300);  
	});
	
});
