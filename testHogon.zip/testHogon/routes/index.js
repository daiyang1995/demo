var express = require('express');
var router = express.Router();


var data = { name : '<span color="red">Rosen</span>' };

// var Hogan = require('hogan.js');
// var template = Hogan.compile("Follow @{{screenName}}.");
// var output = template.render(data);

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: data ,partials :{ header : 'new' } });
});


// prints "Follow @dhg."
// console.log(output);

module.exports = router;