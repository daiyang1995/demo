package com.qucai.kp.api.common;

import java.io.PrintWriter;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.TypeReference;
import com.qucai.kp.api.tool.FastJsonTool;
import com.qucai.kp.common.codec.DESUtil;
import com.qucai.kp.common.codec.RSAUtil;
import com.qucai.kp.common.context.SysInfo;
import com.qucai.kp.common.enums.RetEnum;
import com.qucai.kp.common.tool.JsonTool;

public class CommonInterceptor implements HandlerInterceptor {

	private static Logger logger = LoggerFactory
			.getLogger(CommonInterceptor.class);

	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {

		String uri = request.getRequestURI();
		String method = request.getMethod();
		String channel = request.getHeader("channel");
		if(StringUtils.isBlank(channel)){
			channel = request.getParameter("channel");
		}
		String reqToken = request.getParameter("reqToken");
		String reqData = request.getParameter("reqData");

		// 校验请求方式
		if (!SecurityConstant.REQUEST_METHOD_POST.equals(method)) {
			logger.info("请求方式错误 method = " + method);
			writeRes(response, RetEnum.REQUEST_METHOD_ERROR.getRet(),
					RetEnum.REQUEST_METHOD_ERROR.getMsg());
			return false;
		}

		// 校验渠道
		if (SecurityConstant.CHANNEL_ANDROID.equals(channel)) {
			logger.info("android 请求:{}", uri);
		} else if (SecurityConstant.CHANNEL_IOS.equals(channel)) {
			logger.info("ios 请求:{}", uri);
		} else if (SecurityConstant.CHANNEL_WX.equals(channel)) {
			logger.info("wx 请求:{}", uri);
		} else if (SecurityConstant.CHANNEL_M_SITE.equals(channel)) {
			logger.info("m站 请求:{}", uri);
		} else if (SecurityConstant.CHANNEL_WEB.equals(channel)) {
			logger.info("网站 请求:{}", uri);
		} else {
			logger.error("channel值错误 channel = " + channel);
			writeRes(response, RetEnum.PARAM_ERROR.getRet(),
					RetEnum.PARAM_ERROR.getMsg());
			return false;
		}

		try {
			String desKey = RSAUtil.decryptByPrivateKey(reqToken,
					SysInfo.CONFIG.get("API_RSA_PRIVATE_KEY"));

			String reqJson = DESUtil.decrypt(reqData, desKey);
			logger.info("decrypt data:" + reqJson);

			Map<String, Object> reqDataMap = JsonTool.resolveByFastJson(
					new TypeReference<Map<String, Object>>() {
					}, reqJson);
			reqDataMap.put("channel", channel);
					
			request.setAttribute("reqDataMap", reqDataMap);
		} catch (Exception e) {
			logger.error("非法请求,reqToken:{},reqData:{}", reqToken, reqData);
			writeRes(response, RetEnum.HTTP_ERROR_403.getRet(),
					RetEnum.HTTP_ERROR_403.getMsg());
			return false;
		}

		return true;
	}

	@Override
	public void postHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void afterCompletion(HttpServletRequest request,
			HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		// TODO Auto-generated method stub

	}

	protected void writeRes(HttpServletResponse response, String ret, String msg)
			throws Exception {
		String json = FastJsonTool.genJson(false, ret, msg);
		response.setHeader("Content-Type", "text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print(json);
		out.flush();
		out.close();
	}

}
