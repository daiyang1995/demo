package com.qucai.kp.api.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.qucai.kp.api.vo.ApprovedInfo;
import com.qucai.kp.api.vo.ClaimApplyVo;
import com.qucai.kp.api.vo.ProveinceAndCityVo;
import com.qucai.kp.entity.ClaimApply;

@Repository
public interface ClaimApplyDao {
    int deleteByPrimaryKey(String id);

    int insertSelective(ClaimApply record);

    ClaimApply selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(ClaimApply record);
    
    List<ClaimApplyVo> findClaimApplyVoMap(Map<String, Object> paramMap);
    
    List<ClaimApplyVo> findPolicyList(Map<String, Object> paramMap);
    
    ProveinceAndCityVo findProveinceAndCity(String claimId);
    
    ApprovedInfo findApprovedInfo(String claimId);
}