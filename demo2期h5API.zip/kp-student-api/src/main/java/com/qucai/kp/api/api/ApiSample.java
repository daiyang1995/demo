package com.qucai.kp.api.api;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.qucai.kp.api.common.ExRetEnum;
import com.qucai.kp.api.tool.FastJsonTool;

@Controller
@RequestMapping(value = "/apiSample")
public class ApiSample {

    @RequestMapping(value = "/helloworld")
    @ResponseBody
    public String helloworld(HttpServletRequest request) throws Exception {
    	Map<String, Object> reqDataMap = (Map<String, Object>)request.getAttribute("reqDataMap");
    	
		for (String k : reqDataMap.keySet()) {
			System.out.println("key:" + k + " value:" + reqDataMap.get(k));
		}
		
		List<Map<String, String>> dataList = new ArrayList<Map<String,String>>();
		Map<String, String> m1 = new HashMap<String, String>();
		m1.put("aa", "aa");
		m1.put("bb", "bb");
		Map<String, String> m2 = new HashMap<String, String>();
		m2.put("cc", "cc");
		dataList.add(m1);
		dataList.add(m2);
		reqDataMap.put("dataList", dataList);
    	
        return FastJsonTool.genJson(false, ExRetEnum.SUCCESS, reqDataMap);
    }

}
