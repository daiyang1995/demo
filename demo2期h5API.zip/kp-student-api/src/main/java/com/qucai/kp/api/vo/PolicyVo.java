package com.qucai.kp.api.vo;

import com.qucai.kp.entity.Policy;

public class PolicyVo extends Policy {

	/**
	 * 保单快照-投保人姓名
	 */
	private String policyOwnerName;

	/**
	 * 保单快照-投保人身份证
	 */
	private String policyOwnerIdCard;
	
	/**
	 * 用户当前姓名
	 */
	private String userName;
	
	/**
	 * 用户当前身份证（可以作为登录名）
	 */
	private String userIdCard;

	/**
	 * 方案/计划名称
	 */
	private String planName;
	
	public String getPolicyOwnerName() {
		return policyOwnerName;
	}

	public void setPolicyOwnerName(String policyOwnerName) {
		this.policyOwnerName = policyOwnerName;
	}

	public String getPolicyOwnerIdCard() {
		return policyOwnerIdCard;
	}

	public void setPolicyOwnerIdCard(String policyOwnerIdCard) {
		this.policyOwnerIdCard = policyOwnerIdCard;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserIdCard() {
		return userIdCard;
	}

	public void setUserIdCard(String userIdCard) {
		this.userIdCard = userIdCard;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}
	
}
