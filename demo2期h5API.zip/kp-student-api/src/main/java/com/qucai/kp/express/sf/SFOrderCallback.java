package com.qucai.kp.express.sf;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Date;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.alibaba.fastjson.TypeReference;
import com.qucai.kp.api.kd100.SubscribeReq;
import com.qucai.kp.api.kd100.SubscribeUtil;
import com.qucai.kp.api.service.ClaimExpressService;
import com.qucai.kp.api.service.ClaimLogService;
import com.qucai.kp.api.tool.Tool;
import com.qucai.kp.common.tool.JsonTool;
import com.qucai.kp.entity.ClaimExpress;
import com.qucai.kp.entity.ClaimLog;
import com.sf.openapi.common.entity.HeadMessageResp;
import com.sf.openapi.common.entity.MessageReq;
import com.sf.openapi.common.entity.MessageResp;
import com.sf.openapi.express.sample.order.dto.OrderNotifyReqDto;


public class SFOrderCallback extends HttpServlet {
	
	@Autowired
	private ClaimExpressService claimExpressService;
	@Autowired
	private ClaimLogService claimLogService;
	
	
	
	private static final long serialVersionUID = 1L;
	
	private static Logger logger = LoggerFactory.getLogger(SFOrderCallback.class);
	
	// use this 'wac' get your service bean
	protected WebApplicationContext wac;

	@Override
	public void init() throws ServletException {
		super.init();
		ServletContext sc = getServletContext();
		wac = WebApplicationContextUtils
				.getWebApplicationContext(sc);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		String inputStr = getParamFromStream(request);
		logger.info("SFOrderCallback:{}", inputStr);
		
		MessageReq<OrderNotifyReqDto> req = JsonTool.resolveByFastJson(
				new TypeReference<MessageReq<OrderNotifyReqDto>>() {
				}, inputStr);
		
		// TODO
		// 逻辑处理
		// 根据订单id更新运单号
		System.out.println(req.getBody().getOrderId());
		System.out.println(req.getBody().getMailNo());
		//TODO 更新订单记录
		ClaimExpress record = new ClaimExpress();
		
		record.setId(req.getBody().getOrderId());
		record.setTrackingNo(req.getBody().getMailNo());
		
		int i = claimExpressService.updateByPrimaryKeySelective(record);	
		
		if(i == 1){
			claimLogService.deleteByPrimaryKey(req.getBody().getOrderId());
			// 记录日志
			ClaimLog claimLog = new ClaimLog();
			claimLog.setId(Tool.uuid());
			claimLog.setClaimId(record.getClaimApplyId());
			claimLog.setRemark("物理件已提交（预约收件，快递单号：" + record.getTrackingNo() +"）");
			claimLog.setCreateTime(new Date());
			claimLog.setCreator("-1");
			claimLogService.insertSelective(claimLog);
			
			// 构造基本订阅请求类
			SubscribeReq req1 = new SubscribeReq();
			req1.setNumber(req.getBody().getMailNo());
			// 订阅快递100
			req1.setCompany("shunfeng");
			SubscribeUtil.publishSubscribe(req1);
		}
			
		MessageResp<OrderNotifyRespExDto> resp = new MessageResp<OrderNotifyRespExDto>();
		HeadMessageResp head = new HeadMessageResp();
		head.setTransType(SFConstant.HEAD_TRANSTYPE_4201);
		head.setTransMessageId(SFTool.genTransMessageId());
		resp.setHead(head);
		
		OrderNotifyRespExDto orderNotifyRespExDto = new OrderNotifyRespExDto();
		orderNotifyRespExDto.setOrderId(req.getBody().getOrderId());
		
		resp.setBody(orderNotifyRespExDto);
		response.getWriter().print(JsonTool.genByFastJson(resp));
		
	}
	
	protected String getParamFromStream(HttpServletRequest request)
			throws IOException {
		StringBuffer sb = new StringBuffer();
		InputStream is = request.getInputStream();
		InputStreamReader isr = new InputStreamReader(is);
		BufferedReader br = new BufferedReader(isr);
		String s = "";
		while ((s = br.readLine()) != null) {
			sb.append(s);
		}
		return sb.toString();
	}
}
