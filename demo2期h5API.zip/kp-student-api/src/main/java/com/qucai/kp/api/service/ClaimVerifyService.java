package com.qucai.kp.api.service;

import com.qucai.kp.entity.ClaimVerify;

public interface ClaimVerifyService {
    int deleteByPrimaryKey(String id);

    int insertSelective(ClaimVerify record);

    ClaimVerify selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(ClaimVerify record);

    ClaimVerify  selectByClaimApplyId(String id);
}