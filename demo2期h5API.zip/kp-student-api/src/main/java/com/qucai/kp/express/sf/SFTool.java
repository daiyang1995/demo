package com.qucai.kp.express.sf;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.qucai.kp.common.tool.RedisTool;
import com.sf.openapi.common.entity.AppInfo;
import com.sf.openapi.common.entity.HeadMessageReq;
import com.sf.openapi.common.entity.MessageReq;
import com.sf.openapi.common.entity.MessageResp;
import com.sf.openapi.express.sample.order.dto.CargoInfoDto;
import com.sf.openapi.express.sample.order.dto.DeliverConsigneeInfoDto;
import com.sf.openapi.express.sample.order.dto.OrderFilterReqDto;
import com.sf.openapi.express.sample.order.dto.OrderFilterRespDto;
import com.sf.openapi.express.sample.order.dto.OrderQueryReqDto;
import com.sf.openapi.express.sample.order.dto.OrderQueryRespDto;
import com.sf.openapi.express.sample.order.dto.OrderReqDto;
import com.sf.openapi.express.sample.order.dto.OrderRespDto;
import com.sf.openapi.express.sample.order.tools.OrderTools;
import com.sf.openapi.express.sample.route.dto.RouteIncReqDto;
import com.sf.openapi.express.sample.route.dto.RouteIncRespDto;
import com.sf.openapi.express.sample.route.dto.RouteReqDto;
import com.sf.openapi.express.sample.route.dto.RouteRespDto;
import com.sf.openapi.express.sample.route.tools.RouteTools;
import com.sf.openapi.express.sample.security.dto.TokenReqDto;
import com.sf.openapi.express.sample.security.dto.TokenRespDto;
import com.sf.openapi.express.sample.security.tools.SecurityTools;
import com.sf.openapi.express.sample.waybill.dto.WaybillReqDto;
import com.sf.openapi.express.sample.waybill.dto.WaybillRespDto;
import com.sf.openapi.express.sample.waybill.tools.WaybillDownloadTools;

public class SFTool {

	private static SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

	public static String genTransMessageId() {
		String dateKey = sdf.format(new Date());

		Long rs = RedisTool.inc(dateKey);
		RedisTool.expire(dateKey, 3600);

		return dateKey + StringUtils.leftPad(rs.toString(), 10, "0");
	}

	private static AppInfo genBaseAppInfo() {
		AppInfo appInfo = new AppInfo();
		// appInfo.setAppId(SysInfo.CONFIG.get("EXPRESS_SF_APP_ID"));
		// appInfo.setAppKey(SysInfo.CONFIG.get("EXPRESS_SF_APP_KEY"));
		// appInfo.setAccessToken(RedisTool.get(SFConstant.SF_ACCESS_TOKEN));
		appInfo.setAppId("00031472");
		appInfo.setAppKey("120AF7C10687A75C72A66E174A389E4B");
		return appInfo;
	}

	private static AppInfo genAppInfo() throws Exception {

		if (!RedisTool.exists(SFConstant.SF_ACCESS_TOKEN)) {
			genAccessToken();
		}

		AppInfo appInfo = genBaseAppInfo();
		appInfo.setAccessToken(RedisTool.get(SFConstant.SF_ACCESS_TOKEN));
		return appInfo;
	}

	public static void genAccessToken() throws Exception {
		AppInfo appInfo = genBaseAppInfo();

		MessageReq<TokenReqDto> accessTokenReq = new MessageReq<TokenReqDto>();
		HeadMessageReq head = new HeadMessageReq();
		head.setTransType(SFConstant.HEAD_TRANSTYPE_301);
		head.setTransMessageId(SFTool.genTransMessageId());
		accessTokenReq.setHead(head);

		MessageResp<TokenRespDto> rs = SecurityTools.applyAccessToken(
				SFConstant.URL_SECURITY_ACCESS_TOKEN, appInfo, accessTokenReq);
		System.out.println(rs.getBody().getAccessToken());

		RedisTool
				.set(SFConstant.SF_ACCESS_TOKEN, rs.getBody().getAccessToken());
	}

	public static void genOrder(String orderId) throws Exception {
		AppInfo appInfo = genAppInfo();

		MessageReq<OrderReqDto> req = new MessageReq<OrderReqDto>();
		HeadMessageReq head = new HeadMessageReq();
		head.setTransType(SFConstant.HEAD_TRANSTYPE_200);
		head.setTransMessageId(SFTool.genTransMessageId());
		req.setHead(head);

		OrderReqDto orderReqDto = new OrderReqDto();

		orderReqDto.setOrderId(orderId);
		// 顺丰特惠
		orderReqDto.setExpressType(new Short("2"));
		// 寄方付/寄付月结【默认值】
		orderReqDto.setPayMethod(new Short("1"));
		// 是否需要签回单号（0：否；1：是）
		orderReqDto.setNeedReturnTrackingNo(new Short("0"));
		// 是否下call（通知收派员上门取件）（0：否；1：是）
		orderReqDto.setIsDoCall(new Short("1"));
		// 是否申请运单号（0：否；1：是）
		orderReqDto.setIsGenBillNo(new Short("1"));
		// 顺丰月结卡号；寄付现结，下单不需要传custId字段
		// orderReqDto.setCustId("7550010173");
		// 月结卡号对应的网点，如果付款方式为第三方支付，则必填
		// orderReqDto.setPayArea("755CQ");
		// 要求上门取件开始时间，格式：YYYY-MM-DD HH24:MM:SS，示例：2013-7-30 09:30:00，
		// 默认值为系统收到订单的系统时间
		// orderReqDto.setSendStartTime("2014-4-24 09:30:00");
		// 备注，最大长度30个汉字
		// orderReqDto.setRemark("易碎物品，小心轻放");

		// 寄件方信息
		DeliverConsigneeInfoDto deliverInfoDto = new DeliverConsigneeInfoDto();
		deliverInfoDto.setAddress("上地");
		deliverInfoDto.setCity("朝阳");
		deliverInfoDto.setCompany("京东");
		deliverInfoDto.setContact("李四");
		deliverInfoDto.setCountry("中国");
		deliverInfoDto.setProvince("北京");
		deliverInfoDto.setShipperCode("787564");
		deliverInfoDto.setTel("010-95123669");
		deliverInfoDto.setMobile("13612822894");

		// 收件方信息
		DeliverConsigneeInfoDto consigneeInfoDto = new DeliverConsigneeInfoDto();
		consigneeInfoDto.setCompany("顺丰");
		consigneeInfoDto.setContact("张三");
		consigneeInfoDto.setTel("0755-33915561");
		consigneeInfoDto.setMobile("18588413321");
		consigneeInfoDto.setCountry("中国");
		consigneeInfoDto.setProvince("广东");
		consigneeInfoDto.setCity("深圳");
		consigneeInfoDto.setAddress("世界第一广场");
		consigneeInfoDto.setShipperCode("518100");

		// 货物信息
		CargoInfoDto cargoInfoDto = new CargoInfoDto();
		cargoInfoDto.setParcelQuantity(1);// 包裹数
		cargoInfoDto.setCargo("文件");// 货物名称

		orderReqDto.setDeliverInfo(deliverInfoDto);
		orderReqDto.setConsigneeInfo(consigneeInfoDto);
		orderReqDto.setCargoInfo(cargoInfoDto);

		req.setBody(orderReqDto);

		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put("sf_appid", appInfo.getAppId());
		paramMap.put("sf_appkey", appInfo.getAppKey());
		paramMap.put("access_token", appInfo.getAccessToken());

		MessageResp<OrderRespDto> rs = OrderTools.order(SFConstant.URL_ORDER,
				appInfo, req);
		System.out.println(rs);

	}
	public static void genOrderTest(String orderId,DeliverConsigneeInfoDto deliverInfoDto,DeliverConsigneeInfoDto consigneeInfoDto) throws Exception {
		AppInfo appInfo = genAppInfo();

		MessageReq<OrderReqDto> req = new MessageReq<OrderReqDto>();
		HeadMessageReq head = new HeadMessageReq();
		head.setTransType(SFConstant.HEAD_TRANSTYPE_200);
		head.setTransMessageId(SFTool.genTransMessageId());
		req.setHead(head);

		OrderReqDto orderReqDto = new OrderReqDto();

		orderReqDto.setOrderId(orderId);
		// 顺丰特惠
		orderReqDto.setExpressType(new Short("2"));
		// 寄方付/寄付月结【默认值】
		orderReqDto.setPayMethod(new Short("1"));
		// 是否需要签回单号（0：否；1：是）
		orderReqDto.setNeedReturnTrackingNo(new Short("0"));
		// 是否下call（通知收派员上门取件）（0：否；1：是）
		orderReqDto.setIsDoCall(new Short("1"));
		// 是否申请运单号（0：否；1：是）
		orderReqDto.setIsGenBillNo(new Short("1"));
		// 顺丰月结卡号；寄付现结，下单不需要传custId字段
		// orderReqDto.setCustId("7550010173");
		// 月结卡号对应的网点，如果付款方式为第三方支付，则必填
		// orderReqDto.setPayArea("755CQ");
		// 要求上门取件开始时间，格式：YYYY-MM-DD HH24:MM:SS，示例：2013-7-30 09:30:00，
		// 默认值为系统收到订单的系统时间
		// orderReqDto.setSendStartTime("2014-4-24 09:30:00");
		// 备注，最大长度30个汉字
		// orderReqDto.setRemark("易碎物品，小心轻放");

//		// 寄件方信息
//		DeliverConsigneeInfoDto deliverInfoDto = new DeliverConsigneeInfoDto();
//		deliverInfoDto.setAddress("上地");
//		deliverInfoDto.setCity("朝阳");
//		deliverInfoDto.setCompany("京东");
//		deliverInfoDto.setContact("李四");
//		deliverInfoDto.setCountry("中国");
//		deliverInfoDto.setProvince("北京");
//		deliverInfoDto.setShipperCode("787564");
//		deliverInfoDto.setTel("010-95123669");
//		deliverInfoDto.setMobile("13612822894");
//
//		// 收件方信息
//		DeliverConsigneeInfoDto consigneeInfoDto = new DeliverConsigneeInfoDto();
//		consigneeInfoDto.setCompany("顺丰");
//		consigneeInfoDto.setContact("张三");
//		consigneeInfoDto.setTel("0755-33915561");
//		consigneeInfoDto.setMobile("18588413321");
//		consigneeInfoDto.setCountry("中国");
//		consigneeInfoDto.setProvince("广东");
//		consigneeInfoDto.setCity("深圳");
//		consigneeInfoDto.setAddress("世界第一广场");
//		consigneeInfoDto.setShipperCode("518100");

		// 货物信息
		CargoInfoDto cargoInfoDto = new CargoInfoDto();
		cargoInfoDto.setParcelQuantity(1);// 包裹数
		cargoInfoDto.setCargo("文件");// 货物名称

		orderReqDto.setDeliverInfo(deliverInfoDto);
		orderReqDto.setConsigneeInfo(consigneeInfoDto);
		orderReqDto.setCargoInfo(cargoInfoDto);

		req.setBody(orderReqDto);

		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put("sf_appid", appInfo.getAppId());
		paramMap.put("sf_appkey", appInfo.getAppKey());
		paramMap.put("access_token", appInfo.getAccessToken());

		MessageResp<OrderRespDto> rs = OrderTools.order(SFConstant.URL_ORDER,
				appInfo, req);
		System.out.println("ok!"+rs);

	}
	public static void genOrderQuery(String orderId) throws Exception {
		AppInfo appInfo = genAppInfo();

		MessageReq<OrderQueryReqDto> req = new MessageReq<OrderQueryReqDto>();
		HeadMessageReq head = new HeadMessageReq();
		head.setTransType(SFConstant.HEAD_TRANSTYPE_203);
		head.setTransMessageId(SFTool.genTransMessageId());
		req.setHead(head);

		OrderQueryReqDto orderQueryReqDto = new OrderQueryReqDto();
		orderQueryReqDto.setOrderId(orderId);

		req.setBody(orderQueryReqDto);

		MessageResp<OrderQueryRespDto> rs = OrderTools.orderQuery(
				SFConstant.URL_ORDER_QUERY, appInfo, req);
		System.out.println(rs);

	}

	public static void genOrderFilter(String orderId) throws Exception {
		AppInfo appInfo = genAppInfo();

		MessageReq<OrderFilterReqDto> req = new MessageReq<OrderFilterReqDto>();
		HeadMessageReq head = new HeadMessageReq();
		head.setTransType(SFConstant.HEAD_TRANSTYPE_204);
		head.setTransMessageId(SFTool.genTransMessageId());
		req.setHead(head);

		OrderFilterReqDto orderFilterReqDto = new OrderFilterReqDto();
		orderFilterReqDto.setFilterType(1);
		orderFilterReqDto.setOrderId(orderId);
		orderFilterReqDto.setConsigneeCountry("中国");
		orderFilterReqDto.setConsigneeProvince("广东");
		orderFilterReqDto.setConsigneeCity("深圳");
		orderFilterReqDto.setConsigneeCounty("福田");
		orderFilterReqDto.setConsigneeAddress("世界第一广场");

		req.setBody(orderFilterReqDto);

		MessageResp<OrderFilterRespDto> rs = OrderTools.filterOrder(
				SFConstant.URL_ORDER_FILTER, appInfo, req);
		System.out.println(rs);

	}

	public static void genRouteQuery(String orderId) throws Exception {
		AppInfo appInfo = genAppInfo();

		MessageReq<RouteReqDto> req = new MessageReq<RouteReqDto>();
		HeadMessageReq head = new HeadMessageReq();
		head.setTransType(SFConstant.HEAD_TRANSTYPE_501);
		head.setTransMessageId(SFTool.genTransMessageId());
		req.setHead(head);

		RouteReqDto routeReqDto = new RouteReqDto();
		// 查询类别，1：运单号；2：订单号
		routeReqDto.setTrackingType(2);
		routeReqDto.setTrackingNumber(orderId);
		routeReqDto.setMethodType(1);

		req.setBody(routeReqDto);

		MessageResp<List<RouteRespDto>> rs = RouteTools.routeQuery(
				SFConstant.URL_ROUTE_QUERY, appInfo, req);
		System.out.println(rs);

	}

	public static void genRouteIncQuery(String orderId) throws Exception {
		AppInfo appInfo = genAppInfo();

		MessageReq<RouteIncReqDto> req = new MessageReq<RouteIncReqDto>();
		HeadMessageReq head = new HeadMessageReq();
		head.setTransType(SFConstant.HEAD_TRANSTYPE_504);
		head.setTransMessageId(SFTool.genTransMessageId());
		req.setHead(head);

		RouteIncReqDto routeReqDto = new RouteIncReqDto();
		routeReqDto.setOrderId(orderId);

		req.setBody(routeReqDto);

		MessageResp<List<RouteIncRespDto>> rs = RouteTools.routeIncQuery(
				SFConstant.URL_ROUTE_INC_QUERY, appInfo, req);
		System.out.println(rs);

	}

	public static void genWaybillImage(String orderId) throws Exception {
		AppInfo appInfo = genAppInfo();

		MessageReq<WaybillReqDto> req = new MessageReq<WaybillReqDto>();
		HeadMessageReq head = new HeadMessageReq();
		head.setTransType(SFConstant.HEAD_TRANSTYPE_205);
		head.setTransMessageId(SFTool.genTransMessageId());
		req.setHead(head);

		WaybillReqDto waybillReqDto = new WaybillReqDto();
		waybillReqDto.setOrderId(orderId);

		req.setBody(waybillReqDto);

		MessageResp<WaybillRespDto> rs = WaybillDownloadTools.waybillDownload(
				SFConstant.URL_WAYBILL_IMAGE, appInfo, req);
		System.out.println(rs);

	}

	public static void main(String[] args) throws Exception {
		// SFTool.genAccessToken();
		// SFTool.genOrder("test008");
		// SFTool.genOrderQuery("test008");
		// SFTool.genOrderFilter("test008");
		// SFTool.genRouteQuery("test008");
		// SFTool.genRouteIncQuery("test008");
		SFTool.genWaybillImage("test008");
	}

}
