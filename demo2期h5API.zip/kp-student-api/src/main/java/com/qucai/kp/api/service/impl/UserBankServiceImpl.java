package com.qucai.kp.api.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageHelper;
import com.qucai.kp.api.dao.UserBankDao;
import com.qucai.kp.api.service.UserBankService;
import com.qucai.kp.common.pager.PageParam;
import com.qucai.kp.entity.UserBank;

@Service
@Transactional
public class UserBankServiceImpl implements UserBankService {

    @Autowired
    private UserBankDao userBankDao;

	@Override
	public int deleteByPrimaryKey(String id) {
		return userBankDao.deleteByPrimaryKey(id);
	}

	@Override
	public int insertSelective(UserBank record) {
		return userBankDao.insertSelective(record);
	}

	@Override
	public UserBank selectByPrimaryKey(String id) {
		return userBankDao.selectByPrimaryKey(id);
	}

	@Override
	public int updateByPrimaryKeySelective(UserBank record) {
		return userBankDao.updateByPrimaryKeySelective(record);
	}

	@Override
	public List<UserBank> findAllList(Map<String, Object> paramMap,PageParam pp) {
		if(pp.getPageNum()!=-1)
			PageHelper.startPage(pp.getPageNum(), pp.getPageSize());
		return userBankDao.findAllList(paramMap);
	}
	
	@Override
    public int updateIsDefaultByUserId(String userId, Integer isDefault) {
        UserBank bank = new UserBank();
        bank.setUserId(userId);
        bank.setIsdefault(isDefault);
        return userBankDao.updateIsDefaultByUserId(bank);
    }

	@Override
	public int updateIsDefaultByCreator(String creator) {
		// TODO Auto-generated method stub
		return userBankDao.updateIsDefaultByCreator(creator);
	}
}