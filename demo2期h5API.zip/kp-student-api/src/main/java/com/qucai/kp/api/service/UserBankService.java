package com.qucai.kp.api.service;

import java.util.List;
import java.util.Map;

import com.qucai.kp.common.pager.PageParam;
import com.qucai.kp.entity.UserBank;

public interface UserBankService {
	int deleteByPrimaryKey(String id);

	int insertSelective(UserBank record);

	UserBank selectByPrimaryKey(String id);

	int updateByPrimaryKeySelective(UserBank record);

	// 根据用户userId查询所有银行卡信息
	List<UserBank> findAllList(Map<String, Object> paramMap,PageParam pp);
	
	/**
	 * 根据用户id更新所有银行卡的默认状态
	 * @param userId
	 * @return
	 */
	int updateIsDefaultByUserId(String userId, Integer isDefault);
	
	int updateIsDefaultByCreator(String creator);
}
