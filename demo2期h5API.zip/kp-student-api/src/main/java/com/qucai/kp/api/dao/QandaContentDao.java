package com.qucai.kp.api.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.qucai.kp.entity.QandaContent;

@Repository
public interface QandaContentDao {
    int deleteByPrimaryKey(String id);

    // 插入咨询内容
    int insertSelective(QandaContent record);

    QandaContent selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(QandaContent record);

	// 根据主题id查询咨询内容信息
    List<QandaContent> findContentListByTopicId(String topicId);
}