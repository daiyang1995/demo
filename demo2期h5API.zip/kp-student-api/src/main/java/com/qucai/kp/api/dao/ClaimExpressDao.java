package com.qucai.kp.api.dao;

import org.springframework.stereotype.Repository;

import com.qucai.kp.entity.ClaimExpress;
@Repository
public interface ClaimExpressDao {
    int deleteByPrimaryKey(String id);

    int insertSelective(ClaimExpress record);

    ClaimExpress selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(ClaimExpress record);
}