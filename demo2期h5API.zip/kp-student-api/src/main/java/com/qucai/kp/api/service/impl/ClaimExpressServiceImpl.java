package com.qucai.kp.api.service.impl;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.qucai.kp.api.dao.ClaimApplyDao;
import com.qucai.kp.api.dao.ClaimExpressDao;
import com.qucai.kp.api.dao.ClaimLogDao;
import com.qucai.kp.api.kd100.SubscribeReq;
import com.qucai.kp.api.kd100.SubscribeUtil;
import com.qucai.kp.api.service.ClaimExpressService;
import com.qucai.kp.api.tool.Tool;
import com.qucai.kp.api.vo.ClaimApplyVo;
import com.qucai.kp.entity.ClaimApply;
import com.qucai.kp.entity.ClaimExpress;
import com.qucai.kp.entity.ClaimLog;

@Service
@Transactional
public class ClaimExpressServiceImpl implements ClaimExpressService {
	@Autowired
	private ClaimExpressDao claimExpressDao;

	@Autowired
	private ClaimLogDao claimLogDao;
	
	@Autowired
	private ClaimApplyDao claimApplyDao;
	
	@Override
	public int deleteByPrimaryKey(String id) {
		return claimExpressDao.deleteByPrimaryKey(id);
	}

	@Override
	public int insertSelective(ClaimExpress record) {
		
		// 快递交件，向快递100发起订阅
		if(0 == record.getSubmitType()) {
			// 构造基本订阅请求类
			SubscribeReq req = new SubscribeReq();
			req.setNumber(record.getTrackingNo());
			// 订阅快递100
			req.setCompany(record.getCarrier());
			SubscribeUtil.publishSubscribe(req);
			// 保存处理后的快递信息
//			record.setId(Tool.uuid());
//			record.setCarrier(record.getCarrier());
//			claimExpressDao.insertSelective(record);
					
			// 记录日志
			ClaimLog claimLog = new ClaimLog();
			claimLog.setId(Tool.uuid());
			claimLog.setClaimId(record.getClaimApplyId());
			claimLog.setRemark("物理件已提交");
			claimLog.setMainBody("快递交件，快递单号：" + record.getTrackingNo());
			claimLog.setCreateTime(new Date());
			claimLog.setCreator("-1");
			claimLogDao.insertSelective(claimLog);
				
		}else if (2 ==  record.getSubmitType()){
			// 记录日志
			ClaimLog claimLog = new ClaimLog();
			claimLog.setId(record.getId());
			claimLog.setClaimId(record.getClaimApplyId());
			claimLog.setRemark("物理件已提交");
			claimLog.setMainBody("预约收件");
			claimLog.setCreateTime(new Date());
			claimLog.setCreator("-1");
			claimLogDao.insertSelective(claimLog);
		}
			
		else{
//			record.setId(Tool.uuid());
//			claimExpressDao.insertSelective(record);
			// 记录日志
			ClaimLog claimLog = new ClaimLog();
			claimLog.setId(Tool.uuid());
			claimLog.setClaimId(record.getClaimApplyId());
			claimLog.setRemark("物理件已提交");
			claimLog.setMainBody("自行交件");
			claimLog.setCreateTime(new Date());
			claimLog.setCreator("-1");
			claimLogDao.insertSelective(claimLog);
		}
				
		// 更新物理件提交状态为：已提交
		ClaimApply claimApply = new ClaimApply();
		claimApply.setFileRecieveStatus(1);
		claimApply.setId(record.getClaimApplyId());
		claimApplyDao.updateByPrimaryKeySelective(claimApply);
				
		return claimExpressDao.insertSelective(record);
	}

	@Override
	public ClaimExpress selectByPrimaryKey(String id) {
		return claimExpressDao.selectByPrimaryKey(id);
	}

	@Override
	public int updateByPrimaryKeySelective(ClaimExpress record) {
		return claimExpressDao.updateByPrimaryKeySelective(record);
	}

}