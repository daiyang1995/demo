package com.qucai.kp.api.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.qucai.kp.api.dao.PlanImageVerifyRuleDao;
import com.qucai.kp.api.service.PlanImageVerifyRuleService;
import com.qucai.kp.api.vo.RuleVo;
import com.qucai.kp.entity.PlanImageVerifyRule;

@Service
@Transactional
public class PlanImageVerifyRuleServiceImpl implements  PlanImageVerifyRuleService {

	@Autowired
	private PlanImageVerifyRuleDao planImageVerifyRuleService;
	
	@Override
	public int deleteByPrimaryKey(String id) {
		return planImageVerifyRuleService.deleteByPrimaryKey(id);
	}

	@Override
	public int insertSelective(PlanImageVerifyRule record) {
		return planImageVerifyRuleService.insertSelective(record);
	}

	@Override
	public PlanImageVerifyRule selectByPrimaryKey(String id) {
		return planImageVerifyRuleService.selectByPrimaryKey(id);
	}

	@Override
	public int updateByPrimaryKeySelective(PlanImageVerifyRule record) {
		return planImageVerifyRuleService.updateByPrimaryKeySelective(record);
	}

	@Override
	public PlanImageVerifyRule findRule(Map<String, Object> paramMap) {
		return planImageVerifyRuleService.findRule(paramMap);
	}

	@Override
	public List<RuleVo> findRuleVo(Map<String, Object> paramMap) {
		return planImageVerifyRuleService.findRuleVo(paramMap);
	}
  
}