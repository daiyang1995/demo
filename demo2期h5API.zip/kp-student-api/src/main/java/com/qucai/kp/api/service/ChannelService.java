package com.qucai.kp.api.service;

import java.util.List;
import java.util.Map;

import com.qucai.kp.entity.Channel;
public interface ChannelService {
    int deleteByPrimaryKey(String id);

    int insertSelective(Channel record);

    Channel selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(Channel record);
    
    List<Channel> findAllList(Map<String,Object> paMap);
}