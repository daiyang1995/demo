package com.qucai.kp.api.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.qucai.kp.api.dao.ClaimLogDao;
import com.qucai.kp.api.service.ClaimLogService;
import com.qucai.kp.entity.ClaimLog;
@Service
@Transactional
public class ClaimLogServiceImpl implements ClaimLogService {
	@Autowired
	private ClaimLogDao claimLogDao;
	
	@Override
	public int deleteByPrimaryKey(String id) {
		return claimLogDao.deleteByPrimaryKey(id);
	}

	@Override
	public int insertSelective(ClaimLog record) {
		return claimLogDao.insertSelective(record);
	}

	@Override
	public ClaimLog selectByPrimaryKey(String id) {
		return claimLogDao.selectByPrimaryKey(id);
	}

	@Override
	public int updateByPrimaryKeySelective(ClaimLog record) {
		return claimLogDao.updateByPrimaryKeySelective(record);
	}

	@Override
	public List<ClaimLog> findClaimLogListByClaimId(String id) {
		return claimLogDao.findClaimLogListByClaimId(id);
	}
    
}