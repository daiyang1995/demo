package com.qucai.kp.api.service;

import java.util.List;
import java.util.Map;

import com.qucai.kp.entity.Area;

public interface AreaService {

	List<Area> findAllList(Map<String, Object> paramMap);

}