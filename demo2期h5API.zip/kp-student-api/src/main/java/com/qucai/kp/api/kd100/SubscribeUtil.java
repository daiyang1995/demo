package com.qucai.kp.api.kd100;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.qucai.kp.common.context.SysInfo;
import com.qucai.kp.common.tool.HttpTool;
import com.qucai.kp.common.tool.JsonTool;

public class SubscribeUtil {
	
	private static Logger logger = LoggerFactory
			.getLogger(SubscribeUtil.class);

	public static void publishSubscribeAuto(SubscribeReq req) {
		List<String> companyList = new ArrayList<String>();
		
		if("other".equals(req.getCompany())) {
			companyList.addAll(autoCheckCarrier(req.getNumber()));
		} else {
			companyList.add(req.getCompany());
		}
		for(String company : companyList) {
			req.setCompany(company);
			publishSubscribe(req);
		}
	}
	
	public static void publishSubscribe(SubscribeReq req) {
		req.setKey(SysInfo.CONFIG.get("KD100_KEY"));
		req.getParameters().put("callbackurl",
				SysInfo.CONFIG.get("KD100_CALLBACK_URL"));
		HashMap<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("schema", "json");
		paramMap.put("param", JsonTool.genByFastJson(req));
		String ret = HttpTool.callApiByPost(false,
				SysInfo.CONFIG.get("KD100_SUBSCRIBE_URL"), paramMap);
		SubscribeResp ssr = JsonTool.resolveByFastJson(new TypeReference<SubscribeResp>() {
		}, ret);
		
		logger.info("向快递100推送订阅---单号:{},公司:{},推送结果:{}--{}",req.getNumber(), req.getCompany(), ssr.getResult(), ssr.getMessage());
	}
	
	public static List<String> autoCheckCarrier(String trackingNo) {
		List<String> companyList = new ArrayList<String>();
		String url = "http://www.kuaidi100.com/autonumber/auto?num=" + trackingNo + "&key=" + SysInfo.CONFIG.get("KD100_KEY");
		String jsonArrayStr = HttpTool.callApiByGet(false, url);
		List<Map<String, Object>> carrierList = JSON.parseObject(jsonArrayStr, 
				new TypeReference<List<Map<String, Object>>>() {});
		for(Map<String, Object> m : carrierList) {
			companyList.add(String.valueOf(m.get("comCode")));
		}
		return companyList;
	}
	
}
