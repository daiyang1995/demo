package com.qucai.kp.api.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.qucai.kp.entity.Dict;

@Repository
public interface DictDao {
    
    List<Dict> findAllList(Map<String, Object> paramMap);

    List<Dict> findDictAllList(Map<String, Object> paramMap);
}