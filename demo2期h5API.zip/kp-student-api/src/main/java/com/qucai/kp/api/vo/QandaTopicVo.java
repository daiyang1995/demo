package com.qucai.kp.api.vo;
/**
 * api-咨询实体类vo
 */
import com.qucai.kp.entity.QandaTopic;

public class QandaTopicVo extends QandaTopic {


	/**
	 * 咨询类型描述
	 */
	private String typeStr;

	/**
	 * 咨询类型子项描述
	 */
	private String subitemStr;

	public String getTypeStr() {
		return typeStr;
	}

	public void setTypeStr(String typeStr) {
		this.typeStr = typeStr;
	}

	public String getSubitemStr() {
		return subitemStr;
	}

	public void setSubitemStr(String subitemStr) {
		this.subitemStr = subitemStr;
	}
	
	
}
