package com.qucai.kp.api.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageHelper;
import com.qucai.kp.api.dao.PlanAddressDao;
import com.qucai.kp.api.service.PlanAddressService;
import com.qucai.kp.common.pager.PageParam;
import com.qucai.kp.entity.PlanAddress;
@Service
@Transactional
public class PlanAddressServiceImpl  implements PlanAddressService {
	 @Autowired
	    private PlanAddressDao planAddressDao;
	
	@Override
	public int deleteByPrimaryKey(String id) {
		return planAddressDao.deleteByPrimaryKey(id);
	}

	@Override
	public int insertSelective(PlanAddress record) {
		return planAddressDao.insertSelective(record);
	}

	@Override
	public PlanAddress selectByPrimaryKey(String id) {
		return planAddressDao.selectByPrimaryKey(id);
	}

	@Override
	public int updateByPrimaryKeySelective(PlanAddress record) {
		return planAddressDao.updateByPrimaryKeySelective(record);
	}

	@Override
	public List<PlanAddress> findPlanAddressVoList(Map<String, Object> paramMap,PageParam pp) {
			if(pp.getPageNum()!=-1)
				PageHelper.startPage(pp.getPageNum(), pp.getPageSize());
		return planAddressDao.findPlanAddressVoList(paramMap);
	}
    
    
}