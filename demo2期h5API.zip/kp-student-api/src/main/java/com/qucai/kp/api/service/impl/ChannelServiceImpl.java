package com.qucai.kp.api.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.qucai.kp.api.dao.ChannelDao;
import com.qucai.kp.api.service.ChannelService;
import com.qucai.kp.entity.Channel;
@Service
@Transactional
public class ChannelServiceImpl implements ChannelService {
	@Autowired
	private ChannelDao channelDao;

	@Override
	public int deleteByPrimaryKey(String id) {
		return channelDao.deleteByPrimaryKey(id);
	}

	@Override
	public int insertSelective(Channel record) {
		return channelDao.insertSelective(record);
	}

	@Override
	public Channel selectByPrimaryKey(String id) {
		return channelDao.selectByPrimaryKey(id);
	}

	@Override
	public int updateByPrimaryKeySelective(Channel record) {
		return channelDao.updateByPrimaryKeySelective(record);
	}

	@Override
	public List<Channel> findAllList(Map<String, Object> paMap) {
		return channelDao.findAllList(paMap);
	}
}