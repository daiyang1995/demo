package com.qucai.kp.express.sf;

public class SFConstant {
	
	/**
	 * redis中存放accessToken的key
	 */
	public static final String SF_ACCESS_TOKEN = "SF_ACCESS_TOKEN";
	/**
	 * 生产域名
	 */
	public static final String DOMAIN_PRD = "https://open-prod.sf-express.com";
	/**
	 * 沙盒域名
	 */
	public static final String DOMAIN_SANDBOX = "https://open-sbox.sf-express.com";
	/**
	 * 调用域名
	 */
	public static final String DOMAIN = DOMAIN_SANDBOX;
	/**
	 * api版本
	 */
	public static final String VERSION = "v1.0";
	/**
	 * 免授权API（适用于安全类接口）
	 */
	public static final String TYPE_PUBLIC = "public";
	/**
	 * 授权类API（适用于非安全类的所有接口）
	 */
	public static final String TYPE_REST = "rest";
	/**
	 * 授权类API的Query_String
	 */
	public static final String QUERY_STRING_BY_REST = "access_token/{access_token}/sf_appid/{sf_appid}/sf_appkey/{sf_appkey}";

	/**
	 * 快速下单
	 */
	public static final String QUERY_STRING_ORDER = "/order/" + QUERY_STRING_BY_REST;
	
	public static final String URL_ORDER = DOMAIN + "/" + TYPE_REST + "/" + VERSION + QUERY_STRING_ORDER;
	/**
	 * 订单查询
	 */
	public static final String QUERY_STRING_ORDER_QUERY = "/order/query/" + QUERY_STRING_BY_REST;
	
	public static final String URL_ORDER_QUERY = DOMAIN + "/" + TYPE_REST + "/" + VERSION + QUERY_STRING_ORDER_QUERY;
	/**
	 * 订单筛选
	 */
	public static final String QUERY_STRING_ORDER_FILTER = "/filter/" + QUERY_STRING_BY_REST;
	
	public static final String URL_ORDER_FILTER = DOMAIN + "/" + TYPE_REST + "/" + VERSION + QUERY_STRING_ORDER_FILTER;
	/**
	 * 路由查询
	 */
	public static final String QUERY_STRING_ROUTE_QUERY = "/route/query/" + QUERY_STRING_BY_REST;
	
	public static final String URL_ROUTE_QUERY = DOMAIN + "/" + TYPE_REST + "/" + VERSION + QUERY_STRING_ROUTE_QUERY;
	/**
	 * 路由增量查询
	 */
	public static final String QUERY_STRING_ROUTE_INC_QUERY = "/route/inc/query/" + QUERY_STRING_BY_REST;
	
	public static final String URL_ROUTE_INC_QUERY = DOMAIN + "/" + TYPE_REST + "/" + VERSION + QUERY_STRING_ROUTE_INC_QUERY;
	/**
	 * 电子运单图片下载
	 */
	public static final String QUERY_STRING_WAYBILL_IMAGE = "/waybill/image/" + QUERY_STRING_BY_REST;
	
	public static final String URL_WAYBILL_IMAGE = DOMAIN + "/" + TYPE_REST + "/" + VERSION + QUERY_STRING_WAYBILL_IMAGE;
	/**
	 * 基础服务查询
	 */
	public static final String QUERY_STRING_PRODUCT_BASIC_QUERY = "/product/basic/query/";
	/**
	 * 附加服务查询
	 */
	public static final String QUERY_STRING_PRODUCT_ADDITIONAL_QUERY = "/product/additional/query/";
	/**
	 * 申请访问令牌，默认时效为一个小时
	 */
	public static final String QUERY_STRING_SECURITY_ACCESS_TOKEN = "/security/access_token/sf_appid/{sf_appid}/sf_appkey/{sf_appkey}";
	
	public static final String URL_SECURITY_ACCESS_TOKEN = DOMAIN + "/" + TYPE_PUBLIC + "/" + VERSION + QUERY_STRING_SECURITY_ACCESS_TOKEN;
	/**
	 * 查询访问令牌
	 */
	public static final String QUERY_STRING_SECURITY_ACCESS_TOKEN_QUERY = "/security/access_token/query/";
	/**
	 * 刷新访问令牌
	 */
	public static final String QUERY_STRING_SECURITY_REFRESH_TOKEN = "/security/refresh_token/";

	/**
	 * 快速下单
	 */
	public static final int HEAD_TRANSTYPE_200 = 200;
	/**
	 * 订单结果通知
	 */
	public static final int HEAD_TRANSTYPE_201 = 201;
	
	/**
	 * 订单结果通知（响应）
	 */
	public static final int HEAD_TRANSTYPE_4201 = 4201;
	/**
	 * 订单查询
	 */
	public static final int HEAD_TRANSTYPE_203 = 203;
	/**
	 * 订单筛选
	 */
	public static final int HEAD_TRANSTYPE_204 = 204;
	/**
	 * 电子运单图片下载
	 */
	public static final int HEAD_TRANSTYPE_205 = 205;
	/**
	 * 基础服务查询
	 */
	public static final int HEAD_TRANSTYPE_250 = 250;
	/**
	 * 附加服务查询
	 */
	public static final int HEAD_TRANSTYPE_251 = 251;
	/**
	 * 路由推送
	 */
	public static final int HEAD_TRANSTYPE_500 = 500;
	/**
	 * 路由推送（响应）
	 */
	public static final int HEAD_TRANSTYPE_4500 = 4500;
	/**
	 * 路由查询
	 */
	public static final int HEAD_TRANSTYPE_501 = 501;
	/**
	 * 路由增量查询
	 */
	public static final int HEAD_TRANSTYPE_504 = 504;
	/**
	 * 查询ACCESS_TOKEN
	 */
	public static final int HEAD_TRANSTYPE_300 = 300;
	/**
	 * 申请ACCESS_TOKEN
	 */
	public static final int HEAD_TRANSTYPE_301 = 301;
	/**
	 * 刷新ACCESS_TOKEN
	 */
	public static final int HEAD_TRANSTYPE_302 = 302;
	
	/**
	 * 标准快递
	 */
	public static final short EXPRESS_TYPE_1 = 1;
	/**
	 * 顺丰特惠
	 */
	public static final short EXPRESS_TYPE_2 = 2;
	/**
	 * 电商特惠
	 */
	public static final short EXPRESS_TYPE_3 = 3;
	/**
	 * 顺丰次晨
	 */
	public static final short EXPRESS_TYPE_5 = 5;
	/**
	 * 顺丰即日
	 */
	public static final short EXPRESS_TYPE_6 = 6;
	/**
	 * 电商速配
	 */
	public static final short EXPRESS_TYPE_7 = 7;
	/**
	 * 生鲜速配
	 */
	public static final short EXPRESS_TYPE_15 = 15;
	
}
