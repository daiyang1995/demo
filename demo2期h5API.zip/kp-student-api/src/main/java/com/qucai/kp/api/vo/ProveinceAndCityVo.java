package com.qucai.kp.api.vo;

public class ProveinceAndCityVo {

	/**
	 * 省
	 */
	private String proveince;
	/**
	 * 市
	 */
	private String city;
	
	public String getProveince() {
		return proveince;
	}
	public void setProveince(String proveince) {
		this.proveince = proveince;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	
	
}
