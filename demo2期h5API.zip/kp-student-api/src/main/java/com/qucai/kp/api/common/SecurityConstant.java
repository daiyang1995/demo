package com.qucai.kp.api.common;


public class SecurityConstant {

    public static final String REQUEST_METHOD_POST = "POST";
    public static final String CHANNEL_ANDROID = "0";
    public static final String CHANNEL_IOS = "1";
    public static final String CHANNEL_WX = "2";
    public static final String CHANNEL_M_SITE = "3";
    public static final String CHANNEL_WEB = "4";
    
    /**
     * 采用数据库存储token的方式
     */
    @Deprecated
    public static final String TOKEN_TYPE_APP = "app";
    /**
     * 采用数据库存储token的方式
     */
    @Deprecated
    public static final String TOKEN_TYPE_M_SITE = "m_site";
    /**
     * 采用数据库存储token的方式
     */
    @Deprecated
    public static final String TOKEN_TYPE_WEB = "web";
    
}
