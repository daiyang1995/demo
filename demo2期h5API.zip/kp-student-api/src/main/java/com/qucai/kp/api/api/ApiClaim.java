package com.qucai.kp.api.api;

/**
 * api-理赔
 */
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.qucai.kp.api.common.ExRetEnum;
import com.qucai.kp.api.service.ClaimApplyService;
import com.qucai.kp.api.service.ClaimAttachService;
import com.qucai.kp.api.service.ClaimExpressService;
import com.qucai.kp.api.service.ClaimLogService;
import com.qucai.kp.api.service.ClaimVerifyService;
import com.qucai.kp.api.service.PlanAddressService;
import com.qucai.kp.api.service.PlanImageVerifyRuleService;
import com.qucai.kp.api.tool.FastJsonTool;
import com.qucai.kp.api.tool.Tool;
import com.qucai.kp.api.vo.ApprovedInfo;
import com.qucai.kp.api.vo.ClaimApplyVo;
import com.qucai.kp.api.vo.ProveinceAndCityVo;
import com.qucai.kp.api.vo.RuleVo;
import com.qucai.kp.common.context.SysInfo;
import com.qucai.kp.common.pager.PageParam;
import com.qucai.kp.common.tool.AliTool;
import com.qucai.kp.common.tool.SerialNoTool;
import com.qucai.kp.entity.ClaimApply;
import com.qucai.kp.entity.ClaimAttach;
import com.qucai.kp.entity.ClaimExpress;
import com.qucai.kp.entity.ClaimLog;
import com.qucai.kp.entity.ClaimVerify;
import com.qucai.kp.entity.PlanAddress;
import com.qucai.kp.express.sf.SFTool;
import com.sf.openapi.express.sample.order.dto.DeliverConsigneeInfoDto;

@Controller
@RequestMapping(value = "/apiClaim")
public class ApiClaim {

	 @Autowired
	 private ClaimApplyService claimApplyService;

	 @Autowired
	 private ClaimAttachService claimAttachService;
	 
	 @Autowired
	 private ClaimLogService claimLogService;
	
	 @Autowired
	 private PlanAddressService planAddressService;
	 
	 @Autowired
	 private ClaimExpressService claimExpressService;
	 
	 @Autowired
	 private ClaimVerifyService claimVerifyService;
	 
	 @Autowired
	 private PlanImageVerifyRuleService planImageVerifyRuleService;
	
	/**
	 * 获取被保险人信息
	 * 
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/startClaim")
	@ResponseBody
	public String startClaim(HttpServletRequest request) throws Exception {
		Map<String, Object> rsMap = new HashMap<String, Object>();
		
		String policyNo = request.getParameter("policyNo");
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("policyNo", policyNo);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		List<ClaimApplyVo> policyList = claimApplyService.findPolicyList(paramMap);
		if (CollectionUtils.isNotEmpty(policyList)) {
			ClaimApplyVo po  = policyList.get(0);
			rsMap.put("policyOwnerName", po.getPolicyOwnerName());
			rsMap.put("startDate", sdf.format(po.getStartDate()));
			rsMap.put("endDate", sdf.format(po.getEndDate()));
			rsMap.put("policyId", po.getPolicyId());
		}else {
			return FastJsonTool.genJson(false, ExRetEnum.NO_MORE_DATA, rsMap);
		}
		return FastJsonTool.genJson(false, ExRetEnum.SUCCESS, rsMap);
	}
	 
	
	/**
	 * 得到影像规则
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/getExpression")
	@ResponseBody
	public String getExpression(HttpServletRequest request) throws Exception {
		Map<String, Object> rsMap = new HashMap<String, Object>();
		Map<String , Object> paramMap = new HashMap<String, Object>();
		if(request.getParameter("policyId")!=null){
			paramMap.put("policyId", request.getParameter("policyId"));
			paramMap.put("claimType", request.getParameter("type"));
		}else if(request.getParameter("claimId")!=null){
			ClaimApply cliaApply = claimApplyService.selectByPrimaryKey(request.getParameter("claimId"));
			paramMap.put("policyId",cliaApply.getPolicyId());
			paramMap.put("claimType",cliaApply.getClaimType());
		}
		List<RuleVo> lrv = planImageVerifyRuleService.findRuleVo(paramMap);
		for(RuleVo rv : lrv){
			rv.setDlabel(rv.getDlabel().replaceAll("\\(.+\\)", "").replaceAll("（.+）", ""));
		}
		
		rsMap.put("lrv", lrv);
		return FastJsonTool.genJson(false, ExRetEnum.SUCCESS, rsMap);
		
		
	}
//		Map<String, Object> rsMap = new HashMap<String, Object>();
//		Map<String , Object> paramMap = new HashMap<String, Object>();
//		if(request.getParameter("policyId")!=null){
//			paramMap.put("policyId", request.getParameter("policyId"));
//			paramMap.put("claimType", request.getParameter("type"));
//		}else if(request.getParameter("claimId")!=null){
//			ClaimApply cliaApply = claimApplyService.selectByPrimaryKey(request.getParameter("claimId"));
//			paramMap.put("policyId",cliaApply.getPolicyId());
//			paramMap.put("claimType",cliaApply.getClaimType());
//		}
//		PlanImageVerifyRule ctr = planImageVerifyRuleService.findRule(paramMap);
//		Map<String, String> cactMap = SysInfo.DICT_GROUP.get("claim_attach_content_type");
//		String expressionStr = ctr.getExpression();
//		expressionStr = expressionStr.replaceAll(" ", "").replaceAll("&&", "并且").replaceAll("\\|\\|", "或者");
//		String[] s = expressionStr.split("并且");
//		List<List<String>> lls = new ArrayList<List<String>>();
//		for(String st :s){
//			st = st.replaceAll("[\\(]","");
//			st = st.replaceAll("[\\)]", "");
//			String[] str = st.split("或者");
//			List<String> ls = Arrays.asList(str);
//			lls.add(ls);
//		}
////		String message ="";
//		List<Map<String,Object>> lms = new ArrayList<Map<String,Object>>();
//		for(List<String> ls1 : lls){
//			Map<String , Object > mso = new HashMap<String, Object>();
//			for(String sss : ls1){
//				for (String key : cactMap.keySet()) {
//					if(sss.equals("cact"+key)){
//						mso.put(key, cactMap.get(key));
//						break;
//					}
//				}
//			}
//			lms.add(mso);
//		}
//		rsMap.put("expressionStr", lms);
//		return FastJsonTool.genJson(false, ExRetEnum.SUCCESS, rsMap);
//	}
	 
	/**
	 * 我的理赔
	 * 
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/myClaimList")
	@ResponseBody
	public String myClaim(HttpServletRequest request) throws Exception {

		Map<String, Object> rsMap = new HashMap<String, Object>();
		List<Map<String, Object>> dataList = new ArrayList<Map<String, Object>>();

		String creator = request.getParameter("creator");
		String statusBig = request.getParameter("statusBig");
		PageParam pp = Tool.genPageParam(request);
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("creator", creator);
		paramMap.put("statusBig", statusBig);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		List<ClaimApplyVo> clList = claimApplyService.findClaimApplyVoMap(paramMap, pp);
		if (CollectionUtils.isNotEmpty(clList)) {
			for(ClaimApplyVo ca : clList){
				Map<String, Object> cmap = new HashMap<String, Object>();
				cmap.put("claimId", ca.getId());
				cmap.put("flowNo", ca.getClaimNo());
				cmap.put("policyOwnerName", ca.getPolicyOwnerName());
				cmap.put("applyDate", sdf.format(ca.getApplyDate()));
				cmap.put("status", ca.getStatus());
				cmap.put("statusStr", Tool.claimStatusStr(ca.getStatus()));
				cmap.put("statusBigStr", Tool.claimStatusBigStr(ca.getStatus()));
				
				cmap.put("FileRecieveStatus", ca.getFileRecieveStatus() );
				cmap.put("message",Tool.showMessage( ca.getStatus(),ca.getFileRecieveStatus()) );
				
				if(ca.getStatus() == 100 || ca.getStatus() == -1 || ca.getStatus() == 63){
					cmap.put("costDay", Tool.getDayBetween(ca.getCreateTime(), ca.getModifyTime())+1);
					
					ApprovedInfo approvedInfo = claimApplyService.findApprovedInfo(ca.getId());
					if(approvedInfo!=null){
//						String s =  approvedInfo.getApprovedMoney().toString();
//						if(s.indexOf(".")>0){
//							String s1 = s.substring(0, s.indexOf("."));
//							String s2 = s.substring(s.indexOf(".") ,s.indexOf(".")+3);
//							s=s1+s2;
//						}
//						else{
//							s=s+".00";
//						}
						if(approvedInfo.getApprovedMoney()!=null){
							if(approvedInfo.getUsedAllowMoney()!=null)
								cmap.put("approvedMoney", approvedInfo.getApprovedMoney().add(approvedInfo.getUsedAllowMoney()).toString()); 
							else{
								cmap.put("approvedMoney", approvedInfo.getApprovedMoney().toString()); 
							}
						}else{
							cmap.put("approvedMoney", null); 
						}
					}else{
						cmap.put("approvedMoney","--");
					}
				}else{
					cmap.put("costDay", Tool.getDayBetween(ca.getCreateTime(), new Date())+1);
					cmap.put("approvedMoney","--");
				}
				dataList.add(cmap);
//				ApprovedInfo approvedInfo = claimApplyService.findApprovedInfo(ca.getId());
//				 if(approvedInfo!=null){
//					 cmap.put("totalMoney", approvedInfo.getTotalMoney());
//					 cmap.put("refusedMoney", approvedInfo.getRefusedMoney());
//					 cmap.put("approvedMoney", approvedInfo.getApprovedMoney()); 
//				 }else{
//					 cmap.put("totalMoney", "--");
//					 cmap.put("refusedMoney","--");
//					 cmap.put("approvedMoney","--");
//				 }
			}
		}else {
			return FastJsonTool.genJson(false, ExRetEnum.NO_MORE_DATA, rsMap);
		}
		
		rsMap.put("claimApplyList", dataList);

		return FastJsonTool.genJson(false, ExRetEnum.SUCCESS, rsMap);
	}

	/**
	 * 理赔详情
	 * 
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/myClaimDetail")
	@ResponseBody
	public String myClaimDetail(HttpServletRequest request) throws Exception {
		Map<String, Object> rsMap = new HashMap<String, Object>();
		String claimId = request.getParameter("claimId");
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("claimId", claimId);
		PageParam pp = new PageParam();
		pp.setPageNum(-1);
		//标头内容
		List<ClaimApplyVo>  cav = claimApplyService.findClaimApplyVoMap(paramMap, pp);
		if(CollectionUtils.isNotEmpty(cav)){
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			ClaimApplyVo  ca =  cav.get(0);
			rsMap.put("claimId", claimId);
			 rsMap.put("flowNo", ca.getClaimNo());
			 rsMap.put("policyOwnerName", ca.getPolicyOwnerName());
			 rsMap.put("applyDate", sdf.format(ca.getApplyDate().getTime()));
			 rsMap.put("status", ca.getStatus());
			 rsMap.put("statusStr", Tool.claimStatusStr(ca.getStatus()));
			 rsMap.put("statusBigStr", Tool.claimStatusBigStr(ca.getStatus()));
			 rsMap.put("bankName", ca.getBankName());
			 rsMap.put("bankAccount", ca.getBankAccount());
			 rsMap.put("bankCard", ca.getBankCard());
			 if(63 == ca.getStatus() || -1 == ca.getStatus() || 100 == ca.getStatus()) {
				 rsMap.put("costDay", Tool.getDayBetween(ca.getCreateTime(),
						 ca.getModifyTime()) + 1);
			//赔付说明 
			//TODO
			ApprovedInfo approvedInfo = claimApplyService.findApprovedInfo(claimId);
				if(approvedInfo!=null){
					rsMap.put("totalMoney", approvedInfo.getTotalMoney());
					rsMap.put("refusedMoney", approvedInfo.getRefusedMoney());
					if(approvedInfo.getApprovedMoney()!=null&&approvedInfo.getUsedAllowMoney()!=null)
						rsMap.put("approvedMoney", approvedInfo.getApprovedMoney().add(approvedInfo.getUsedAllowMoney())); 
					else if(approvedInfo.getUsedAllowMoney()==null)
						rsMap.put("approvedMoney", approvedInfo.getApprovedMoney()); 
					 }
				 
			 } else {
				 rsMap.put("costDay", Tool.getDayBetween(ca.getCreateTime(), new
						 Date()) + 1);
			 }
			
//			//已提交过的影像件
//			List<Map<String, Object>> attachList = new ArrayList<Map<String, Object>>();
//			paramMap.put("idDel", 0);
//			 List<ClaimAttach> caList = claimAttachService.findAllList(paramMap);
//			 if (CollectionUtils.isNotEmpty(caList)) {
//				 for (ClaimAttach cat : caList) {
//					 Map<String, Object> cmap = new HashMap<String, Object>();
//					 cmap.put("attachId",  AliTool.getPrivateInstance().getAccessURL(cat.getId(),
//								"style/kp-student-claim-pic-upload-view"));
//					 String isClear1 ="";
//						if( cat.getIsClear()!=null){
//							if(cat.getIsClear() == 1){
//								isClear1 = "是";
//							}else{
//								isClear1 = "否" ;
//							}
//						}else{
//							isClear1 = "未审核";
//						}
//						String isMasterCopy1 = "";
//						if(cat.getIsMasterCopy()!=null){
//							if(cat.getIsMasterCopy() == 1){
//								isMasterCopy1 = "是";
//							}else{
//								isMasterCopy1 = "否" ;
//							}
//						}else{
//							isMasterCopy1 = "未审核";
//						}
//					 cmap.put("isClear", isClear1);
//					 cmap.put("isMasterCopy", isMasterCopy1);
//					 attachList.add(cmap);
//				 }
//			 }
//			 rsMap.put("attachList", attachList);
			 return FastJsonTool.genJson(false, ExRetEnum.SUCCESS, rsMap);
		}else{
			return FastJsonTool.genJson(false, ExRetEnum.CLAIM_NOT_EXIST_ERROR,rsMap);
		}
	}
	/**
	 * 已提交过的影像件
	 * 
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/getAttachList")
	@ResponseBody
	public String getAttachList(HttpServletRequest request) throws Exception {
		Map<String, Object> rsMap = new HashMap<String, Object>();
		List<Map<String, Object>> attachList = new ArrayList<Map<String, Object>>();
		Map<String, Object> paramMap = new HashMap<String, Object>();
		String claimId = request.getParameter("claimId");
		paramMap.put("claimId", claimId);
		paramMap.put("idDel", 0);
		 List<ClaimAttach> caList = claimAttachService.findAllList(paramMap);
		 if (CollectionUtils.isNotEmpty(caList)) {
			 for (ClaimAttach cat : caList) {
				 Map<String, Object> cmap = new HashMap<String, Object>();
				 cmap.put("attachId",  AliTool.getPrivateInstance().getAccessURL(cat.getId(),
							"style/kp-student-claim-pic-upload-view"));
				 String isClear1 ="";
					if( cat.getIsClear()!=null){
						if(cat.getIsClear() == 1){
							isClear1 = "是";
						}else{
							isClear1 = "否" ;
						}
					}else{
						isClear1 = "未审核";
					}
					String isMasterCopy1 = "";
					if(cat.getIsMasterCopy()!=null){
						if(cat.getIsMasterCopy() == 1){
							isMasterCopy1 = "是";
						}else{
							isMasterCopy1 = "否" ;
						}
					}else{
						isMasterCopy1 = "未审核";
					}
				 cmap.put("isClear", isClear1);
				 cmap.put("isMasterCopy", isMasterCopy1);
				 attachList.add(cmap);
			 }
		 }
		 rsMap.put("attachList", attachList);
		return FastJsonTool.genJson(false, ExRetEnum.CLAIM_NOT_EXIST_ERROR,rsMap);
	}
	/**
	 * 赔付进度（日程表）
	 * 
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/claimLog")
	@ResponseBody
	public String claimLog(HttpServletRequest request) throws Exception {
		Map<String, Object> rsMap = new HashMap<String, Object>();
		List<Map<String, Object>> dataList = new ArrayList<Map<String, Object>>();

		String claimId = request.getParameter("claimId");
		 // 根据理赔id查询赔付进度信息
		 List<ClaimLog> claimLogList = claimLogService.findClaimLogListByClaimId(claimId);
		 if (CollectionUtils.isNotEmpty(claimLogList)) {
			 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		 for (ClaimLog claimLog : claimLogList) {
			 Map<String, Object> cmap = new HashMap<String, Object>();
				 cmap.put("createTime", sdf.format(claimLog.getCreateTime().getTime()) );
				 cmap.put("remark", claimLog.getRemark());
				 cmap.put("mainBody", claimLog.getMainBody());
				 dataList.add(cmap);
			 }
		 }
		rsMap.put("claimLogList", dataList);

		return FastJsonTool.genJson(false, ExRetEnum.SUCCESS, rsMap);
	}

	/**
	 * 催款
	 * 
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/claimPress")
	@ResponseBody
	public String claimPress(HttpServletRequest request) throws Exception {
		String claimId = request.getParameter("claimId");
			//TODO
		return FastJsonTool.genJson(false, ExRetEnum.SUCCESS);
	}

	/**
	 * 发起理赔
	 * 
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/applyClaim")
	@ResponseBody
	public String applyClaim(HttpServletRequest request) throws Exception {
		
		Map<String, Object> rsMap = new HashMap<String, Object>();
		String policyId = request.getParameter("policyId");
		String claimType = request.getParameter("claimType");
		String applyDate = request.getParameter("applyDate");
		String bankName = request.getParameter("bankName");
		String bankAccount = request.getParameter("bankAccount");
		String bankCard = request.getParameter("bankCard");
		String applier = request.getParameter("applier");
		String mobile = request.getParameter("mobile");
		String email = request.getParameter("email");
		String creator = request.getParameter("creator");

		SimpleDateFormat dft = new SimpleDateFormat("yyyy-MM-dd");
		
		ClaimApply claimApply = new ClaimApply();
		claimApply.setId(Tool.uuid());
		claimApply.setClaimNo(SerialNoTool.claimFlowNo());// 流水号
		claimApply.setPolicyId(policyId); 
		claimApply.setClaimType(claimType);
		claimApply.setApplier(applier);
		claimApply.setMobile(mobile);
		claimApply.setEmail(email);
		claimApply.setBankName(bankName);
		claimApply.setBankAccount(bankAccount);
		claimApply.setBankCard(bankCard);
		claimApply.setApplyDate(dft.parse(applyDate));
		claimApply.setStatus(0);
		claimApply.setCreator(creator);// 创建人id
		claimApply.setCreateTime(new Date());// 创建日期
		
		claimApplyService.insertSelective(claimApply);
		switch (Integer.parseInt(claimType)) {
		case 10:
		case 20:
		case 50:
			ClaimVerify claimVerify = new ClaimVerify();
			claimVerify.setId(Tool.uuid());
			claimVerify.setClaimApplyId(claimApply.getId());
			claimVerify.setCreateTime(new Date());
			claimVerifyService.insertSelective(claimVerify);
			break;
		default:
			break;
		}
		
		
		rsMap.put("claimId", claimApply.getId());
		return FastJsonTool.genJson(false, ExRetEnum.SUCCESS, rsMap);
	}
	
	/**
	 * 辅助理赔
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/claimRemark")
	@ResponseBody
	public String claimRemark(HttpServletRequest request)
			throws Exception {
		Map<String, Object> rsMap = new HashMap<String, Object>();
		
		String cliamId = request.getParameter("cliamId");
		String remark = request.getParameter("remark");
		ClaimApply claimapply = new ClaimApply();
		
		claimapply.setRemark(remark);
		claimapply.setId(cliamId);
		claimapply.setStatus(10);
		claimApplyService.updateByPrimaryKeySelective(claimapply);
		
		ClaimApply  claimApply2 = claimApplyService.selectByPrimaryKey(cliamId); 
		
		ClaimLog claimLog = new ClaimLog();
		claimLog.setId(Tool.uuid());
		claimLog.setCreator(claimApply2.getCreator());
		claimLog.setCreateTime(new Date());
		claimLog.setClaimId(claimApply2.getId());
		claimLog.setRemark("发起理赔");
		claimLogService.insertSelective(claimLog);
		
		
		rsMap.put("claimNo", claimApply2.getClaimNo());
		return FastJsonTool.genJson(false, ExRetEnum.SUCCESS, rsMap);
	}
	/**
	 * 影像件理赔
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/applyClaimAttach")
	@ResponseBody
	public String applyclaimAttach(HttpServletRequest request)
			throws Exception {
		Map<String, Object> rsMap = new HashMap<String, Object>();
		
		ClaimAttach claimAttach = new ClaimAttach();
		
		claimAttach.setId(request.getParameter("fileName"));
		claimAttach.setClaimApplyId(request.getParameter("cliamId"));
		claimAttach.setCreator(request.getParameter("creator"));// 创建人id
		claimAttach.setCreateTime(new Date());// 创建日期
		claimAttach.setStatus(0);
		claimAttachService.insertSelective(claimAttach);
		
		return FastJsonTool.genJson(false, ExRetEnum.SUCCESS, rsMap);
		
	}
	/**
	 * 逻辑删除
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/applyClaimAttachDel")
	@ResponseBody
	public String applyClaimAttachDel(HttpServletRequest request)
			throws Exception {
		Map<String, Object> rsMap = new HashMap<String, Object>();
		ClaimAttach claimAttach = new ClaimAttach();
		claimAttach.setId(request.getParameter("Id"));
		claimAttach.setIsDel(1);
		claimAttachService.updateByPrimaryKeySelective(claimAttach);
		return FastJsonTool.genJson(false, ExRetEnum.SUCCESS, rsMap);
	}
	
	/**
	 * 影像件提交完成 提交接口
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/claimApplyAttachFinish")
	@ResponseBody
	public String applycClaimInfoById(HttpServletRequest request)
			throws Exception {
		Map<String, Object> rsMap = new HashMap<String, Object>();
		
		ClaimApply claimApply = claimApplyService.selectByPrimaryKey(request.getParameter("Id"));
		if(claimApply.getStatus()==11 || claimApply.getStatus() == 13 ){
				ClaimLog claimLog = new ClaimLog();
				claimLog.setId(Tool.uuid());
				claimLog.setCreator(request.getParameter("creator"));
				claimLog.setCreateTime(new Date());
				claimLog.setClaimId(request.getParameter("Id"));
				claimLog.setRemark("影像补充完成");
				claimLogService.insertSelective(claimLog);
			}else{
				ClaimLog claimLog = new ClaimLog();
				claimLog.setId(Tool.uuid());
				claimLog.setCreator(request.getParameter("creator"));
				claimLog.setCreateTime(new Date());
				claimLog.setClaimId(claimApply.getId());
				claimLog.setRemark("发起理赔");
				claimLogService.insertSelective(claimLog);
			}
		if(claimApply.getStatus()==11){
			ClaimApply record = new ClaimApply();
			record.setId(request.getParameter("Id"));
			record.setStatus(14);
			claimApplyService.updateByPrimaryKeySelective(record);
			
			ClaimVerify claimVerify1 = claimVerifyService.selectByClaimApplyId(record.getId());
			if(claimVerify1==null){
				ClaimVerify claimVerify = new ClaimVerify();
				claimVerify.setId(Tool.uuid());
				claimVerify.setClaimApplyId(record.getId());
				claimVerify.setCreateTime(new Date());
				claimVerifyService.insertSelective(claimVerify);
			}
		}else{
			ClaimApply record = new ClaimApply();
			record.setId(request.getParameter("Id"));
			record.setStatus(10);
			claimApplyService.updateByPrimaryKeySelective(record);
		}
			
			
		rsMap.put("claimNo", claimApply.getClaimNo());
		return FastJsonTool.genJson(false, ExRetEnum.SUCCESS, rsMap);
		
	}
	/**
	 * 补件 二审
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/claimVerifyRemark")
	@ResponseBody
	public String claimVerifyRemark(HttpServletRequest request)
			throws Exception {
		Map<String, Object> rsMap = new HashMap<String, Object>();
		String claimId = request.getParameter("claimId");
		//获取已上传过但未审核的图片
		Map<String,Object> mso = new HashMap<String, Object>();
		mso.put("idDel", 0);
		mso.put("unchecked", 0);
		mso.put("claimId", claimId);
		List<ClaimAttach> lca = claimAttachService.findAllList(mso);
		List<Map<String,Object>> lmso = new ArrayList<Map<String,Object>>();
		for(ClaimAttach ca :lca){
			Map<String,Object> mo = new HashMap<String, Object>();
			mo.put("name", ca.getId());
			mo.put("url", AliTool.getPrivateInstance().getAccessURL(ca.getId(),
				"style/kp-student-claim-pic-upload-view"));
			lmso.add(mo);
		}
		rsMap.put("lmso", lmso);
		//获取规则
		ClaimApply claimApply = claimApplyService.selectByPrimaryKey(claimId);
		if(claimApply!=null ){
			if(claimApply.getVerifyRemark()!=null && claimApply.getVerifyRemark()!=""){
				rsMap.put("VerifyRemark", claimApply.getVerifyRemark().replaceAll("\\(.+?\\)", "").replaceAll("（.+?）", ""));
				rsMap.put("type", 0); //不是第一次提交
			}else{  //二审通过第一次提交
				Map<String,Object> paramMap = new HashMap<String, Object>();
				paramMap.put("policyId",claimApply.getPolicyId());
				paramMap.put("claimType",claimApply.getClaimType());
				List<RuleVo> lrv = planImageVerifyRuleService.findRuleVo(paramMap);
				for(RuleVo rv : lrv){
					rv.setDlabel(rv.getDlabel().replaceAll("\\(.+\\)", "").replaceAll("（.+）", ""));
				}
				rsMap.put("type", 1); //是第一次提交
				rsMap.put("VerifyRemark", lrv);
			return FastJsonTool.genJson(false, ExRetEnum.SUCCESS, rsMap);
			}
			return FastJsonTool.genJson(false, ExRetEnum.SUCCESS, rsMap);
		}else{
			return FastJsonTool.genJson(false, ExRetEnum.NO_VERIFY_REMARK, rsMap);
		}
		
	}
	
	/**
	 *  通过planId 查询planAddress
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/planAddressInfoByPlanId")
	@ResponseBody
	public String planAddressInfoByPlanId(HttpServletRequest request)
			throws Exception {
		Map<String, Object> rsMap = new HashMap<String, Object>();
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("planId", request.getParameter("planId"));
		ProveinceAndCityVo proveinceAndCityVo = claimApplyService.findProveinceAndCity( request.getParameter("claimId"));
		if(proveinceAndCityVo!=null){
			if(proveinceAndCityVo.getProveince()!=null)
				paramMap.put("province", proveinceAndCityVo.getProveince());
			if(proveinceAndCityVo.getCity()!=null)
				paramMap.put("city", proveinceAndCityVo.getCity());
		}
		PageParam pp = new PageParam();
		pp.setPageNum(-1);
		List<PlanAddress> planAddress = planAddressService.findPlanAddressVoList(paramMap, pp);
		rsMap.put("planAddress", planAddress);
		return FastJsonTool.genJson(false, ExRetEnum.SUCCESS, rsMap);
		
	}
	
	
	
	/**
	 * 我的案件文件列表
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/myClaimFileList")
	@ResponseBody
	public String myClaimFileList(HttpServletRequest request)
			throws Exception {
		Map<String, Object> rsMap = new HashMap<String, Object>();
		String creator = request.getParameter("creator");
		Map<String ,Object> param = new HashMap<String, Object>();
		if(request.getParameter("claimId")!=null){
			param.put("claimId", request.getParameter("claimId"));
		}
		param.put("creator", creator);
//		param.put("status", 99);
		param.put("fileRecieveStatus", 0);
		param.put("statusBig", 1);
		PageParam pp = new PageParam();
		pp.setPageNum(-1);
		List<ClaimApplyVo> claimApplyVo =  claimApplyService.findClaimApplyVoMap(param, pp);
		List<Map<String,Object>> lms = new ArrayList<Map<String,Object>>();
		for(ClaimApplyVo cv : claimApplyVo){
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("claimId", cv.getId());
			map.put("planName", cv.getPlanName());
			map.put("policyOwnerName", cv.getPolicyOwnerName());
			map.put("claimNo", cv.getClaimNo());
			map.put("planId", cv.getPlanId());
			map.put("createTime", cv.getCreateTime().getTime());
			lms.add(map);
		}
		rsMap.put("claimApplyList", lms);
		return FastJsonTool.genJson(false, ExRetEnum.SUCCESS, rsMap);
	}
	/**
	 * 预约交件提交
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/claimFileOrderSubmit")
	@ResponseBody
	public String claimFileOrderSubmit(HttpServletRequest request)
			throws Exception {
		Map<String, Object> rsMap = new HashMap<String, Object>();
		String recipient = request.getParameter("recipient");
		String receiveTelephone = request.getParameter("receiveTelephone");
		String planAddressId = request.getParameter("planAddressId");
		String applyId = request.getParameter("claimId");
		String submitType = request.getParameter("submitType");
		String creator = request.getParameter("creator");
		
		String province = request.getParameter("province");
		String city = request.getParameter("city");
		String county = request.getParameter("county");
		String address = request.getParameter("address");
		String contact = request.getParameter("contact");
		String mobile = request.getParameter("mobile");
		
		ClaimExpress  claimExpress  = new ClaimExpress();
		claimExpress.setClaimApplyId(applyId);
		claimExpress.setCarrier("shunfeng");
		claimExpress.setCreateTime(new Date());
		claimExpress.setCreator(creator);
		claimExpress.setId(Tool.uuid());
		claimExpress.setPlanAddressId(planAddressId);
		claimExpress.setReceiveTelephone(receiveTelephone);
		claimExpress.setRecipient(recipient);
		claimExpress.setSubmitType(Integer.parseInt(submitType) );
		claimExpressService.insertSelective(claimExpress);

		DeliverConsigneeInfoDto deliverInfoDto = new DeliverConsigneeInfoDto();
		deliverInfoDto.setAddress(address);
		deliverInfoDto.setCity(city);
		deliverInfoDto.setContact(contact);
		deliverInfoDto.setCountry("中国");
		deliverInfoDto.setCounty(county);
		deliverInfoDto.setProvince(province);
		deliverInfoDto.setMobile(mobile);
		
		DeliverConsigneeInfoDto consigneeInfoDto = new DeliverConsigneeInfoDto();
		PlanAddress planAddress =  planAddressService.selectByPrimaryKey(planAddressId);
		consigneeInfoDto.setCompany(planAddress.getCompanyName()); 
		consigneeInfoDto.setContact(planAddress.getContactor());
		consigneeInfoDto.setTel(planAddress.getTelephone());
		consigneeInfoDto.setMobile(planAddress.getMobile());
		consigneeInfoDto.setCountry("中国");
		consigneeInfoDto.setProvince(planAddress.getProvince());
		consigneeInfoDto.setCity(planAddress.getCity());
		consigneeInfoDto.setCounty(planAddress.getDistrict());
		consigneeInfoDto.setAddress(planAddress.getFullAddress());
		SFTool.genOrderTest(claimExpress.getId(), deliverInfoDto, consigneeInfoDto);
		
		
		
		
		return FastJsonTool.genJson(false, ExRetEnum.SUCCESS, rsMap);
	}
	/**
	 * 快递交件提交
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/claimFileExpressSubmit")
	@ResponseBody
	public String claimFileExpressSubmit(HttpServletRequest request)
			throws Exception {
		Map<String, Object> rsMap = new HashMap<String, Object>();
		String expressCom = request.getParameter("carrier");
		String trackingNo = request.getParameter("trackingNo");
		String recipient = request.getParameter("recipient");
		String receiveTelephone = request.getParameter("receiveTelephone");
		String planAddressId = request.getParameter("planAddressId");
		String applyId = request.getParameter("claimId");
		String submitType = request.getParameter("submitType");
		String creator = request.getParameter("creator");
		ClaimExpress  claimExpress  = new ClaimExpress();
		claimExpress.setCarrier(expressCom);
		claimExpress.setClaimApplyId(applyId);
		claimExpress.setCreateTime(new Date());
		claimExpress.setCreator(creator);
		claimExpress.setId(Tool.uuid());
		claimExpress.setPlanAddressId(planAddressId);
		claimExpress.setReceiveTelephone(receiveTelephone);
		claimExpress.setRecipient(recipient);
		claimExpress.setSubmitType(Integer.parseInt(submitType) );
		claimExpress.setTrackingNo(trackingNo);
		
		claimExpressService.insertSelective(claimExpress);
		
		return FastJsonTool.genJson(false, ExRetEnum.SUCCESS, rsMap);
	}
	/**
	 * 自行交件提交
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/claimFileResidentSubmit")
	@ResponseBody
	public String claimFileResidentSubmit(HttpServletRequest request)
			throws Exception {
		Map<String, Object> rsMap = new HashMap<String, Object>();
		String recipient = request.getParameter("recipient");
		String receiveTelephone = request.getParameter("receiveTelephone");
		String planAddressId = request.getParameter("planAddressId");
		String applyId = request.getParameter("claimId");
		String submitType = request.getParameter("submitType");
		String creator = request.getParameter("creator");
		
		ClaimExpress  claimExpress  = new ClaimExpress();
		claimExpress.setClaimApplyId(applyId);
		claimExpress.setCreateTime(new Date());
		claimExpress.setCreator(creator);
		claimExpress.setId(Tool.uuid());
		claimExpress.setPlanAddressId(planAddressId);
		claimExpress.setReceiveTelephone(receiveTelephone);
		claimExpress.setRecipient(recipient);
		claimExpress.setSubmitType(Integer.parseInt(submitType) );
		
		claimExpressService.insertSelective(claimExpress);
		
		return FastJsonTool.genJson(false, ExRetEnum.SUCCESS, rsMap);
	}
	
}
