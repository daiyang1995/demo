package com.qucai.kp.api.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.qucai.kp.api.vo.QandaTopicVo;
import com.qucai.kp.entity.QandaTopic;

@Repository
public interface QandaTopicDao {
    int deleteByPrimaryKey(String id);

    // 插入咨询主题
    int insertSelective(QandaTopic record);

    QandaTopic selectByPrimaryKey(String id);

    // 修改咨询主题状态
    int updateByPrimaryKeySelective(QandaTopic record);

    // 根据用户userId查询咨询主题信息
    List<QandaTopicVo> findTopicListByUserId(Map<String,Object> paraMap);
}