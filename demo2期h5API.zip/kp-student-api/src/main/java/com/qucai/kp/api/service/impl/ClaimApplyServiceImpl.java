package com.qucai.kp.api.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageHelper;
import com.qucai.kp.api.dao.ClaimApplyDao;
import com.qucai.kp.api.service.ClaimApplyService;
import com.qucai.kp.api.vo.ApprovedInfo;
import com.qucai.kp.api.vo.ClaimApplyVo;
import com.qucai.kp.api.vo.ProveinceAndCityVo;
import com.qucai.kp.common.pager.PageParam;
import com.qucai.kp.entity.ClaimApply;

@Service
@Transactional
public class ClaimApplyServiceImpl implements ClaimApplyService {
	 @Autowired
	    private ClaimApplyDao claimApplyDao;
	 
	@Override
	public int deleteByPrimaryKey(String id) {
		return claimApplyDao.deleteByPrimaryKey(id);
	}

	@Override
	public int insertSelective(ClaimApply record) {
		return claimApplyDao.insertSelective(record);
	}

	@Override
	public ClaimApply selectByPrimaryKey(String id) {
		return claimApplyDao.selectByPrimaryKey(id);
	}

	@Override
	public int updateByPrimaryKeySelective(ClaimApply record) {
		return claimApplyDao.updateByPrimaryKeySelective(record);
	}

	@Override
	public List<ClaimApplyVo> findClaimApplyVoMap(Map<String, Object> paramMap,PageParam pp) {
		if(pp.getPageNum()!=-1)
			PageHelper.startPage(pp.getPageNum(), pp.getPageSize());
		return claimApplyDao.findClaimApplyVoMap(paramMap);
	}

	@Override
	public List<ClaimApplyVo> findPolicyList(Map<String, Object> paramMap) {
		return claimApplyDao.findPolicyList(paramMap);
	}

	@Override
	public ProveinceAndCityVo findProveinceAndCity(String claimId) {
		return claimApplyDao.findProveinceAndCity(claimId);
	}

	@Override
	public ApprovedInfo findApprovedInfo(String claimId) {
		return claimApplyDao.findApprovedInfo(claimId);
	}
}