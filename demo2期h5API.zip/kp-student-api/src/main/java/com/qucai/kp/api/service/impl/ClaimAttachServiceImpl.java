package com.qucai.kp.api.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.qucai.kp.api.dao.ClaimAttachDao;
import com.qucai.kp.api.service.ClaimAttachService;
import com.qucai.kp.entity.ClaimAttach;
@Service
@Transactional
public class ClaimAttachServiceImpl implements ClaimAttachService {
	@Autowired
	   private ClaimAttachDao claimAttachDao;
	 
	@Override
	public int deleteByPrimaryKey(String id) {
		return claimAttachDao.deleteByPrimaryKey(id);
	}

	@Override
	public int insertSelective(ClaimAttach record) {
		return claimAttachDao.insertSelective(record);
	}

	@Override
	public ClaimAttach selectByPrimaryKey(String id) {
		return claimAttachDao.selectByPrimaryKey(id);
	}

	@Override
	public int updateByPrimaryKeySelective(ClaimAttach record) {
		return claimAttachDao.updateByPrimaryKeySelective(record);
	}

	@Override
	public List<ClaimAttach> findAllList(Map<String, Object> paramMap) {
		return claimAttachDao.findAllList(paramMap);
	}
	
    
}
