package com.qucai.kp.api.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.qucai.kp.entity.PlanAddress;
@Repository
public interface PlanAddressDao {
    int deleteByPrimaryKey(String id);

    int insertSelective(PlanAddress record);

    PlanAddress selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(PlanAddress record);
    
    List<PlanAddress> findPlanAddressVoList(Map<String ,Object> paramMap);
}