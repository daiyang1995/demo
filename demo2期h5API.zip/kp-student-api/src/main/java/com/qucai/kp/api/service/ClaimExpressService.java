package com.qucai.kp.api.service;

import com.qucai.kp.entity.ClaimExpress;

public interface ClaimExpressService {
    int deleteByPrimaryKey(String id);

    int insertSelective(ClaimExpress record);

    ClaimExpress selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(ClaimExpress record);
}