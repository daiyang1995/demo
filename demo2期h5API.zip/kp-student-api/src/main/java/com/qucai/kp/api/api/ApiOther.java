package com.qucai.kp.api.api;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.qucai.kp.api.common.ApiConstant;
import com.qucai.kp.api.common.ExRetEnum;
import com.qucai.kp.api.service.AreaService;
import com.qucai.kp.api.service.DictService;
import com.qucai.kp.api.tool.FastJsonTool;
import com.qucai.kp.api.tool.SmsTool;
import com.qucai.kp.common.context.SysInfo;
import com.qucai.kp.common.tool.RedisTool;
import com.qucai.kp.entity.Area;
import com.qucai.kp.entity.Dict;

@Controller
@RequestMapping(value = "/apiOther")
public class ApiOther {

	@Autowired
	private AreaService areaService;

	@Autowired
	private DictService dictService;

	@RequestMapping("/captcha")
	@ResponseBody
	public String captcha(HttpServletRequest request) throws Exception {

		String type = request.getParameter("type");
		String mobile = request.getParameter("mobile");

		// 验证码
		int captcha = new Random().nextInt(899999) + 100000;
		// 15分钟有效期
		ApiConstant.CAPTCHA_MAP.put(mobile,
				captcha + ":" + (new Date().getTime() + 15 * 60 * 1000));

		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put("captcha", String.valueOf(captcha));

		// 1：注册；2：忘记密码
		if ("1".equals(type)) {

		} else if ("2".equals(type)) {
			SmsTool.sendSmsCaptcha(
					SysInfo.CONFIG.get("USER_FORGET_PASSWORD_CAPTCHA"), mobile,
					paramMap);
		} else if ("3".equals(type)) {
			SmsTool.sendSmsCaptcha(
					SysInfo.CONFIG.get("USER_BIND_MOBILE_CAPTCHA"), mobile,
					paramMap);
		}

		return FastJsonTool.genJson(false, ExRetEnum.SUCCESS);
	}

	@RequestMapping(value = "findAreaListByParentId")
	@ResponseBody
	public String findAreaListByParentId(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String jsonStr = "";
		String parentId = request.getParameter("parentId");
			
		if(!RedisTool.exists(ApiConstant.REDIS_KEY_PREFIX + "area-" + parentId + "-jsonStr")){
			Map<String, Object> rsMap = new HashMap<String, Object>();
	
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put("parentId", parentId);
			List<Area> areaList = areaService.findAllList(paramMap);
	
			rsMap.put("areaList", areaList);
	
			jsonStr = FastJsonTool.genJson(false, ExRetEnum.SUCCESS, rsMap);
			RedisTool.set(ApiConstant.REDIS_KEY_PREFIX + "area-" + parentId + "-jsonStr", jsonStr);
			
		} else {
			jsonStr = RedisTool.get(ApiConstant.REDIS_KEY_PREFIX + "area-" + parentId + "-jsonStr");
		}
		
		return jsonStr;
	}

	@RequestMapping(value = "findDictListByType")
	@ResponseBody
	public String findDictListByType(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		String jsonStr = "";
		String type = request.getParameter("type");
		
		if(!RedisTool.exists(ApiConstant.REDIS_KEY_PREFIX + "dict-" + type + "-jsonStr")){
			Map<String, Object> rsMap = new HashMap<String, Object>();
			List<Map<String, Object>> dataList = new ArrayList<Map<String, Object>>();
	
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put("type", type);
			List<Dict> dictList = dictService.findAllList(paramMap);
	
			for (Dict d : dictList) {
				Map<String, Object> dictMap = new HashMap<String, Object>();
				dictMap.put("value", d.getDvalue());
				dictMap.put("label", d.getDlabel());
				dataList.add(dictMap);
			}
	
			rsMap.put("dictList", dataList);
	
			jsonStr = FastJsonTool.genJson(false, ExRetEnum.SUCCESS, rsMap);
			RedisTool.set(ApiConstant.REDIS_KEY_PREFIX + "dict-" + type + "-jsonStr", jsonStr);
		
		} else {
			jsonStr = RedisTool.get(ApiConstant.REDIS_KEY_PREFIX + "dict-" + type + "-jsonStr");
		}
		
		return jsonStr;
	}

	@RequestMapping(value = "findDictAllList")
	@ResponseBody
	public String findDictAllList(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String jsonStr = "";
		
		if(!RedisTool.exists(ApiConstant.REDIS_KEY_PREFIX + "dictAllJsonStr")){
			Map<String, Object> rsMap = new HashMap<String, Object>();
			List<Map<String, Object>> dataList = new ArrayList<Map<String, Object>>();
	
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put("type", "claim_type,customer_type,qanda_type,express_com,bank_name_zh".split(","));
			paramMap.put("subType", "qanda_subitem");
			List<Dict> dictList = dictService.findDictAllList(paramMap);
	
			for (Dict d : dictList) {
				Map<String, Object> dictMap = new HashMap<String, Object>();
				dictMap.put("value", d.getDvalue());
				dictMap.put("label", d.getDlabel());
				dictMap.put("type", d.getType());
				dataList.add(dictMap);
			}
	
			rsMap.put("dictList", dataList);
	
			jsonStr = FastJsonTool.genJson(false, ExRetEnum.SUCCESS, rsMap);
			RedisTool.set(ApiConstant.REDIS_KEY_PREFIX + "dictAllJsonStr", jsonStr);
		
		} else {
			jsonStr = RedisTool.get(ApiConstant.REDIS_KEY_PREFIX + "dictAllJsonStr");
		}
		
		return jsonStr;
	}
}
