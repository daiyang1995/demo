package com.qucai.kp.api.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.qucai.kp.entity.UserBank;

@Repository
public interface UserBankDao {
    int deleteByPrimaryKey(String id);

    int insertSelective(UserBank record);

    UserBank selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(UserBank record);
    
	List<UserBank> findAllList(Map<String, Object> paramMap);
	
	int updateIsDefaultByUserId(UserBank userBank);
	
	int updateIsDefaultByCreator(String creator);
}