package com.qucai.kp.api.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.qucai.kp.entity.ClaimAttach;
@Repository
public interface ClaimAttachDao {
    int deleteByPrimaryKey(String id);

    int insertSelective(ClaimAttach record);

    ClaimAttach selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(ClaimAttach record);
    
    List<ClaimAttach>  findAllList(Map<String, Object> paramMap);
}