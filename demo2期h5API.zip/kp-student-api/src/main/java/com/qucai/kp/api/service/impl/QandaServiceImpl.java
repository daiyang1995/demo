package com.qucai.kp.api.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageHelper;
import com.qucai.kp.api.dao.QandaContentDao;
import com.qucai.kp.api.dao.QandaTopicDao;
import com.qucai.kp.api.service.QandaService;
import com.qucai.kp.api.vo.QandaTopicVo;
import com.qucai.kp.common.pager.PageParam;
import com.qucai.kp.entity.QandaContent;
import com.qucai.kp.entity.QandaTopic;

@Service
@Transactional
public class QandaServiceImpl implements QandaService {

	@Autowired
	private QandaTopicDao qandaTopicDao;

	@Autowired
	private QandaContentDao qandaContentDao;

	@Override
	public int deleteByPrimaryKey(String id) {
		return qandaTopicDao.deleteByPrimaryKey(id);
	}

	@Override
	public int insertQandaTopicSelective(QandaTopic record) {
		return qandaTopicDao.insertSelective(record);
	}

	@Override
	public int insertQandaContentSelective(QandaContent record) {
		return qandaContentDao.insertSelective(record);
	}

	@Override
	public QandaTopic selectQandaTopicByPrimaryKey(String id) {
		return qandaTopicDao.selectByPrimaryKey(id);
	}

	@Override
	public List<QandaTopicVo> findTopicListByUserId(
			Map<String, Object> paraMap, PageParam pp) {
		if (pp.getPageNum() != -1) {
			PageHelper.startPage(pp.getPageNum(), pp.getPageSize());
		}
		return qandaTopicDao.findTopicListByUserId(paraMap);
	}

	@Override
	public List<QandaContent> findContentListByTopicId(String topicId) {
		return qandaContentDao.findContentListByTopicId(topicId);
	}

	@Override
	public int submitQuestion(QandaTopic trecord, QandaContent crecord) {
		int tnum = qandaTopicDao.insertSelective(trecord);
		int cnum = qandaContentDao.insertSelective(crecord);
		return tnum + cnum;
	}

	@Override
	public int reSubmitQuestion(QandaContent crecord, QandaTopic trecord) {
		int tnum = qandaTopicDao.updateByPrimaryKeySelective(trecord);
		int cnum = qandaContentDao.insertSelective(crecord);
		return tnum + cnum;
	}

}
