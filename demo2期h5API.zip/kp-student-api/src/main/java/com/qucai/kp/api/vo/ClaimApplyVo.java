package com.qucai.kp.api.vo;
import java.util.Date;

/**
 * api-赔案明细
 */
import com.qucai.kp.entity.ClaimApply;

public class ClaimApplyVo extends ClaimApply {

	/**
	 * 投保人姓名
	 */
	private String policyOwnerName;
	
	/**
	 * 方案名称
	 */
	private String planName;

	/**
	 * 方案Id
	 */
	private String planId;

	/**
	 * 起保日期
	 */
	private Date startDate;

	/**
	 * 结束日期
	 */
	private Date endDate;

	/**
	 * 保单Id
	 */
	private String policyId;

	public String getPlanId() {
		return planId;
	}

	public void setPlanId(String planId) {
		this.planId = planId;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public String getPolicyOwnerName() {
		return policyOwnerName;
	}

	public void setPolicyOwnerName(String policyOwnerName) {
		this.policyOwnerName = policyOwnerName;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getPolicyId() {
		return policyId;
	}

	public void setPolicyId(String policyId) {
		this.policyId = policyId;
	}
	
}
