package com.qucai.kp.api.listener;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.qucai.kp.api.common.ApiConstant;
import com.qucai.kp.api.dao.ChannelDao;
import com.qucai.kp.api.dao.ConfigDao;
import com.qucai.kp.api.dao.DictDao;
import com.qucai.kp.common.context.SysInfo;
import com.qucai.kp.common.tool.RedisTool;
import com.qucai.kp.entity.Channel;
import com.qucai.kp.entity.Config;
import com.qucai.kp.entity.Dict;

@Component
public class SysInfoListener implements
        ApplicationListener<ContextRefreshedEvent> {
	
	private static Logger logger = LoggerFactory
			.getLogger(SysInfoListener.class);
	
	@Autowired
    private DictDao dictDao;
    @Autowired
    private ConfigDao configDao;
    @Autowired 
    private ChannelDao channelDao;
    
    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
            // 在web 项目中（spring mvc），系统会存在两个容器，一个是root application context,
            // 另一个就是我们自己的 projectName-servlet context（作为root application context的子容器）。
            // 这种情况下，就会造成onApplicationEvent方法被执行两次。为了避免上面提到的问题，我们可以只在
            // root application context初始化完成后调用逻辑代码，其他的容器的初始化完成，则不做任何处理
            if (event.getApplicationContext().getParent() == null) {
            	// 启动的时候，清空redis缓存，包括：oauthToken(ApiOauth)、area(ApiOther)、dict(ApiOther)信息
            	Set<String> apiKeys = RedisTool.getJedisInstance().keys(ApiConstant.REDIS_KEY_PREFIX + "*");
        		if (!CollectionUtils.isEmpty(apiKeys)) {
        			Long rs = RedisTool.getJedisInstance().del(apiKeys.toArray(new String[0]));
        			logger.info("clean kp-student-api redis keys, num : " + rs);
        		}
            	
                List<Dict> DictList = dictDao.findAllList(new LinkedHashMap<String, Object>());
                List<Config> configList = configDao.findAllList(new LinkedHashMap<String, Object>());
                Map<String,Object> paMap = new HashMap<String, Object>();
                List<Channel> ChannelList  = channelDao.findAllList(paMap);
                for(Channel channel : ChannelList){
                	RedisTool.set( channel.getCode()+"-"+channel.getEntCode()+"-"+channel.getTradeCode() , channel.getName());
                }
                for (Dict d : DictList) {
                    if (SysInfo.DICT_GROUP.containsKey(d.getType())) {
                        SysInfo.DICT_GROUP.get(d.getType()).put(d.getDvalue(), d.getDlabel());
                    } else {
                        Map<String, String> m = new LinkedHashMap<String, String>();
                        m.put(d.getDvalue(), d.getDlabel());
                        SysInfo.DICT_GROUP.put(d.getType(), m);
                    }
                }
                
                for (Config c : configList) {
                    SysInfo.CONFIG.put(c.getCkey(), c.getCvalue());
                }
                
            }
    }
    
}
