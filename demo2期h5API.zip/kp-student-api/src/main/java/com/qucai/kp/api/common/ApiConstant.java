package com.qucai.kp.api.common;

import java.util.HashMap;
import java.util.Map;

public class ApiConstant {

	public static final Map<String, String> CAPTCHA_MAP = new HashMap<String, String>();
	
	public static final String REDIS_KEY_PREFIX = "kp-student-api-";
	
}
