package com.qucai.kp.api.vo;

import java.math.BigDecimal;

public class ApprovedInfo {
	/**
	 * 申请金额
	 */
	private BigDecimal totalMoney;
	/**
	 * 扣除金额
	 */
	private BigDecimal refusedMoney;
	/**
	 * 赔付金额
	 */
	private BigDecimal approvedMoney;
	/**
	 * 住院津贴
	 */
	private BigDecimal usedAllowMoney;
	
	
	public BigDecimal getUsedAllowMoney() {
		return usedAllowMoney;
	}
	public void setUsedAllowMoney(BigDecimal usedAllowMoney) {
		this.usedAllowMoney = usedAllowMoney;
	}
	public BigDecimal getTotalMoney() {
		return totalMoney;
	}
	public void setTotalMoney(BigDecimal totalMoney) {
		this.totalMoney = totalMoney;
	}
	public BigDecimal getRefusedMoney() {
		return refusedMoney;
	}
	public void setRefusedMoney(BigDecimal refusedMoney) {
		this.refusedMoney = refusedMoney;
	}
	public BigDecimal getApprovedMoney() {
		return approvedMoney;
	}
	public void setApprovedMoney(BigDecimal approvedMoney) {
		this.approvedMoney = approvedMoney;
	}
	
	
	
}
