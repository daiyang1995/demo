package com.qucai.kp.api.service;

import java.util.List;
import java.util.Map;

import com.qucai.kp.common.pager.PageParam;
import com.qucai.kp.entity.PlanAddress;

public interface PlanAddressService {
    int deleteByPrimaryKey(String id);

    int insertSelective(PlanAddress record);

    PlanAddress selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(PlanAddress record);
    
    List<PlanAddress> findPlanAddressVoList(Map<String ,Object> paramMap ,PageParam pp);
}