package com.qucai.kp.api.api;

/**
 * api-我的账户
 */
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.qucai.kp.api.common.ExRetEnum;
import com.qucai.kp.api.service.DictService;
import com.qucai.kp.api.service.UserBankService;
import com.qucai.kp.api.tool.FastJsonTool;
import com.qucai.kp.api.tool.Tool;
import com.qucai.kp.common.pager.PageParam;
import com.qucai.kp.entity.Dict;
import com.qucai.kp.entity.UserBank;

@Controller
@RequestMapping(value = "/apiAccount")
public class ApiAccount {

    @Autowired
    private UserBankService userBankService;

    @Autowired
    private DictService dictService;

    /**
     * 银行列表
     * @param request
     * @return
     */
    @RequestMapping("/bankList")
    @ResponseBody
    public String bankList(HttpServletRequest request) {
        Map<String, Object> rsMap = new HashMap<String, Object>();
        Map<String, Object> paramMap = new HashMap<String, Object>();
        paramMap.put("type", "bank_name_zh");
        List<String> bankList = new ArrayList<String>();
        List<Dict> list = dictService.findAllList(paramMap);
        if (CollectionUtils.isNotEmpty(list)) {
            for (Dict dict : list) {
                bankList.add(dict.getDvalue());
            }
        }
        rsMap.put("bankList", bankList);//只有一个银行名称
        String json = "";
        try {
            json = FastJsonTool.genJson(false, ExRetEnum.SUCCESS, rsMap);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        //	    String callback = request.getParameter("jsonpcallback");
        //        String str = callback +"(" +json +")";
        System.out.println(json);
        return json;
    }

    /**
     * 上拉加载逻辑
     * @param request
     * @param creator
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/userBankMoreList")
    @ResponseBody
    public String userBankMoreList(HttpServletRequest request) throws Exception {
        System.out.println(new Date());
        String creator = request.getParameter("creator");
        PageParam pp = Tool.genPageParam(request);
        List<Map<String, Object>> dataList = new ArrayList<Map<String, Object>>();
        Map<String, Object> rsMap = new HashMap<String, Object>();
        //获取个人银行信息
        Map<String, Object> paramMap = new HashMap<String, Object>();
        paramMap.put("userId", creator);
        List<UserBank> userBankList = userBankService.findAllList(paramMap, pp);
        System.out.println(new Date());
        //		String callback = request.getParameter("jsonpcallback");

        if (CollectionUtils.isNotEmpty(userBankList)) {
            for (UserBank ub : userBankList) {
                Map<String, Object> userBankMap = new HashMap<String, Object>();
                userBankMap.put("bankId", ub.getId());
                userBankMap.put("bankName", ub.getBankName());
                userBankMap.put("bankAccount", ub.getBankAccount());
                userBankMap.put("bankCardHide", Tool.hideBankCard(ub.getBankCard()));
                userBankMap.put("bankCard", ub.getBankCard());
                userBankMap.put("accountType", ub.getAccounttype());
                userBankMap.put("isdefault", ub.getIsdefault());
                dataList.add(userBankMap);
            }
        } else {
            //		    System.out.println(callback +"(" + FastJsonTool.genJson(false, ExRetEnum.NO_MORE_DATA, rsMap) +")");
            //			return callback +"(" + FastJsonTool.genJson(false, ExRetEnum.NO_MORE_DATA, rsMap) +")";
            return FastJsonTool.genJson(false, ExRetEnum.NO_MORE_DATA, rsMap);
        }

        rsMap.put("userBankList", dataList);
        //		System.out.println(callback +"(" + FastJsonTool.genJson(false, ExRetEnum.SUCCESS, rsMap) +")");
        //		return callback +"(" + FastJsonTool.genJson(false, ExRetEnum.SUCCESS, rsMap) +")";
        return FastJsonTool.genJson(false, ExRetEnum.SUCCESS, rsMap);
    }

    /**
     * 新增用户银行卡信息列表
     * 
     * @param request
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/addUserBank")
    @ResponseBody
    public String addUserBank(HttpServletRequest request) throws Exception {
        String creator = request.getParameter("creator");
        String bankName = request.getParameter("accountName");
        String bankAccount = request.getParameter("name");
        String bankCard = request.getParameter("accountNum");
        String accountType = request.getParameter("accountType");
        String accountImg = request.getParameter("accountImg");
        String isDefault = request.getParameter("isDefault");
        if("1".equals(isDefault)) {
            //TODO:更新其他银行卡信息为非默认，根据user_id更新is_default = 0
            userBankService.updateIsDefaultByUserId(creator, 0);
        }
        UserBank userBank = new UserBank();
        userBank.setIsdefault(Integer.parseInt(isDefault));
        userBank.setAccounttype(accountType);
        userBank.setAccountimg(accountImg);
        userBank.setId(Tool.uuid());
        userBank.setUserId(creator);
        userBank.setBankName(bankName);
        userBank.setBankAccount(bankAccount);
        userBank.setBankCard(bankCard);
        userBank.setCreator(creator);
        userBank.setCreateTime(new Date());
        userBankService.insertSelective(userBank);
        return FastJsonTool.genJson(false, ExRetEnum.SUCCESS);
    }

    /**
     * 删除用户银行卡信息列表
     * 
     * @param request
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "deleteUserBank")
    @ResponseBody
    public String deleteUserBank(HttpServletRequest request) throws Exception {
        String bankId = request.getParameter("bankId");
        userBankService.deleteByPrimaryKey(bankId);
        //		String callback = request.getParameter("jsonpcallback");
        //		System.out.println(callback +"(" + FastJsonTool.genJson(false, ExRetEnum.SUCCESS) +")");
        //		return callback +"(" + FastJsonTool.genJson(false, ExRetEnum.SUCCESS) +")";
        return FastJsonTool.genJson(false, ExRetEnum.SUCCESS);
    }

    @RequestMapping(value = "selectById")
    @ResponseBody
    public String selectById(HttpServletRequest request) throws Exception {
        Map<String, Object> rsMap = new HashMap<String, Object>();
        String id = request.getParameter("id");
        UserBank userBank = userBankService.selectByPrimaryKey(id);
        if(userBank != null) {
            rsMap.put("accountName", userBank.getBankName());
            rsMap.put("name", userBank.getBankAccount());
            rsMap.put("accountNum", userBank.getBankCard());
            rsMap.put("accountType", userBank.getAccounttype());
            rsMap.put("accountImg", userBank.getAccountimg());
            rsMap.put("isDefault", userBank.getIsdefault());
            return FastJsonTool.genJson(false, ExRetEnum.SUCCESS, rsMap);
        }else {
            return FastJsonTool.genJson(false, ExRetEnum.SUCCESS, rsMap);
        }
       
    }
    
}
