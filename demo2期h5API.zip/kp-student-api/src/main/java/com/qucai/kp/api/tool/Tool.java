package com.qucai.kp.api.tool;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;

import com.qucai.kp.common.pager.PageParam;

public class Tool {

	public static PageParam genPageParam(HttpServletRequest request) {
		String pageNum = request.getParameter("pageNum") == null ? "1"
				: request.getParameter("pageNum");
		String pageSize = request.getParameter("pageSize") == null ? "10"
				: request.getParameter("pageSize");
		PageParam pp = new PageParam();
		pp.setPageNum(Integer.parseInt(pageNum));
		pp.setPageSize(Integer.parseInt(pageSize));
		return pp;
	}

	public static String uuid() {
		return UUID.randomUUID().toString().replaceAll("-", "");
	}
	
	public static String hideBankCard(String bankCard){
		bankCard = "**** **** **** "+bankCard.substring(bankCard.length()-4, bankCard.length());
		return bankCard;
	}

	public static String getFileAbsolutePath(HttpServletRequest request,
			String path) {
		return request.getSession().getServletContext().getRealPath(path);
	}

	public static String claimStatusStr(int status) {
		String str = "";
		
		switch(status){
		case 0:
			str = "草稿";
			break;
		case 10:
			str = "案件受理";
			break;
		case 11:
			str = "辅助理赔案件审核通过";
			break;
		case 12:
			str = "案件审核";	//银行卡审核通过
			break;
		case 13:
			str = "影像审核不通过";
			break;
		case 14:
			str = "案件受理"; //辅助理赔影像提交
			break;
		case 20:
			str = "案件审核";
			break;
		case 30: case 31:case 32:case 40:case 50:
			str = "案件审核";
			break;
//		 30 影像录入
//		 31 影像录入复核完成
//		 32 影像理赔复核完成
//		 40 数据发送
//		 50 数据回盘
		case 60:case 61:
			str="划账中";
			break;
		case 62:
			str="划账失败";
			break;
//		 60  待划账
//		 61  已划账
		case 63:
			str = "划账成功";
			break;
		case 100:
			str = "结案";
			break;
		case -1:
			str = "结案";
			break;
		default:
			break;
		}
		
		return str;
	}
	
	public static String claimStatusBigStr(int status) {
		String str = "";
		switch(status){
		case 0:
			str = "待发起";
			break;
		case 10:case 12:case 14:case 20:case 30:case 31:case 32:case 40:case 50:case 60:case 61:case 62:
			str = "进行中";
			break;
		case 11:case 13:
			str = "待操作";
			break;
			
		case 63:case 100:
			str = "完成";
			break;
			
		case -1:
			str = "终止";
			break;
		default:
			break;
		}
		
		return str;
	}
	public static String showMessage(int status, int fileRecieveStatus) {
		String message  = "";
		switch(status){
		case 10:case 12:case 14:case 20:case 30:case 31:case 32:case 40:case 50:case 60:case 61:case 62:
			message = "案件受理中，请耐心等待";
			break;
		case 11:case 13:
			message = "请进行案件补充";
			break;
		case 63:case 100:
			message = "案件已完成";
			break;
		case -1:
			message = "案件已终止";
			break;
		default:
			break;
		}
		if(fileRecieveStatus==0){
			message = "请进行物理交件";
		}
		return message;
	}
	
	public static String FileRecieveStatus(int fileRecieveStatus) {
		String str = "";
		switch(fileRecieveStatus){
			case -1:
				str =null;
				break;
			case 0:
				str = "待操作";
				break;
			case 1:case 2:
				str = "交件";
				break;
			case 3:
				str = "拒收";
				break;
		}
		return str;
	}
	
	public static int getDayBetween(Date d1, Date d2) {
		Calendar c1 = Calendar.getInstance();
		c1.setTime(d1);
		c1.set(Calendar.HOUR_OF_DAY, 0);
		c1.set(Calendar.MINUTE, 0);
		c1.set(Calendar.SECOND, 0);
		c1.set(Calendar.MILLISECOND, 0);
		
		Calendar c2 = Calendar.getInstance();
		c2.setTime(d2);
		c2.set(Calendar.HOUR_OF_DAY, 0);
		c2.set(Calendar.MINUTE, 0);
		c2.set(Calendar.SECOND, 0);
		c2.set(Calendar.MILLISECOND, 0);
		
		Long d = Math.abs((c2.getTimeInMillis()- c1.getTimeInMillis()) / (1000 * 3600 * 24));
		return d.intValue();
	}

	public static String hideIdCard(String idCard) {
		return idCard.substring(0, 2)
				+ StringUtils.leftPad(idCard.substring(idCard.length() - 4),
						idCard.length() - 2, "*");
	}

	public static long datetimeNullConvert(Date d, int def) {
		return d == null ? def : d.getTime();
	}

	public static int numberNullConvert(Integer o, int def) {
		return o == null ? def : o;
	}

	public static Double numberNullConvert(Double o, double def) {
		return o == null ? def : o;
	}

	public static BigDecimal numberNullConvert(BigDecimal o, BigDecimal def) {
		return o == null ? def : o;
	}

	public static String stringNullConvert(String s) {
		return s == null ? "" : s;
	}

	public static String genInviteCode(int userId) {
		return StringUtils.leftPad(Integer.toHexString(userId), 6, "0");
	}
}
