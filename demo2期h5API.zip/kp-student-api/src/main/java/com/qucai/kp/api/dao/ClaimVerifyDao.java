package com.qucai.kp.api.dao;

import org.springframework.stereotype.Repository;

import com.qucai.kp.entity.ClaimVerify;
@Repository
public interface ClaimVerifyDao {
    int deleteByPrimaryKey(String id);

    int insertSelective(ClaimVerify record);

    ClaimVerify selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(ClaimVerify record);
    
    ClaimVerify  selectByClaimApplyId(String id);
}