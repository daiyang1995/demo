package com.qucai.kp.api.service;

import java.util.List;
import java.util.Map;

import com.qucai.kp.entity.Dict;

public interface DictService {
    
    List<Dict> findAllList(Map<String, Object> paramMap);

    List<Dict> findDictAllList(Map<String, Object> paramMap);
}