package com.qucai.kp.api.api;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.qucai.kp.api.common.ExRetEnum;
import com.qucai.kp.api.service.QandaService;
import com.qucai.kp.api.tool.FastJsonTool;
import com.qucai.kp.api.tool.Tool;
import com.qucai.kp.api.vo.QandaTopicVo;
import com.qucai.kp.common.pager.PageParam;
import com.qucai.kp.entity.QandaContent;
import com.qucai.kp.entity.QandaTopic;

@Controller
@RequestMapping(value = "/apiQuestion")
public class ApiQuestion {

	@Autowired
	private QandaService qandaService;

	@RequestMapping(value = "/myQuestionMoreList")
	@ResponseBody
	public String myQuestionMoreList(HttpServletRequest request)
			throws Exception {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		
		List<Map<String, Object>> dataList = new ArrayList<Map<String, Object>>();
		Map<String, Object> rsMap = new HashMap<String, Object>();
		
		PageParam pp = Tool.genPageParam(request);
		String creator = request.getParameter("creator");

		Map<String, Object> paraMap = new HashMap<String, Object>();
		paraMap.put("userId", creator);
		List<QandaTopicVo> qandaTopicList = qandaService.findTopicListByUserId(
				paraMap, pp);

		if (CollectionUtils.isNotEmpty(qandaTopicList)) {
			for (QandaTopicVo qtv : qandaTopicList) {
				Map<String, Object> cmap = new HashMap<String, Object>();
				cmap.put("questionId", qtv.getId());
				cmap.put("type", qtv.getType());
				cmap.put("typeStr", qtv.getTypeStr());
				cmap.put("subitem", qtv.getSubitem());
				cmap.put("subitemStr", qtv.getSubitemStr());
				cmap.put("title", qtv.getTitle());
				cmap.put("status", qtv.getStatus());
				cmap.put("createTime", sdf.format(qtv.getCreateTime()));
				dataList.add(cmap);
			}
		} else {
			return FastJsonTool.genJson(false, ExRetEnum.NO_MORE_DATA, rsMap);
		}

		rsMap.put("questionList", dataList);
		return FastJsonTool.genJson(false, ExRetEnum.SUCCESS, rsMap);
	}

	/**
	 * 咨询详细
	 * 
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/questionDetail")
	@ResponseBody
	public String questionDetail(HttpServletRequest request) throws Exception {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		
		Map<String, Object> rsMap = new HashMap<String, Object>();
		List<Map<String, Object>> dataList = new ArrayList<Map<String, Object>>();

		String questionId = request.getParameter("questionId");
		// 根据主题id查询咨询内容信息
		List<QandaContent> qandaContentList = qandaService
				.findContentListByTopicId(questionId);

		if (CollectionUtils.isNotEmpty(qandaContentList)) {
			for (QandaContent qc : qandaContentList) {
				Map<String, Object> cmap = new HashMap<String, Object>();
				cmap.put("content", qc.getContent());
				cmap.put("createTime",sdf.format( qc.getCreateTime()));
				cmap.put("isMyMsg", qc.getIsUserMsg());
				dataList.add(cmap);
			}
		} else {
			return FastJsonTool.genJson(false, ExRetEnum.QANDA_NOT_EXIST_ERROR,
					rsMap);
		}

		rsMap.put("topicId", questionId);
		rsMap.put("qandaList", dataList);

		return FastJsonTool.genJson(false, ExRetEnum.SUCCESS, rsMap);
	}

	/**
	 * 提交咨询
	 * 
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/submitQuestion")
	@ResponseBody
	public String submitQuestion(HttpServletRequest request) throws Exception {
		String creator = request.getParameter("creator");
		String type = request.getParameter("type");
		String subitem = request.getParameter("subitem");
		String content = request.getParameter("content");
		String mobile = request.getParameter("mobile");
		String email = request.getParameter("email");

		String qandaTitle = "";// 咨询标题
		if (content.trim().length() > 20) {
			qandaTitle = content.trim().substring(0, 20) + "...";
		} else {
			qandaTitle = content.trim() + "...";
		}
		String qandaTopicId = Tool.uuid();

		// 咨询主题
		QandaTopic qandaTopic = new QandaTopic();
		qandaTopic.setId(qandaTopicId);// 咨询主题id
		qandaTopic.setType(type);// 咨询类型
		qandaTopic.setSubitem(subitem);// 咨询类型子项
		qandaTopic.setMobile(mobile);// 联系电话
		qandaTopic.setEmail(email);// 联系邮箱
		qandaTopic.setTitle(qandaTitle);// 咨询标题
		qandaTopic.setStatus(0);// 状态
		qandaTopic.setCreator(creator);// 创建人id
		qandaTopic.setCreateTime(new Date());// 创建日期
		// 咨询内容
		QandaContent qandaContent = new QandaContent();
		qandaContent.setId(Tool.uuid());// 咨询内容id
		qandaContent.setQandaTopicId(qandaTopicId);// 咨询主题id
		qandaContent.setIsUserMsg(1);// 是否用户留言
		qandaContent.setContent(content);// 咨询内容
		qandaContent.setCreator(creator);// 修改人id
		qandaContent.setCreateTime(new Date());// 修改日期

		qandaService.submitQuestion(qandaTopic, qandaContent);

		return FastJsonTool.genJson(false, ExRetEnum.SUCCESS);
	}

	/**
	 * 追问
	 * 
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/reSubmitQuestion")
	@ResponseBody
	public String reSubmitQuestion(HttpServletRequest request) throws Exception {
		String questionId = request.getParameter("questionId");
		String content = request.getParameter("content");
		String creator = request.getParameter("creator");
		
		// 咨询内容
		QandaContent qandaContent = new QandaContent();
		qandaContent.setId(Tool.uuid());// 咨询内容id
		qandaContent.setQandaTopicId(questionId);// 咨询主题id
		qandaContent.setIsUserMsg(1);// 是否给用户留言
		qandaContent.setContent(content);// 咨询内容
		qandaContent.setCreator(creator);// 创建人id
		qandaContent.setCreateTime(new Date());// 创建日期
		// 修改咨询主题状态
		QandaTopic qandaTopic = new QandaTopic();
		qandaTopic.setId(questionId);
		qandaTopic.setStatus(0);
		qandaService.reSubmitQuestion(qandaContent, qandaTopic);
		
		Map<String, Object> rsMap = new HashMap<String, Object>();
		
		rsMap.put("content", qandaContent.getContent());
		rsMap.put("createTime", qandaContent.getCreateTime());
		return FastJsonTool.genJson(false, ExRetEnum.SUCCESS,rsMap);
	}

}
