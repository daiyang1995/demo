package com.qucai.kp.api.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.qucai.kp.api.dao.AreaDao;
import com.qucai.kp.api.service.AreaService;
import com.qucai.kp.entity.Area;

@Service
@Transactional
public class AreaServiceImpl implements AreaService {

    @Autowired
    private AreaDao areaDao;
    
    @Override
    public List<Area> findAllList(Map<String, Object> paramMap) {
        return areaDao.findAllList(paramMap);
    }

}