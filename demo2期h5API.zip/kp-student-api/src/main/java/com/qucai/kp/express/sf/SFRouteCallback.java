package com.qucai.kp.express.sf;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.alibaba.fastjson.TypeReference;
import com.qucai.kp.common.tool.JsonTool;
import com.sf.openapi.common.entity.HeadMessageResp;
import com.sf.openapi.common.entity.MessageReq;
import com.sf.openapi.common.entity.MessageResp;
import com.sf.openapi.express.sample.route.dto.RoutePushReqDto;
import com.sf.openapi.express.sample.route.dto.RoutePushRespDto;

public class SFRouteCallback extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	private static Logger logger = LoggerFactory.getLogger(SFOrderCallback.class);
	
	// use this 'wac' get your service bean
	protected WebApplicationContext wac;

	@Override
	public void init() throws ServletException {
		super.init();
		ServletContext sc = getServletContext();
		wac = WebApplicationContextUtils
				.getWebApplicationContext(sc);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		String inputStr = getParamFromStream(request);
		logger.info("SFOrderCallback:{}", inputStr);
		
		MessageReq<List<RoutePushReqDto>> req = JsonTool.resolveByFastJson(
				new TypeReference<MessageReq<List<RoutePushReqDto>>>() {
				}, inputStr);
		
		// TODO
		// 逻辑处理
		// 根据运单号，增量添加物流信息
		List<BigDecimal> idList = new ArrayList<BigDecimal>();
		for(RoutePushReqDto rp : req.getBody()){
			idList.add(rp.getId());
			System.out.println(rp.getId());
			System.out.println(rp.getMailNo());
		}
		
		MessageResp<RoutePushRespDto> resp = new MessageResp<RoutePushRespDto>();
		HeadMessageResp head = new HeadMessageResp();
		head.setTransType(SFConstant.HEAD_TRANSTYPE_4500);
		head.setTransMessageId(SFTool.genTransMessageId());
		head.setCode("EX_CODE_OPENAPI_0200");
		head.setMessage("路由推送成功");
		resp.setHead(head);
		
		RoutePushRespDto routePushRespDto = new RoutePushRespDto();
		routePushRespDto.setId(StringUtils.join(idList.toArray()));
		routePushRespDto.setIdError("");
		
		resp.setBody(routePushRespDto);
		response.getWriter().print(JsonTool.genByFastJson(resp));
		
	}
	
	protected String getParamFromStream(HttpServletRequest request)
			throws IOException {
		StringBuffer sb = new StringBuffer();
		InputStream is = request.getInputStream();
		InputStreamReader isr = new InputStreamReader(is);
		BufferedReader br = new BufferedReader(isr);
		String s = "";
		while ((s = br.readLine()) != null) {
			sb.append(s);
		}
		return sb.toString();
	}
}
