package com.qucai.kp.api.service;

import java.util.List;

import com.qucai.kp.entity.ClaimLog;

public interface ClaimLogService {
    int deleteByPrimaryKey(String id);

    int insertSelective(ClaimLog record);

    ClaimLog selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(ClaimLog record);
    
    List<ClaimLog> findClaimLogListByClaimId(String id );
}