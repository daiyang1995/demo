package com.qucai.kp.api.common;


/**
 * 业务返回码定义规则如下：<br>
 * 模块名_方法名_返回码<br>
 * 每个方法至少保留一项默认返回码<br>
 * ret：如010101：01(模块)01(方法)01(异常)，其中，模块编号00代表业务系统的自定义系统级错误<br>
 * 
 * @author owner
 *
 */
public enum ExRetEnum {

	// 基本
	SUCCESS("0", "成功"), 
	NO_MORE_DATA("100","没有更多数据了"),
	NO_VERIFY_REMARK("100","审核备注为空"),
	// 认证
	TOKEN_ERROR("-1", "oauthtoken错误"), 
	TOKEN_EXPIRE("-1", "oauthtoken过期"),
	OAUTH_USER_FROZEN("-1", "账户被冻结"),
	OAUTH_WX_OPEN_ID_ERROR("-1", "用户未注册"), 
	OAUTH_WX_MOBILE_BIND_ERROR("-1", "用户未绑定手机号"),
	OAUTH_LOGIN_FAIL("-1", "用户名/密码错误"),

	CAPTCHA_REPEAT_ERROR("-1", "请勿重复请求"),
	CAPTCHA_SEND_FAIL("-1", "短信发送失败"),
	
	CAPTCHA_CHECK_ERROR("-1", "验证码错误"),
	CAPTCHA_TIMEOUT("-1", "验证码已过期"),
	
	ACCOUNT_MODIFY_PASSWORD_ERROR("-1", "原密码错误"),
	ACCOUNT_MODIFY_IDENTITY_INFO_BLANK_ERROR("-1", "姓名及身份证不可为空"),
	ACCOUNT_MODIFY_IDENTITY_INFO_ID_CARD_ERROR("-1", "身份证不合法"),
	
	POLICY_NOT_EXIST_ERROR("-1", "保单不存在"),
	
	CLAIM_APPLY_ATTACH_FILE_EMPTY_ERROR("-1", "请上传影像件"),
	
	CLAIM_NOT_EXIST_ERROR("-1", "理赔案件不存在"),
	CLAIM_EDIT_NOT_DRAFT_ERROR("-1", "理赔案件不是草稿状态，禁止编辑"),
	
	QANDA_NOT_EXIST_ERROR("-1", "咨询信息不存在");

	
	private String ret;
	private String msg;

	ExRetEnum(String ret, String msg) {
		this.ret = ret;
		this.msg = msg;
	}

	public String getRet() {
		return ret;
	}

	public void setRet(String ret) {
		this.ret = ret;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

}
