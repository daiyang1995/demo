package com.qucai.kp.api.service;

import java.util.List;
import java.util.Map;

import com.qucai.kp.api.vo.QandaTopicVo;
import com.qucai.kp.common.pager.PageParam;
import com.qucai.kp.entity.QandaContent;
import com.qucai.kp.entity.QandaTopic;

public interface QandaService {

	int deleteByPrimaryKey(String id);

	// 插入咨询主题
	int insertQandaTopicSelective(QandaTopic record);

	// 插入咨询内容
	int insertQandaContentSelective(QandaContent record);

	QandaTopic selectQandaTopicByPrimaryKey(String id);

	// 提交咨询信息
	int submitQuestion(QandaTopic trecord, QandaContent crecord);

	// 追问咨询信息
	int reSubmitQuestion(QandaContent crecord, QandaTopic trecord);

	// 根据用户userId查询咨询主题信息
	List<QandaTopicVo> findTopicListByUserId(Map<String,Object> paraMap, PageParam pp);

	// 根据主题id查询咨询内容信息
	List<QandaContent> findContentListByTopicId(String topicId);

}