package com.qucai.kp.api.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.qucai.kp.entity.ClaimLog;
@Repository
public interface ClaimLogDao {
    int deleteByPrimaryKey(String id);

    int insertSelective(ClaimLog record);

    ClaimLog selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(ClaimLog record);
    
    List<ClaimLog> findClaimLogListByClaimId(String id );
}