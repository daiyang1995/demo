package com.qucai.kp.api.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.qucai.kp.entity.Area;

@Repository
public interface AreaDao {
    
    List<Area> findAllList(Map<String, Object> paramMap);
}