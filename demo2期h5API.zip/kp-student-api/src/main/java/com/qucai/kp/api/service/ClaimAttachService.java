package com.qucai.kp.api.service;

import java.util.List;
import java.util.Map;

import com.qucai.kp.entity.ClaimAttach;

public interface ClaimAttachService {
	int deleteByPrimaryKey(String id);

    int insertSelective(ClaimAttach record);

    ClaimAttach selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(ClaimAttach record);
    
    List<ClaimAttach>  findAllList(Map<String, Object> paramMap);
}
