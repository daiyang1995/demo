package com.qucai.kp.api.tool;

import java.util.HashMap;
import java.util.Map;

import com.qucai.kp.api.common.ExRetEnum;
import com.qucai.kp.common.codec.MixEncryptUtil;
import com.qucai.kp.common.context.SysInfo;
import com.qucai.kp.common.tool.JsonTool;

public class FastJsonTool {

	public static String genJson(boolean encrypt, ExRetEnum re) throws Exception {
		return genJson(encrypt, re.getRet(), re.getMsg());
	}

	public static String genJson(boolean encrypt, String ret, String msg) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("ret", ret);
		map.put("msg", msg);
		return genJson(encrypt, map);
	}

	public static String genJson(boolean encrypt, ExRetEnum re, Map<String, Object> body)
			throws Exception {
		body.put("ret", re.getRet());
		body.put("msg", re.getMsg());
		return genJson(encrypt, body);
	}
	
	public static String genJson(boolean encrypt, Map<String, Object> body)
			throws Exception {
		if(encrypt) {
			Map<String, Object> dataMap = MixEncryptUtil.safeHandle4Resp(
					SysInfo.CONFIG.get("API_RSA_PRIVATE_KEY"), body);
			// 冗余设计，保证h5开发，后期要删除掉
			dataMap.put("ret", body.get("ret"));
			dataMap.put("msg", body.get("msg"));
			return JsonTool.genByFastJson(dataMap);
		}
		return JsonTool.genByFastJson(body);
	}

}
