package com.qucai.kp.api.service;

import java.util.List;
import java.util.Map;

import com.qucai.kp.api.vo.RuleVo;
import com.qucai.kp.entity.PlanImageVerifyRule;

public interface PlanImageVerifyRuleService {
    int deleteByPrimaryKey(String id);

    int insertSelective(PlanImageVerifyRule record);

    PlanImageVerifyRule selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(PlanImageVerifyRule record);
    
    PlanImageVerifyRule  findRule(Map<String, Object> paramMap);
    
    List<RuleVo> findRuleVo(Map<String, Object> paramMap);
}