package com.qucai.kp.api.vo;
/**
 * api-保单明细
 */

public class PolicyDetailVo extends PolicyVo {

	/**
	 * 所属公司
	 */
	private String enterpriseName;
	
	/**
	 * 人员类型
	 */
	private String customerType;
	
	/**
	 * 人员类型描述
	 */
	private String customerTypeStr;

	public String getEnterpriseName() {
		return enterpriseName;
	}

	public void setEnterpriseName(String enterpriseName) {
		this.enterpriseName = enterpriseName;
	}

	public String getCustomerType() {
		return customerType;
	}

	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

	public String getCustomerTypeStr() {
		return customerTypeStr;
	}

	public void setCustomerTypeStr(String customerTypeStr) {
		this.customerTypeStr = customerTypeStr;
	}
	
	
}
