package com.qucai.kp.api.service;

import java.util.List;
import java.util.Map;

import com.qucai.kp.api.vo.ApprovedInfo;
import com.qucai.kp.api.vo.ClaimApplyVo;
import com.qucai.kp.api.vo.ProveinceAndCityVo;
import com.qucai.kp.common.pager.PageParam;
import com.qucai.kp.entity.ClaimApply;


public interface ClaimApplyService {
    int deleteByPrimaryKey(String id);

    int insertSelective(ClaimApply record);

    ClaimApply selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(ClaimApply record);
    //根据用户id 状态 查询 进心中或者已完成
    List<ClaimApplyVo> findClaimApplyVoMap(Map<String, Object> paramMap,PageParam pp);
    
    List<ClaimApplyVo> findPolicyList(Map<String, Object> paramMap);
    
    ProveinceAndCityVo findProveinceAndCity(String claimId);
    
    ApprovedInfo findApprovedInfo(String claimId);
}