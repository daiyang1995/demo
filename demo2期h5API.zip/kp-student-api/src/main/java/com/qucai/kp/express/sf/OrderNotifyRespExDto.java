package com.qucai.kp.express.sf;

import com.sf.openapi.express.sample.order.dto.OrderNotifyRespDto;

public class OrderNotifyRespExDto extends OrderNotifyRespDto {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3149422340616952328L;
	private String orderId;

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	
}
