package com.qucai.kp.api.tool;

import java.util.Map;

import com.alibaba.fastjson.JSONObject;
import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.IAcsClient;
import com.aliyuncs.profile.DefaultProfile;
import com.aliyuncs.profile.IClientProfile;
import com.aliyuncs.sms.model.v20160927.SingleSendSmsRequest;
import com.qucai.kp.common.context.SysInfo;


public class SmsTool {
    
	/**
	 * 验证码
	 * 
	 * @param mobile
	 *            多个手机号用逗号分割，最多不超过100个手机号
	 * @param paramMap
	 *            模板参数
	 * @throws Exception
	 */
	public static void sendSmsCaptcha(String templateCode, String mobile,
			Map<String, String> paramMap) throws Exception {
		JSONObject jsonObject = new JSONObject();
		for (String key : paramMap.keySet()) {
			jsonObject.put(key,
					paramMap.get(key) == null ? "" : paramMap.get(key));
		}
		String paramStr = jsonObject.toString();

		IClientProfile profile = DefaultProfile.getProfile("cn-hangzhou",
				SysInfo.CONFIG.get("SMS_ACCESS_KEY_ID"),
				SysInfo.CONFIG.get("SMS_ACCESS_KEY_SECRET"));
		DefaultProfile.addEndpoint("cn-hangzhou", "cn-hangzhou", "Sms",
				"sms.aliyuncs.com");
		IAcsClient client = new DefaultAcsClient(profile);
		SingleSendSmsRequest request = new SingleSendSmsRequest();
		request.setSignName(SysInfo.CONFIG.get("SMS_SIGN_NAME"));
		request.setTemplateCode(templateCode);
		request.setParamString(paramStr);
		request.setRecNum(mobile);
		client.getAcsResponse(request);
	}
    
}