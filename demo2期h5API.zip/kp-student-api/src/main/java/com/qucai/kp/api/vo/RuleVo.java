package com.qucai.kp.api.vo;

public class RuleVo {

	/**
	 * 规则编号
	 */
	private String dvalue;
	/**
	 * 规则描述
	 */
	private String dlabel;
	
	public String getDvalue() {
		return dvalue;
	}
	public void setDvalue(String dvalue) {
		this.dvalue = dvalue;
	}
	public String getDlabel() {
		return dlabel;
	}
	public void setDlabel(String dlabel) {
		this.dlabel = dlabel;
	}
	
	
}
