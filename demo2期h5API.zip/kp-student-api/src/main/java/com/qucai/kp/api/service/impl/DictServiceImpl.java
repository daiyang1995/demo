package com.qucai.kp.api.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.qucai.kp.api.dao.DictDao;
import com.qucai.kp.api.service.DictService;
import com.qucai.kp.entity.Dict;

@Service
@Transactional
public class DictServiceImpl implements DictService {

    @Autowired
    private DictDao dictDao;

    @Override
	public List<Dict> findAllList(Map<String, Object> paramMap) {
		return dictDao.findAllList(paramMap);
	}

    @Override
	public List<Dict> findDictAllList(Map<String, Object> paramMap) {
		return dictDao.findDictAllList(paramMap);
	}
}
