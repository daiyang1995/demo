package com.qucai.kp.api.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.qucai.kp.api.dao.ClaimVerifyDao;
import com.qucai.kp.api.service.ClaimVerifyService;
import com.qucai.kp.entity.ClaimVerify;
@Service
@Transactional
public class  ClaimVerifyServiceImpl  implements ClaimVerifyService{
	@Autowired
	private ClaimVerifyDao claimVerifyDao;
	
	@Override
	public int deleteByPrimaryKey(String id) {
		return claimVerifyDao.deleteByPrimaryKey(id);
	}

	@Override
	public int insertSelective(ClaimVerify record) {
		return claimVerifyDao.insertSelective(record);
	}

	@Override
	public ClaimVerify selectByPrimaryKey(String id) {
		return claimVerifyDao.selectByPrimaryKey(id);
	}

	@Override
	public int updateByPrimaryKeySelective(ClaimVerify record) {
		return claimVerifyDao.updateByPrimaryKeySelective(record);
	}

	@Override
	public ClaimVerify selectByClaimApplyId(String id) {
		return claimVerifyDao.selectByClaimApplyId(id);
	}

}