package com.sf.aries.core.model;

import java.io.Serializable;
import org.apache.commons.lang.builder.ToStringBuilder;

public class BaseEntity implements Serializable {
	private static final long serialVersionUID = -1541987047978883181L;

	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
