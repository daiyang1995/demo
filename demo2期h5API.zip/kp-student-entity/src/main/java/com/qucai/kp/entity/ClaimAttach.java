package com.qucai.kp.entity;

import java.util.Date;

/**
 * 理赔影像表
 * 
 * @version 1.0 2017-07-24
 */
public class ClaimAttach {
    /**
     * id
     */
    private String id;

    /**
     * 案件id
     */
    private String claimApplyId;

    /**
     * 目录
     */
    private String folder;

    /**
     * 文件名
     */
    private String fileName;

    /**
     * 扩展名
     */
    private String suffix;

    /**
     * 是否清晰（0：否；1：是）
     */
    private Integer isClear;

    /**
     * 是否原件（0：否；1：是）
     */
    private Integer isMasterCopy;

    /**
     * 影像类型
     */
    private String contentType;

    /**
     * 审核状态（0：未审核；1：已审核）
     */
    private Integer status;

    /**
     * 备注
     */
    private String remark;

    /**
     * 创建人
     */
    private String creator;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改人
     */
    private String modifier;

    /**
     * 修改时间
     */
    private Date modifyTime;
    /**
     * 是否删除
     */
    private Integer isDel;

    /**
     * id
     * @return 
     */
    public String getId() {
        return id;
    }

    /**
     * id
     * @param id
     */
    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    /**
     * 案件id
     * @return 
     */
    public String getClaimApplyId() {
        return claimApplyId;
    }

    /**
     * 案件id
     * @param claimApplyId
     */
    public void setClaimApplyId(String claimApplyId) {
        this.claimApplyId = claimApplyId == null ? null : claimApplyId.trim();
    }

    /**
     * 目录
     * @return 
     */
    public String getFolder() {
        return folder;
    }

    /**
     * 目录
     * @param folder
     */
    public void setFolder(String folder) {
        this.folder = folder == null ? null : folder.trim();
    }

    /**
     * 文件名
     * @return 
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * 文件名
     * @param fileName
     */
    public void setFileName(String fileName) {
        this.fileName = fileName == null ? null : fileName.trim();
    }

    /**
     * 扩展名
     * @return 
     */
    public String getSuffix() {
        return suffix;
    }

    /**
     * 扩展名
     * @param suffix
     */
    public void setSuffix(String suffix) {
        this.suffix = suffix == null ? null : suffix.trim();
    }

    /**
     * 是否清晰（0：否；1：是）
     * @return 
     */
    public Integer getIsClear() {
        return isClear;
    }

    /**
     * 是否清晰（0：否；1：是）
     * @param isClear
     */
    public void setIsClear(Integer isClear) {
        this.isClear = isClear;
    }

    /**
     * 是否原件（0：否；1：是）
     * @return 
     */
    public Integer getIsMasterCopy() {
        return isMasterCopy;
    }

    /**
     * 是否原件（0：否；1：是）
     * @param isMasterCopy
     */
    public void setIsMasterCopy(Integer isMasterCopy) {
        this.isMasterCopy = isMasterCopy;
    }

    /**
     * 影像类型
     * @return 
     */
    public String getContentType() {
        return contentType;
    }

    /**
     * 影像类型
     * @param contentType
     */
    public void setContentType(String contentType) {
        this.contentType = contentType == null ? null : contentType.trim();
    }

    /**
     * 审核状态（0：未审核；1：已审核）
     * @return 
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * 审核状态（0：未审核；1：已审核）
     * @param status
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     * 备注
     * @return 
     */
    public String getRemark() {
        return remark;
    }

    /**
     * 备注
     * @param remark
     */
    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    /**
     * 创建人
     * @return 
     */
    public String getCreator() {
        return creator;
    }

    /**
     * 创建人
     * @param creator
     */
    public void setCreator(String creator) {
        this.creator = creator == null ? null : creator.trim();
    }

    /**
     * 创建时间
     * @return 
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 创建时间
     * @param createTime
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 修改人
     * @return 
     */
    public String getModifier() {
        return modifier;
    }

    /**
     * 修改人
     * @param modifier
     */
    public void setModifier(String modifier) {
        this.modifier = modifier == null ? null : modifier.trim();
    }

    /**
     * 修改时间
     * @return 
     */
    public Date getModifyTime() {
        return modifyTime;
    }

    /**
     * 修改时间
     * @param modifyTime
     */
    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }
    /**
     * 是否删除
     * @return isDel
     */
    public Integer getIsDel() {
        return isDel;
    }
    /**
     * 是否删除
     * @param isDel
     */
    public void setIsDel(Integer isDel) {
        this.isDel = isDel;
    }
}