package com.qucai.kp.entity;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 理赔录入信息表
 * 
 * @version 1.0 2017-08-06
 */
public class ClaimReceipt {
    /**
     * id
     */
    private String id;

    /**
     * 理赔申请id
     */
    private String claimApplyId;

    /**
     * 就诊医院
     */
    private String hospitalId;

    /**
     * 就诊疾病
     */
    private String diseaseId;

    /**
     * 关联报案影像ID
     */
    private String claimAttachId;

    /**
     * 发票号
     */
    private String receiptNumber;

    /**
     * 就诊日期
     */
    private Date visitDate;

    /**
     * 入院日期
     */
    private Date hospitalDate;

    /**
     * 出院日期
     */
    private Date dischargeDate;

    /**
     * 账户支付
     */
    private BigDecimal accountMoney;

    /**
     * 现金支付
     */
    private BigDecimal cashMoney;

    /**
     * 统筹支付
     */
    private BigDecimal fundMoney;

    /**
     * 附加支付
     */
    private BigDecimal additionalMoney;

    /**
     * 自费
     */
    private BigDecimal selfMoney;

    /**
     * 分类自负
     */
    private BigDecimal classifyMoney;

    /**
     * 合计
     */
    private BigDecimal total;

    /**
     * 是否复核过
     */
    private String isVerify;

    /**
     * 创建人
     */
    private String creator;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改人
     */
    private String modifier;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * id
     * @return 
     */
    public String getId() {
        return id;
    }

    /**
     * id
     * @param id
     */
    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    /**
     * 理赔申请id
     * @return 
     */
    public String getClaimApplyId() {
        return claimApplyId;
    }

    /**
     * 理赔申请id
     * @param claimApplyId
     */
    public void setClaimApplyId(String claimApplyId) {
        this.claimApplyId = claimApplyId == null ? null : claimApplyId.trim();
    }

    /**
     * 就诊医院
     * @return 
     */
    public String getHospitalId() {
        return hospitalId;
    }

    /**
     * 就诊医院
     * @param hospitalId
     */
    public void setHospitalId(String hospitalId) {
        this.hospitalId = hospitalId == null ? null : hospitalId.trim();
    }

    /**
     * 就诊疾病
     * @return 
     */
    public String getDiseaseId() {
        return diseaseId;
    }

    /**
     * 就诊疾病
     * @param diseaseId
     */
    public void setDiseaseId(String diseaseId) {
        this.diseaseId = diseaseId == null ? null : diseaseId.trim();
    }

    /**
     * 关联报案影像ID
     * @return 
     */
    public String getClaimAttachId() {
        return claimAttachId;
    }

    /**
     * 关联报案影像ID
     * @param claimAttachId
     */
    public void setClaimAttachId(String claimAttachId) {
        this.claimAttachId = claimAttachId == null ? null : claimAttachId.trim();
    }

    /**
     * 发票号
     * @return 
     */
    public String getReceiptNumber() {
        return receiptNumber;
    }

    /**
     * 发票号
     * @param receiptNumber
     */
    public void setReceiptNumber(String receiptNumber) {
        this.receiptNumber = receiptNumber == null ? null : receiptNumber.trim();
    }

    /**
     * 就诊日期
     * @return 
     */
    public Date getVisitDate() {
        return visitDate;
    }

    /**
     * 就诊日期
     * @param visitDate
     */
    public void setVisitDate(Date visitDate) {
        this.visitDate = visitDate;
    }

    /**
     * 入院日期
     * @return 
     */
    public Date getHospitalDate() {
        return hospitalDate;
    }

    /**
     * 入院日期
     * @param hospitalDate
     */
    public void setHospitalDate(Date hospitalDate) {
        this.hospitalDate = hospitalDate;
    }

    /**
     * 出院日期
     * @return 
     */
    public Date getDischargeDate() {
        return dischargeDate;
    }

    /**
     * 出院日期
     * @param dischargeDate
     */
    public void setDischargeDate(Date dischargeDate) {
        this.dischargeDate = dischargeDate;
    }

    /**
     * 账户支付
     * @return 
     */
    public BigDecimal getAccountMoney() {
        return accountMoney;
    }

    /**
     * 账户支付
     * @param accountMoney
     */
    public void setAccountMoney(BigDecimal accountMoney) {
        this.accountMoney = accountMoney;
    }

    /**
     * 现金支付
     * @return 
     */
    public BigDecimal getCashMoney() {
        return cashMoney;
    }

    /**
     * 现金支付
     * @param cashMoney
     */
    public void setCashMoney(BigDecimal cashMoney) {
        this.cashMoney = cashMoney;
    }

    /**
     * 统筹支付
     * @return 
     */
    public BigDecimal getFundMoney() {
        return fundMoney;
    }

    /**
     * 统筹支付
     * @param fundMoney
     */
    public void setFundMoney(BigDecimal fundMoney) {
        this.fundMoney = fundMoney;
    }

    /**
     * 附加支付
     * @return 
     */
    public BigDecimal getAdditionalMoney() {
        return additionalMoney;
    }

    /**
     * 附加支付
     * @param additionalMoney
     */
    public void setAdditionalMoney(BigDecimal additionalMoney) {
        this.additionalMoney = additionalMoney;
    }

    /**
     * 自费
     * @return 
     */
    public BigDecimal getSelfMoney() {
        return selfMoney;
    }

    /**
     * 自费
     * @param selfMoney
     */
    public void setSelfMoney(BigDecimal selfMoney) {
        this.selfMoney = selfMoney;
    }

    /**
     * 分类自负
     * @return 
     */
    public BigDecimal getClassifyMoney() {
        return classifyMoney;
    }

    /**
     * 分类自负
     * @param classifyMoney
     */
    public void setClassifyMoney(BigDecimal classifyMoney) {
        this.classifyMoney = classifyMoney;
    }

    /**
     * 合计
     * @return 
     */
    public BigDecimal getTotal() {
        return total;
    }

    /**
     * 合计
     * @param total
     */
    public void setTotal(BigDecimal total) {
        this.total = total;
    }

    /**
     * 是否复核过
     * @return 
     */
    public String getIsVerify() {
        return isVerify;
    }

    /**
     * 是否复核过
     * @param isVerify
     */
    public void setIsVerify(String isVerify) {
        this.isVerify = isVerify == null ? null : isVerify.trim();
    }

    /**
     * 创建人
     * @return 
     */
    public String getCreator() {
        return creator;
    }

    /**
     * 创建人
     * @param creator
     */
    public void setCreator(String creator) {
        this.creator = creator == null ? null : creator.trim();
    }

    /**
     * 创建时间
     * @return 
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 创建时间
     * @param createTime
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 修改人
     * @return 
     */
    public String getModifier() {
        return modifier;
    }

    /**
     * 修改人
     * @param modifier
     */
    public void setModifier(String modifier) {
        this.modifier = modifier == null ? null : modifier.trim();
    }

    /**
     * 修改时间
     * @return 
     */
    public Date getModifyTime() {
        return modifyTime;
    }

    /**
     * 修改时间
     * @param modifyTime
     */
    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }
}