package com.qucai.kp.entity;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 理赔录入项目信息表
 * 
 * @version 1.0 2017-07-22
 */
public class ClaimReceiptDetail {
    /**
     * id
     */
    private String id;

    /**
     * 理赔申请录入id
     */
    private String claimReceiptId;

    /**
     * 给付责任代码
     */
    private String dutyCode;

    /**
     * 给付责任名称
     */
    private String dutyName;

    /**
     * 项目代码
     */
    private String itemCode;

    /**
     * 项目金额
     */
    private BigDecimal itemFee;

    /**
     * 创建人
     */
    private String creator;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改人
     */
    private String modifier;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * id
     * @return 
     */
    public String getId() {
        return id;
    }

    /**
     * id
     * @param id
     */
    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    /**
     * 理赔申请录入id
     * @return 
     */
    public String getClaimReceiptId() {
        return claimReceiptId;
    }

    /**
     * 理赔申请录入id
     * @param claimReceiptId
     */
    public void setClaimReceiptId(String claimReceiptId) {
        this.claimReceiptId = claimReceiptId == null ? null : claimReceiptId.trim();
    }

    /**
     * 给付责任代码
     * @return 
     */
    public String getDutyCode() {
        return dutyCode;
    }

    /**
     * 给付责任代码
     * @param dutyCode
     */
    public void setDutyCode(String dutyCode) {
        this.dutyCode = dutyCode == null ? null : dutyCode.trim();
    }

    /**
     * 给付责任名称
     * @return 
     */
    public String getDutyName() {
        return dutyName;
    }

    /**
     * 给付责任名称
     * @param dutyName
     */
    public void setDutyName(String dutyName) {
        this.dutyName = dutyName == null ? null : dutyName.trim();
    }

    /**
     * 项目代码
     * @return 
     */
    public String getItemCode() {
        return itemCode;
    }

    /**
     * 项目代码
     * @param itemCode
     */
    public void setItemCode(String itemCode) {
        this.itemCode = itemCode == null ? null : itemCode.trim();
    }

    /**
     * 项目金额
     * @return 
     */
    public BigDecimal getItemFee() {
        return itemFee;
    }

    /**
     * 项目金额
     * @param itemFee
     */
    public void setItemFee(BigDecimal itemFee) {
        this.itemFee = itemFee;
    }

    /**
     * 创建人
     * @return 
     */
    public String getCreator() {
        return creator;
    }

    /**
     * 创建人
     * @param creator
     */
    public void setCreator(String creator) {
        this.creator = creator == null ? null : creator.trim();
    }

    /**
     * 创建时间
     * @return 
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 创建时间
     * @param createTime
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 修改人
     * @return 
     */
    public String getModifier() {
        return modifier;
    }

    /**
     * 修改人
     * @param modifier
     */
    public void setModifier(String modifier) {
        this.modifier = modifier == null ? null : modifier.trim();
    }

    /**
     * 修改时间
     * @return 
     */
    public Date getModifyTime() {
        return modifyTime;
    }

    /**
     * 修改时间
     * @param modifyTime
     */
    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }
}