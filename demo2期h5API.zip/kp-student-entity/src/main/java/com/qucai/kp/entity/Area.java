package com.qucai.kp.entity;

/**
 * 地区信息表
 * 
 * @version 1.0 2017-07-22
 */
public class Area {
    /**
     * id
     */
    private String id;

    /**
     * 代码
     */
    private String code;

    /**
     * 名称
     */
    private String name;

    /**
     * 上级ID
     */
    private String parentId;

    /**
     * id
     * @return 
     */
    public String getId() {
        return id;
    }

    /**
     * id
     * @param id
     */
    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    /**
     * 代码
     * @return 
     */
    public String getCode() {
        return code;
    }

    /**
     * 代码
     * @param code
     */
    public void setCode(String code) {
        this.code = code == null ? null : code.trim();
    }

    /**
     * 名称
     * @return 
     */
    public String getName() {
        return name;
    }

    /**
     * 名称
     * @param name
     */
    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    /**
     * 上级ID
     * @return 
     */
    public String getParentId() {
        return parentId;
    }

    /**
     * 上级ID
     * @param parentId
     */
    public void setParentId(String parentId) {
        this.parentId = parentId == null ? null : parentId.trim();
    }
}