package com.qucai.kp.entity;

import java.util.Date;

/**
 * 咨询内容表
 * 
 * @version 1.0 2017-07-22
 */
public class QandaContent {
    /**
     * id
     */
    private String id;

    /**
     * 咨询主题id
     */
    private String qandaTopicId;

    /**
     * 内容
     */
    private String content;

    /**
     * 是否用户留言（0：否；1：是）
     */
    private Integer isUserMsg;

    /**
     * 创建人
     */
    private String creator;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * id
     * @return 
     */
    public String getId() {
        return id;
    }

    /**
     * id
     * @param id
     */
    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    /**
     * 咨询主题id
     * @return 
     */
    public String getQandaTopicId() {
        return qandaTopicId;
    }

    /**
     * 咨询主题id
     * @param qandaTopicId
     */
    public void setQandaTopicId(String qandaTopicId) {
        this.qandaTopicId = qandaTopicId == null ? null : qandaTopicId.trim();
    }

    /**
     * 内容
     * @return 
     */
    public String getContent() {
        return content;
    }

    /**
     * 内容
     * @param content
     */
    public void setContent(String content) {
        this.content = content == null ? null : content.trim();
    }

    /**
     * 是否用户留言（0：否；1：是）
     * @return 
     */
    public Integer getIsUserMsg() {
        return isUserMsg;
    }

    /**
     * 是否用户留言（0：否；1：是）
     * @param isUserMsg
     */
    public void setIsUserMsg(Integer isUserMsg) {
        this.isUserMsg = isUserMsg;
    }

    /**
     * 创建人
     * @return 
     */
    public String getCreator() {
        return creator;
    }

    /**
     * 创建人
     * @param creator
     */
    public void setCreator(String creator) {
        this.creator = creator == null ? null : creator.trim();
    }

    /**
     * 创建时间
     * @return 
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 创建时间
     * @param createTime
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
}