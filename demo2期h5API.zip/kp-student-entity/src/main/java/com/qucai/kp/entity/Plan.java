package com.qucai.kp.entity;

import java.util.Date;

/**
 * 方案表
 * 
 * @version 1.0 2017-07-22
 */
public class Plan {
    /**
     * id
     */
    private String id;

    /**
     * 方案名称
     */
    private String name;

    /**
     * 方案代码
     */
    private String code;

    /**
     * 保期
     */
    private Integer limitTime;

    /**
     * 保期类型（0：月；1：季度；2：年）
     */
    private String limitType;

    /**
     * 方案使用最低年龄
     */
    private Integer limitLowAge;

    /**
     * 方案使用最高年龄
     */
    private Integer limitHighAge;

    /**
     * 购买最高份数
     */
    private Integer maxCopies;

    /**
     * 创建人
     */
    private String creator;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改人
     */
    private String modifier;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * id
     * @return 
     */
    public String getId() {
        return id;
    }

    /**
     * id
     * @param id
     */
    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    /**
     * 方案名称
     * @return 
     */
    public String getName() {
        return name;
    }

    /**
     * 方案名称
     * @param name
     */
    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    /**
     * 方案代码
     * @return 
     */
    public String getCode() {
        return code;
    }

    /**
     * 方案代码
     * @param code
     */
    public void setCode(String code) {
        this.code = code == null ? null : code.trim();
    }

    /**
     * 保期
     * @return 
     */
    public Integer getLimitTime() {
        return limitTime;
    }

    /**
     * 保期
     * @param limitTime
     */
    public void setLimitTime(Integer limitTime) {
        this.limitTime = limitTime;
    }

    /**
     * 保期类型（0：月；1：季度；2：年）
     * @return 
     */
    public String getLimitType() {
        return limitType;
    }

    /**
     * 保期类型（0：月；1：季度；2：年）
     * @param limitType
     */
    public void setLimitType(String limitType) {
        this.limitType = limitType == null ? null : limitType.trim();
    }

    /**
     * 方案使用最低年龄
     * @return 
     */
    public Integer getLimitLowAge() {
        return limitLowAge;
    }

    /**
     * 方案使用最低年龄
     * @param limitLowAge
     */
    public void setLimitLowAge(Integer limitLowAge) {
        this.limitLowAge = limitLowAge;
    }

    /**
     * 方案使用最高年龄
     * @return 
     */
    public Integer getLimitHighAge() {
        return limitHighAge;
    }

    /**
     * 方案使用最高年龄
     * @param limitHighAge
     */
    public void setLimitHighAge(Integer limitHighAge) {
        this.limitHighAge = limitHighAge;
    }

    /**
     * 购买最高份数
     * @return 
     */
    public Integer getMaxCopies() {
        return maxCopies;
    }

    /**
     * 购买最高份数
     * @param maxCopies
     */
    public void setMaxCopies(Integer maxCopies) {
        this.maxCopies = maxCopies;
    }

    /**
     * 创建人
     * @return 
     */
    public String getCreator() {
        return creator;
    }

    /**
     * 创建人
     * @param creator
     */
    public void setCreator(String creator) {
        this.creator = creator == null ? null : creator.trim();
    }

    /**
     * 创建时间
     * @return 
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 创建时间
     * @param createTime
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 修改人
     * @return 
     */
    public String getModifier() {
        return modifier;
    }

    /**
     * 修改人
     * @param modifier
     */
    public void setModifier(String modifier) {
        this.modifier = modifier == null ? null : modifier.trim();
    }

    /**
     * 修改时间
     * @return 
     */
    public Date getModifyTime() {
        return modifyTime;
    }

    /**
     * 修改时间
     * @param modifyTime
     */
    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }
}