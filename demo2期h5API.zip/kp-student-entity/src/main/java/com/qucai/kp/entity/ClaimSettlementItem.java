package com.qucai.kp.entity;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 理赔录入结果项目信息表
 * 
 * @version 1.0 2017-07-22
 */
public class ClaimSettlementItem {
    /**
     * id
     */
    private String id;

    /**
     * 理赔录入信息表id
     */
    private String claimReceiptId;

    /**
     * 给付责任代码
     */
    private String dutyCode;

    /**
     * 给付责任保额
     */
    private BigDecimal dutyAmount;

    /**
     * 给付责任剩余保额
     */
    private BigDecimal dutyRemainedAmount;

    /**
     * 给付责任理算给付金额
     */
    private BigDecimal approvedMoney;

    /**
     * 给付责任拒付金额
     */
    private BigDecimal refusedAmount;

    /**
     * 备注
     */
    private String remark;

    /**
     * 创建人
     */
    private String creator;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改人
     */
    private String modifier;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * id
     * @return 
     */
    public String getId() {
        return id;
    }

    /**
     * id
     * @param id
     */
    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    /**
     * 理赔录入信息表id
     * @return 
     */
    public String getClaimReceiptId() {
        return claimReceiptId;
    }

    /**
     * 理赔录入信息表id
     * @param claimReceiptId
     */
    public void setClaimReceiptId(String claimReceiptId) {
        this.claimReceiptId = claimReceiptId == null ? null : claimReceiptId.trim();
    }

    /**
     * 给付责任代码
     * @return 
     */
    public String getDutyCode() {
        return dutyCode;
    }

    /**
     * 给付责任代码
     * @param dutyCode
     */
    public void setDutyCode(String dutyCode) {
        this.dutyCode = dutyCode == null ? null : dutyCode.trim();
    }

    /**
     * 给付责任保额
     * @return 
     */
    public BigDecimal getDutyAmount() {
        return dutyAmount;
    }

    /**
     * 给付责任保额
     * @param dutyAmount
     */
    public void setDutyAmount(BigDecimal dutyAmount) {
        this.dutyAmount = dutyAmount;
    }

    /**
     * 给付责任剩余保额
     * @return 
     */
    public BigDecimal getDutyRemainedAmount() {
        return dutyRemainedAmount;
    }

    /**
     * 给付责任剩余保额
     * @param dutyRemainedAmount
     */
    public void setDutyRemainedAmount(BigDecimal dutyRemainedAmount) {
        this.dutyRemainedAmount = dutyRemainedAmount;
    }

    /**
     * 给付责任理算给付金额
     * @return 
     */
    public BigDecimal getApprovedMoney() {
        return approvedMoney;
    }

    /**
     * 给付责任理算给付金额
     * @param approvedMoney
     */
    public void setApprovedMoney(BigDecimal approvedMoney) {
        this.approvedMoney = approvedMoney;
    }

    /**
     * 给付责任拒付金额
     * @return 
     */
    public BigDecimal getRefusedAmount() {
        return refusedAmount;
    }

    /**
     * 给付责任拒付金额
     * @param refusedAmount
     */
    public void setRefusedAmount(BigDecimal refusedAmount) {
        this.refusedAmount = refusedAmount;
    }

    /**
     * 备注
     * @return 
     */
    public String getRemark() {
        return remark;
    }

    /**
     * 备注
     * @param remark
     */
    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    /**
     * 创建人
     * @return 
     */
    public String getCreator() {
        return creator;
    }

    /**
     * 创建人
     * @param creator
     */
    public void setCreator(String creator) {
        this.creator = creator == null ? null : creator.trim();
    }

    /**
     * 创建时间
     * @return 
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 创建时间
     * @param createTime
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 修改人
     * @return 
     */
    public String getModifier() {
        return modifier;
    }

    /**
     * 修改人
     * @param modifier
     */
    public void setModifier(String modifier) {
        this.modifier = modifier == null ? null : modifier.trim();
    }

    /**
     * 修改时间
     * @return 
     */
    public Date getModifyTime() {
        return modifyTime;
    }

    /**
     * 修改时间
     * @param modifyTime
     */
    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }
}