package com.qucai.kp.entity;

/**
 * 系统字典表
 * 
 * @version 1.0 2017-07-22
 */
public class Dict {
    /**
     * id
     */
    private String id;

    /**
     * 值
     */
    private String dvalue;

    /**
     * 显示标签
     */
    private String dlabel;

    /**
     * 类型
     */
    private String type;

    /**
     * 备注
     */
    private String remark;

    /**
     * id
     * @return 
     */
    public String getId() {
        return id;
    }

    /**
     * id
     * @param id
     */
    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    /**
     * 值
     * @return 
     */
    public String getDvalue() {
        return dvalue;
    }

    /**
     * 值
     * @param dvalue
     */
    public void setDvalue(String dvalue) {
        this.dvalue = dvalue == null ? null : dvalue.trim();
    }

    /**
     * 显示标签
     * @return 
     */
    public String getDlabel() {
        return dlabel;
    }

    /**
     * 显示标签
     * @param dlabel
     */
    public void setDlabel(String dlabel) {
        this.dlabel = dlabel == null ? null : dlabel.trim();
    }

    /**
     * 类型
     * @return 
     */
    public String getType() {
        return type;
    }

    /**
     * 类型
     * @param type
     */
    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    /**
     * 备注
     * @return 
     */
    public String getRemark() {
        return remark;
    }

    /**
     * 备注
     * @param remark
     */
    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }
}