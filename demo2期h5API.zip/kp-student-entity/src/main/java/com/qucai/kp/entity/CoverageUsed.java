package com.qucai.kp.entity;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 保额使用信息
 * 
 * @version 1.0 2017-07-25
 */
public class CoverageUsed {
    /**
     * id
     */
    private String id;

    /**
     * 方案ID
     */
    private String planId;

    /**
     * 保单ID
     */
    private String policyId;

    /**
     * 方案组险种id
     */
    private String planClassId;

    /**
     * 险种额度
     */
    private BigDecimal coverage;

    /**
     * 险种使用额度
     */
    private BigDecimal coverageUsed;

    /**
     * 险种剩余额度
     */
    private BigDecimal coverageRemaind;

    /**
     * 创建人
     */
    private String creator;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改人
     */
    private String modifier;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * id
     * @return 
     */
    public String getId() {
        return id;
    }

    /**
     * id
     * @param id
     */
    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    /**
     * 方案ID
     * @return 
     */
    public String getPlanId() {
        return planId;
    }

    /**
     * 方案ID
     * @param planId
     */
    public void setPlanId(String planId) {
        this.planId = planId == null ? null : planId.trim();
    }

    /**
     * 保单ID
     * @return 
     */
    public String getPolicyId() {
        return policyId;
    }

    /**
     * 保单ID
     * @param policyId
     */
    public void setPolicyId(String policyId) {
        this.policyId = policyId == null ? null : policyId.trim();
    }

    /**
     * 方案组险种id
     * @return 
     */
    public String getPlanClassId() {
        return planClassId;
    }

    /**
     * 方案组险种id
     * @param planClassId
     */
    public void setPlanClassId(String planClassId) {
        this.planClassId = planClassId == null ? null : planClassId.trim();
    }

    /**
     * 险种额度
     * @return 
     */
    public BigDecimal getCoverage() {
        return coverage;
    }

    /**
     * 险种额度
     * @param coverage
     */
    public void setCoverage(BigDecimal coverage) {
        this.coverage = coverage;
    }

    /**
     * 险种使用额度
     * @return 
     */
    public BigDecimal getCoverageUsed() {
        return coverageUsed;
    }

    /**
     * 险种使用额度
     * @param coverageUsed
     */
    public void setCoverageUsed(BigDecimal coverageUsed) {
        this.coverageUsed = coverageUsed;
    }

    /**
     * 险种剩余额度
     * @return 
     */
    public BigDecimal getCoverageRemaind() {
        return coverageRemaind;
    }

    /**
     * 险种剩余额度
     * @param coverageRemaind
     */
    public void setCoverageRemaind(BigDecimal coverageRemaind) {
        this.coverageRemaind = coverageRemaind;
    }

    /**
     * 创建人
     * @return 
     */
    public String getCreator() {
        return creator;
    }

    /**
     * 创建人
     * @param creator
     */
    public void setCreator(String creator) {
        this.creator = creator == null ? null : creator.trim();
    }

    /**
     * 创建时间
     * @return 
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 创建时间
     * @param createTime
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 修改人
     * @return 
     */
    public String getModifier() {
        return modifier;
    }

    /**
     * 修改人
     * @param modifier
     */
    public void setModifier(String modifier) {
        this.modifier = modifier == null ? null : modifier.trim();
    }

    /**
     * 修改时间
     * @return 
     */
    public Date getModifyTime() {
        return modifyTime;
    }

    /**
     * 修改时间
     * @param modifyTime
     */
    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }
}