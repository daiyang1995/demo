package com.qucai.kp.entity;

import java.util.Date;

/**
 * 用户银行卡信息表
 * 
 * @version 1.0 2017-09-01
 */
public class UserBank {
    /**
     * id
     */
    private String id;

    /**
     * 用户id（天天艾米用户ID）
     */
    private String userId;

    /**
     * 银行名称
     */
    private String bankName;

    /**
     * 银行户名
     */
    private String bankAccount;

    /**
     * 银行卡号
     */
    private String bankCard;

    private String accounttype;

    private String accountimg;

    /**
     * 备注
     */
    private String remark;

    private Integer isdefault;

    /**
     * 创建人
     */
    private String creator;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改人
     */
    private String modifier;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * id
     * @return 
     */
    public String getId() {
        return id;
    }

    /**
     * id
     * @param id
     */
    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    /**
     * 用户id（天天艾米用户ID）
     * @return 
     */
    public String getUserId() {
        return userId;
    }

    /**
     * 用户id（天天艾米用户ID）
     * @param userId
     */
    public void setUserId(String userId) {
        this.userId = userId == null ? null : userId.trim();
    }

    /**
     * 银行名称
     * @return 
     */
    public String getBankName() {
        return bankName;
    }

    /**
     * 银行名称
     * @param bankName
     */
    public void setBankName(String bankName) {
        this.bankName = bankName == null ? null : bankName.trim();
    }

    /**
     * 银行户名
     * @return 
     */
    public String getBankAccount() {
        return bankAccount;
    }

    /**
     * 银行户名
     * @param bankAccount
     */
    public void setBankAccount(String bankAccount) {
        this.bankAccount = bankAccount == null ? null : bankAccount.trim();
    }

    /**
     * 银行卡号
     * @return 
     */
    public String getBankCard() {
        return bankCard;
    }

    /**
     * 银行卡号
     * @param bankCard
     */
    public void setBankCard(String bankCard) {
        this.bankCard = bankCard == null ? null : bankCard.trim();
    }

    public String getAccounttype() {
        return accounttype;
    }

    public void setAccounttype(String accounttype) {
        this.accounttype = accounttype == null ? null : accounttype.trim();
    }

    public String getAccountimg() {
        return accountimg;
    }

    public void setAccountimg(String accountimg) {
        this.accountimg = accountimg == null ? null : accountimg.trim();
    }

    /**
     * 备注
     * @return 
     */
    public String getRemark() {
        return remark;
    }

    /**
     * 备注
     * @param remark
     */
    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public Integer getIsdefault() {
        return isdefault;
    }

    public void setIsdefault(Integer isdefault) {
        this.isdefault = isdefault;
    }

    /**
     * 创建人
     * @return 
     */
    public String getCreator() {
        return creator;
    }

    /**
     * 创建人
     * @param creator
     */
    public void setCreator(String creator) {
        this.creator = creator == null ? null : creator.trim();
    }

    /**
     * 创建时间
     * @return 
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 创建时间
     * @param createTime
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 修改人
     * @return 
     */
    public String getModifier() {
        return modifier;
    }

    /**
     * 修改人
     * @param modifier
     */
    public void setModifier(String modifier) {
        this.modifier = modifier == null ? null : modifier.trim();
    }

    /**
     * 修改时间
     * @return 
     */
    public Date getModifyTime() {
        return modifyTime;
    }

    /**
     * 修改时间
     * @param modifyTime
     */
    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }
}