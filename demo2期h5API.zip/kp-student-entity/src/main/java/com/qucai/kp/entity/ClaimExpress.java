package com.qucai.kp.entity;

import java.util.Date;

/**
 * 理赔管理-报案申请快递
 * 
 * @version 1.0 2017-07-27
 */
public class ClaimExpress {
    /**
     * id
     */
    private String id;

    /**
     * 案件id
     */
    private String claimApplyId;

    /**
     * 地址id
     */
    private String planAddressId;

    /**
     * 递交方式（0：快递；1：驻点）
     */
    private Integer submitType;

    /**
     * 快递公司
     */
    private String carrier;

    /**
     * 快递单号
     */
    private String trackingNo;

    /**
     * 接收人
     */
    private String recipient;

    /**
     * 接收人电话
     */
    private String receiveTelephone;

    /**
     * 状态（0：已提交；1：已收件；2：已退回）
     */
    private Integer status;

    /**
     * 备注
     */
    private String remark;

    /**
     * 创建人
     */
    private String creator;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改人
     */
    private String modifier;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * id
     * @return 
     */
    public String getId() {
        return id;
    }

    /**
     * id
     * @param id
     */
    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    /**
     * 案件id
     * @return 
     */
    public String getClaimApplyId() {
        return claimApplyId;
    }

    /**
     * 案件id
     * @param claimApplyId
     */
    public void setClaimApplyId(String claimApplyId) {
        this.claimApplyId = claimApplyId == null ? null : claimApplyId.trim();
    }

    /**
     * 地址id
     * @return 
     */
    public String getPlanAddressId() {
        return planAddressId;
    }

    /**
     * 地址id
     * @param planAddressId
     */
    public void setPlanAddressId(String planAddressId) {
        this.planAddressId = planAddressId == null ? null : planAddressId.trim();
    }

    /**
     * 递交方式（0：快递；1：驻点）
     * @return 
     */
    public Integer getSubmitType() {
        return submitType;
    }

    /**
     * 递交方式（0：快递；1：驻点）
     * @param submitType
     */
    public void setSubmitType(Integer submitType) {
        this.submitType = submitType;
    }

    /**
     * 快递公司
     * @return 
     */
    public String getCarrier() {
        return carrier;
    }

    /**
     * 快递公司
     * @param carrier
     */
    public void setCarrier(String carrier) {
        this.carrier = carrier == null ? null : carrier.trim();
    }

    /**
     * 快递单号
     * @return 
     */
    public String getTrackingNo() {
        return trackingNo;
    }

    /**
     * 快递单号
     * @param trackingNo
     */
    public void setTrackingNo(String trackingNo) {
        this.trackingNo = trackingNo == null ? null : trackingNo.trim();
    }

    /**
     * 接收人
     * @return 
     */
    public String getRecipient() {
        return recipient;
    }

    /**
     * 接收人
     * @param recipient
     */
    public void setRecipient(String recipient) {
        this.recipient = recipient == null ? null : recipient.trim();
    }

    /**
     * 接收人电话
     * @return 
     */
    public String getReceiveTelephone() {
        return receiveTelephone;
    }

    /**
     * 接收人电话
     * @param receiveTelephone
     */
    public void setReceiveTelephone(String receiveTelephone) {
        this.receiveTelephone = receiveTelephone == null ? null : receiveTelephone.trim();
    }

    /**
     * 状态（0：已提交；1：已收件；2：已退回）
     * @return 
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * 状态（0：已提交；1：已收件；2：已退回）
     * @param status
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     * 备注
     * @return 
     */
    public String getRemark() {
        return remark;
    }

    /**
     * 备注
     * @param remark
     */
    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    /**
     * 创建人
     * @return 
     */
    public String getCreator() {
        return creator;
    }

    /**
     * 创建人
     * @param creator
     */
    public void setCreator(String creator) {
        this.creator = creator == null ? null : creator.trim();
    }

    /**
     * 创建时间
     * @return 
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 创建时间
     * @param createTime
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 修改人
     * @return 
     */
    public String getModifier() {
        return modifier;
    }

    /**
     * 修改人
     * @param modifier
     */
    public void setModifier(String modifier) {
        this.modifier = modifier == null ? null : modifier.trim();
    }

    /**
     * 修改时间
     * @return 
     */
    public Date getModifyTime() {
        return modifyTime;
    }

    /**
     * 修改时间
     * @param modifyTime
     */
    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }
}