package com.qucai.kp.entity;

import java.util.Date;

/**
 * 咨询表
 * 
 * @version 1.0 2017-07-25
 */
public class Consult {
    /**
     * id
     */
    private String id;
    
    /**
     * 咨询编号
     */
    private String consultNo;

    /**
     * 类型
     */
    private String type;

    /**
     * 状态
     */
    private String status;

    /**
     * 紧急程度
     */
    private String level;

    /**
     * 方式
     */
    private String method;

    /**
     * 咨询人
     */
    private String name;
    
    /**
     * 咨询人性别
     */
    private String gender;

    /**
     * 咨询人联系方式
     */
    private String telephone;

    /**
     * 被保险人id
     */
    private String insuredId;
    
    /**
     * 与被保险人关系
     */
    private String insuredRelation;

    /**
     * 咨询内容
     */
    private String content;

    /**
     * 创建人
     */
    private String creator;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改人
     */
    private String modifier;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * id
     * @return 
     */
    public String getId() {
        return id;
    }

    /**
     * id
     * @param id
     */
    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    /**
     * 类型
     * @return 
     */
    public String getType() {
        return type;
    }

    /**
     * 类型
     * @param type
     */
    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    /**
     * 状态
     * @return 
     */
    public String getStatus() {
        return status;
    }

    /**
     * 状态
     * @param status
     */
    public void setStatus(String status) {
        this.status = status == null ? null : status.trim();
    }

    /**
     * 紧急程度
     * @return 
     */
    public String getLevel() {
        return level;
    }

    /**
     * 紧急程度
     * @param level
     */
    public void setLevel(String level) {
        this.level = level == null ? null : level.trim();
    }

    /**
     * 方式
     * @return 
     */
    public String getMethod() {
        return method;
    }

    /**
     * 方式
     * @param method
     */
    public void setMethod(String method) {
        this.method = method == null ? null : method.trim();
    }

    /**
     * 咨询人
     * @return 
     */
    public String getName() {
        return name;
    }

    /**
     * 咨询人
     * @param name
     */
    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    /**
     * 咨询人联系方式
     * @return 
     */
    public String getTelephone() {
        return telephone;
    }

    /**
     * 咨询人联系方式
     * @param telephone
     */
    public void setTelephone(String telephone) {
        this.telephone = telephone == null ? null : telephone.trim();
    }

    /**
     * 被保险人id
     * @return 
     */
    public String getInsuredId() {
        return insuredId;
    }

    /**
     * 被保险人id
     * @param insuredId
     */
    public void setInsuredId(String insuredId) {
        this.insuredId = insuredId == null ? null : insuredId.trim();
    }

    /**
     * 咨询内容
     * @return 
     */
    public String getContent() {
        return content;
    }

    /**
     * 咨询内容
     * @param content
     */
    public void setContent(String content) {
        this.content = content == null ? null : content.trim();
    }

    /**
     * 创建人
     * @return 
     */
    public String getCreator() {
        return creator;
    }

    /**
     * 创建人
     * @param creator
     */
    public void setCreator(String creator) {
        this.creator = creator == null ? null : creator.trim();
    }

    /**
     * 创建时间
     * @return 
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 创建时间
     * @param createTime
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 修改人
     * @return 
     */
    public String getModifier() {
        return modifier;
    }

    /**
     * 修改人
     * @param modifier
     */
    public void setModifier(String modifier) {
        this.modifier = modifier == null ? null : modifier.trim();
    }

    /**
     * 修改时间
     * @return 
     */
    public Date getModifyTime() {
        return modifyTime;
    }

    /**
     * 修改时间
     * @param modifyTime
     */
    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public String getConsultNo() {
        return consultNo;
    }

    public void setConsultNo(String consultNo) {
        this.consultNo = consultNo;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getInsuredRelation() {
        return insuredRelation;
    }

    public void setInsuredRelation(String insuredRelation) {
        this.insuredRelation = insuredRelation;
    }
    
}