package com.qucai.kp.entity;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 理赔拆分项目表
 * 
 * @version 1.0 2017-07-22
 */
public class SplitItemFee {
    /**
     * id
     */
    private String id;

    /**
     * 方案ID
     */
    private String planId;

    /**
     * 保单ID
     */
    private String policyId;

    /**
     * 理赔申请id
     */
    private String claimReceiptId;

    /**
     * 给付责任代码
     */
    private String dutyCode;

    /**
     * 给付责任名称
     */
    private String dutyName;

    /**
     * 项目代码
     */
    private String itemCode;

    /**
     * 项目名称
     */
    private String itemName;

    /**
     * 项目金额
     */
    private BigDecimal itemFee;

    /**
     * 项目扣除金额
     */
    private BigDecimal itemFeeRefused;

    /**
     * 项目使用免赔额
     */
    private BigDecimal itemFeeDeducibled;

    /**
     * 项目赔付金额
     */
    private BigDecimal itemFeeApproved;

    /**
     * 创建人
     */
    private String creator;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改人
     */
    private String modifier;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * id
     * @return 
     */
    public String getId() {
        return id;
    }

    /**
     * id
     * @param id
     */
    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    /**
     * 方案ID
     * @return 
     */
    public String getPlanId() {
        return planId;
    }

    /**
     * 方案ID
     * @param planId
     */
    public void setPlanId(String planId) {
        this.planId = planId == null ? null : planId.trim();
    }

    /**
     * 保单ID
     * @return 
     */
    public String getPolicyId() {
        return policyId;
    }

    /**
     * 保单ID
     * @param policyId
     */
    public void setPolicyId(String policyId) {
        this.policyId = policyId == null ? null : policyId.trim();
    }

    /**
     * 理赔申请id
     * @return 
     */
    public String getClaimReceiptId() {
        return claimReceiptId;
    }

    /**
     * 理赔申请id
     * @param claimReceiptId
     */
    public void setClaimReceiptId(String claimReceiptId) {
        this.claimReceiptId = claimReceiptId == null ? null : claimReceiptId.trim();
    }

    /**
     * 给付责任代码
     * @return 
     */
    public String getDutyCode() {
        return dutyCode;
    }

    /**
     * 给付责任代码
     * @param dutyCode
     */
    public void setDutyCode(String dutyCode) {
        this.dutyCode = dutyCode == null ? null : dutyCode.trim();
    }

    /**
     * 给付责任名称
     * @return 
     */
    public String getDutyName() {
        return dutyName;
    }

    /**
     * 给付责任名称
     * @param dutyName
     */
    public void setDutyName(String dutyName) {
        this.dutyName = dutyName == null ? null : dutyName.trim();
    }

    /**
     * 项目代码
     * @return 
     */
    public String getItemCode() {
        return itemCode;
    }

    /**
     * 项目代码
     * @param itemCode
     */
    public void setItemCode(String itemCode) {
        this.itemCode = itemCode == null ? null : itemCode.trim();
    }

    /**
     * 项目名称
     * @return 
     */
    public String getItemName() {
        return itemName;
    }

    /**
     * 项目名称
     * @param itemName
     */
    public void setItemName(String itemName) {
        this.itemName = itemName == null ? null : itemName.trim();
    }

    /**
     * 项目金额
     * @return 
     */
    public BigDecimal getItemFee() {
        return itemFee;
    }

    /**
     * 项目金额
     * @param itemFee
     */
    public void setItemFee(BigDecimal itemFee) {
        this.itemFee = itemFee;
    }

    /**
     * 项目扣除金额
     * @return 
     */
    public BigDecimal getItemFeeRefused() {
        return itemFeeRefused;
    }

    /**
     * 项目扣除金额
     * @param itemFeeRefused
     */
    public void setItemFeeRefused(BigDecimal itemFeeRefused) {
        this.itemFeeRefused = itemFeeRefused;
    }

    /**
     * 项目使用免赔额
     * @return 
     */
    public BigDecimal getItemFeeDeducibled() {
        return itemFeeDeducibled;
    }

    /**
     * 项目使用免赔额
     * @param itemFeeDeducibled
     */
    public void setItemFeeDeducibled(BigDecimal itemFeeDeducibled) {
        this.itemFeeDeducibled = itemFeeDeducibled;
    }

    /**
     * 项目赔付金额
     * @return 
     */
    public BigDecimal getItemFeeApproved() {
        return itemFeeApproved;
    }

    /**
     * 项目赔付金额
     * @param itemFeeApproved
     */
    public void setItemFeeApproved(BigDecimal itemFeeApproved) {
        this.itemFeeApproved = itemFeeApproved;
    }

    /**
     * 创建人
     * @return 
     */
    public String getCreator() {
        return creator;
    }

    /**
     * 创建人
     * @param creator
     */
    public void setCreator(String creator) {
        this.creator = creator == null ? null : creator.trim();
    }

    /**
     * 创建时间
     * @return 
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 创建时间
     * @param createTime
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 修改人
     * @return 
     */
    public String getModifier() {
        return modifier;
    }

    /**
     * 修改人
     * @param modifier
     */
    public void setModifier(String modifier) {
        this.modifier = modifier == null ? null : modifier.trim();
    }

    /**
     * 修改时间
     * @return 
     */
    public Date getModifyTime() {
        return modifyTime;
    }

    /**
     * 修改时间
     * @param modifyTime
     */
    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }
}