package com.qucai.kp.entity;

import java.util.Date;

/**
 * 方案影像审核规则
 * 
 * @version 1.0 2017-08-08
 */
public class PlanImageVerifyRule {
    /**
     * id
     */
    private String id;

    /**
     * 方案/计划id
     */
    private String planId;

    /**
     * 出险类型
     */
    private String claimType;

    /**
     * 影像大类
     */
    private String imageType;

    /**
     * 是否原件（0：否；1：是）
     */
    private Integer isMasterCopy;

    /**
     * 是否清晰（0：否；1：是）
     */
    private Integer isClear;

    /**
     * 表达式（使用aviator解析）
     */
    private String expression;

    /**
     * 备注
     */
    private String remark;

    /**
     * 创建人
     */
    private String creator;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改人
     */
    private String modifier;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * id
     * @return 
     */
    public String getId() {
        return id;
    }

    /**
     * id
     * @param id
     */
    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    /**
     * 方案/计划id
     * @return 
     */
    public String getPlanId() {
        return planId;
    }

    /**
     * 方案/计划id
     * @param planId
     */
    public void setPlanId(String planId) {
        this.planId = planId == null ? null : planId.trim();
    }

    /**
     * 出险类型
     * @return 
     */
    public String getClaimType() {
        return claimType;
    }

    /**
     * 出险类型
     * @param claimType
     */
    public void setClaimType(String claimType) {
        this.claimType = claimType == null ? null : claimType.trim();
    }

    /**
     * 影像大类
     * @return 
     */
    public String getImageType() {
        return imageType;
    }

    /**
     * 影像大类
     * @param imageType
     */
    public void setImageType(String imageType) {
        this.imageType = imageType == null ? null : imageType.trim();
    }

    /**
     * 是否原件（0：否；1：是）
     * @return 
     */
    public Integer getIsMasterCopy() {
        return isMasterCopy;
    }

    /**
     * 是否原件（0：否；1：是）
     * @param isMasterCopy
     */
    public void setIsMasterCopy(Integer isMasterCopy) {
        this.isMasterCopy = isMasterCopy;
    }

    /**
     * 是否清晰（0：否；1：是）
     * @return 
     */
    public Integer getIsClear() {
        return isClear;
    }

    /**
     * 是否清晰（0：否；1：是）
     * @param isClear
     */
    public void setIsClear(Integer isClear) {
        this.isClear = isClear;
    }

    /**
     * 表达式（使用aviator解析）
     * @return 
     */
    public String getExpression() {
        return expression;
    }

    /**
     * 表达式（使用aviator解析）
     * @param expression
     */
    public void setExpression(String expression) {
        this.expression = expression == null ? null : expression.trim();
    }

    /**
     * 备注
     * @return 
     */
    public String getRemark() {
        return remark;
    }

    /**
     * 备注
     * @param remark
     */
    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    /**
     * 创建人
     * @return 
     */
    public String getCreator() {
        return creator;
    }

    /**
     * 创建人
     * @param creator
     */
    public void setCreator(String creator) {
        this.creator = creator == null ? null : creator.trim();
    }

    /**
     * 创建时间
     * @return 
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 创建时间
     * @param createTime
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 修改人
     * @return 
     */
    public String getModifier() {
        return modifier;
    }

    /**
     * 修改人
     * @param modifier
     */
    public void setModifier(String modifier) {
        this.modifier = modifier == null ? null : modifier.trim();
    }

    /**
     * 修改时间
     * @return 
     */
    public Date getModifyTime() {
        return modifyTime;
    }

    /**
     * 修改时间
     * @param modifyTime
     */
    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }
}