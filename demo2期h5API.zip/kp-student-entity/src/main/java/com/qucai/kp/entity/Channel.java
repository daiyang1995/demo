package com.qucai.kp.entity;

import java.util.Date;

public class Channel {
    /**
     * id
     */
    private String id;

    /**
     * 渠道名称
     */
    private String name;

    /**
     * 渠道代码
     */
    private String code;

    /**
     * 渠道机构代码
     */
    private String entCode;

    /**
     * 渠道交易代码
     */
    private String tradeCode;
    
    /**
     * 渠道归属企业名称
     */
    private String ownerEnterpriseName;

    /**
     * ip白名单（多个ip用英文逗号分割）
     */
    private String ipWhiteList;

    /**
     * 备注
     */
    private String remark;

    /**
     * 创建人
     */
    private String creator;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改人
     */
    private String modifier;

    /**
     * 修改时间
     */
    private Date modifyTime;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code == null ? null : code.trim();
    }

    public String getEntCode() {
        return entCode;
    }

    public void setEntCode(String entCode) {
        this.entCode = entCode == null ? null : entCode.trim();
    }

    public String getTradeCode() {
        return tradeCode;
    }

    public void setTradeCode(String tradeCode) {
        this.tradeCode = tradeCode == null ? null : tradeCode.trim();
    }

    public String getOwnerEnterpriseName() {
        return ownerEnterpriseName;
    }

    public void setOwnerEnterpriseName(String ownerEnterpriseName) {
        this.ownerEnterpriseName = ownerEnterpriseName == null ? null : ownerEnterpriseName.trim();
    }

    public String getIpWhiteList() {
        return ipWhiteList;
    }

    public void setIpWhiteList(String ipWhiteList) {
        this.ipWhiteList = ipWhiteList == null ? null : ipWhiteList.trim();
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator == null ? null : creator.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier == null ? null : modifier.trim();
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }
}