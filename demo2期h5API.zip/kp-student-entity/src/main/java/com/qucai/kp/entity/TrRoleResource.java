package com.qucai.kp.entity;

public class TrRoleResource {
    /**
     * 资源id
     */
    private String resourceId;

    /**
     * 角色id
     */
    private String roleId;

    /**
     * 资源id
     * @return 
     */
    public String getResourceId() {
        return resourceId;
    }

    /**
     * 资源id
     * @param resourceId
     */
    public void setResourceId(String resourceId) {
        this.resourceId = resourceId == null ? null : resourceId.trim();
    }

    /**
     * 角色id
     * @return 
     */
    public String getRoleId() {
        return roleId;
    }

    /**
     * 角色id
     * @param roleId
     */
    public void setRoleId(String roleId) {
        this.roleId = roleId == null ? null : roleId.trim();
    }
}