package com.qucai.kp.entity;

/**
 * 系统配置表
 * 
 * @version 1.0 2017-07-22
 */
public class Config {
    /**
     * id
     */
    private String id;

    /**
     * 键
     */
    private String ckey;

    /**
     * 值
     */
    private String cvalue;

    /**
     * 是否有效（0：否；1：是）
     */
    private Integer status;

    /**
     * 备注
     */
    private String remark;

    /**
     * id
     * @return 
     */
    public String getId() {
        return id;
    }

    /**
     * id
     * @param id
     */
    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    /**
     * 键
     * @return 
     */
    public String getCkey() {
        return ckey;
    }

    /**
     * 键
     * @param ckey
     */
    public void setCkey(String ckey) {
        this.ckey = ckey == null ? null : ckey.trim();
    }

    /**
     * 值
     * @return 
     */
    public String getCvalue() {
        return cvalue;
    }

    /**
     * 值
     * @param cvalue
     */
    public void setCvalue(String cvalue) {
        this.cvalue = cvalue == null ? null : cvalue.trim();
    }

    /**
     * 是否有效（0：否；1：是）
     * @return 
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * 是否有效（0：否；1：是）
     * @param status
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     * 备注
     * @return 
     */
    public String getRemark() {
        return remark;
    }

    /**
     * 备注
     * @param remark
     */
    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }
}