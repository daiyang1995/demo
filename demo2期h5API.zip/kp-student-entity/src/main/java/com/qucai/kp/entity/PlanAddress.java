package com.qucai.kp.entity;

import java.util.Date;

/**
 * 方案对应收件地址信息
 * 
 * @version 1.0 2017-07-26
 */
public class PlanAddress {
    /**
     * id
     */
    private String id;

    /**
     * 方案id
     */
    private String planId;

    /**
     * 省
     */
    private String province;

    /**
     * 市
     */
    private String city;

    /**
     * 区
     */
    private String district;

    /**
     * 具体地址
     */
    private String fullAddress;

    /**
     * 联系人
     */
    private String contactor;

    /**
     * 手机
     */
    private String mobile;

    /**
     * 座机
     */
    private String telephone;

    /**
     * 工作时间
     */
    private String workingTime;

    /**
     * 地址类别（0：平台地址；1：客户地址）
     */
    private Integer type;

    /**
     * 是否驻点地址（0：否；1：是）
     */
    private Integer isResident;

    /**
     * 是否快递地址（0：否；1：是）
     */
    private Integer isExpress;

    /**
     * 备注
     */
    private String remark;

    /**
     * 创建人
     */
    private String creator;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改人
     */
    private String modifier;

    /**
     * 修改时间
     */
    private Date modifyTime;
    /**
     * 收件人公司名称
     */
    private String companyName;

    /**
     * id
     * @return 
     */
    public String getId() {
        return id;
    }

    /**
     * id
     * @param id
     */
    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    /**
     * 方案id
     * @return 
     */
    public String getPlanId() {
        return planId;
    }

    /**
     * 方案id
     * @param planId
     */
    public void setPlanId(String planId) {
        this.planId = planId == null ? null : planId.trim();
    }

    /**
     * 省
     * @return 
     */
    public String getProvince() {
        return province;
    }

    /**
     * 省
     * @param province
     */
    public void setProvince(String province) {
        this.province = province == null ? null : province.trim();
    }

    /**
     * 市
     * @return 
     */
    public String getCity() {
        return city;
    }

    /**
     * 市
     * @param city
     */
    public void setCity(String city) {
        this.city = city == null ? null : city.trim();
    }

    /**
     * 区
     * @return 
     */
    public String getDistrict() {
        return district;
    }

    /**
     * 区
     * @param district
     */
    public void setDistrict(String district) {
        this.district = district == null ? null : district.trim();
    }

    /**
     * 具体地址
     * @return 
     */
    public String getFullAddress() {
        return fullAddress;
    }

    /**
     * 具体地址
     * @param fullAddress
     */
    public void setFullAddress(String fullAddress) {
        this.fullAddress = fullAddress == null ? null : fullAddress.trim();
    }

    /**
     * 联系人
     * @return 
     */
    public String getContactor() {
        return contactor;
    }

    /**
     * 联系人
     * @param contactor
     */
    public void setContactor(String contactor) {
        this.contactor = contactor == null ? null : contactor.trim();
    }

    /**
     * 手机
     * @return 
     */
    public String getMobile() {
        return mobile;
    }

    /**
     * 手机
     * @param mobile
     */
    public void setMobile(String mobile) {
        this.mobile = mobile == null ? null : mobile.trim();
    }

    /**
     * 座机
     * @return 
     */
    public String getTelephone() {
        return telephone;
    }

    /**
     * 座机
     * @param telephone
     */
    public void setTelephone(String telephone) {
        this.telephone = telephone == null ? null : telephone.trim();
    }

    /**
     * 工作时间
     * @return 
     */
    public String getWorkingTime() {
        return workingTime;
    }

    /**
     * 工作时间
     * @param workingTime
     */
    public void setWorkingTime(String workingTime) {
        this.workingTime = workingTime == null ? null : workingTime.trim();
    }

    /**
     * 地址类别（0：平台地址；1：客户地址）
     * @return 
     */
    public Integer getType() {
        return type;
    }

    /**
     * 地址类别（0：平台地址；1：客户地址）
     * @param type
     */
    public void setType(Integer type) {
        this.type = type;
    }

    /**
     * 是否驻点地址（0：否；1：是）
     * @return 
     */
    public Integer getIsResident() {
        return isResident;
    }

    /**
     * 是否驻点地址（0：否；1：是）
     * @param isResident
     */
    public void setIsResident(Integer isResident) {
        this.isResident = isResident;
    }

    /**
     * 是否快递地址（0：否；1：是）
     * @return 
     */
    public Integer getIsExpress() {
        return isExpress;
    }

    /**
     * 是否快递地址（0：否；1：是）
     * @param isExpress
     */
    public void setIsExpress(Integer isExpress) {
        this.isExpress = isExpress;
    }

    /**
     * 备注
     * @return 
     */
    public String getRemark() {
        return remark;
    }

    /**
     * 备注
     * @param remark
     */
    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    /**
     * 创建人
     * @return 
     */
    public String getCreator() {
        return creator;
    }

    /**
     * 创建人
     * @param creator
     */
    public void setCreator(String creator) {
        this.creator = creator == null ? null : creator.trim();
    }

    /**
     * 创建时间
     * @return 
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 创建时间
     * @param createTime
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 修改人
     * @return 
     */
    public String getModifier() {
        return modifier;
    }

    /**
     * 修改人
     * @param modifier
     */
    public void setModifier(String modifier) {
        this.modifier = modifier == null ? null : modifier.trim();
    }

    /**
     * 修改时间
     * @return 
     */
    public Date getModifyTime() {
        return modifyTime;
    }

    /**
     * 修改时间
     * @param modifyTime
     */
    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }
    /**
     * 收件人公司名称
     * @return
     */
    public String getCompanyName() {
        return companyName;
    }
    /**
     * 收件人公司名称
     * @param companyName
     */
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }
}