package com.qucai.kp.entity;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 保单表
 * 
 * @version 1.0 2017-08-10
 */
public class Policy {
    /**
     * id
     */
    private String id;

    /**
     * 被保险人id
     */
    private String insuredId;

    /**
     * 被保险人监护人id
     */
    private String guardianId;

    /**
     * 保单归属省
     */
    private String policyProvince;

    /**
     * 保单归属市
     */
    private String policyCity;

    /**
     * 保单号
     */
    private String policyNo;

    /**
     * 方案/计划id
     */
    private String planId;

    /**
     * 分组id
     */
    private String planGroupId;

    /**
     * 起保日期
     */
    private Date startDate;

    /**
     * 结束日期
     */
    private Date endDate;

    /**
     * 购买份数
     */
    private Integer copies;

    /**
     * 保费
     */
    private BigDecimal premium;

    /**
     * 有无社保（0：无社保：1：有社保）
     */
    private String socialInsurance;

    /**
     * 是否有效（0：否；1：是）
     */
    private Integer isEffective;

    /**
     * 保单状态（0：退保；1：在保）
     */
    private String status;

    /**
     * 备注
     */
    private String remark;

    /**
     * 创建人
     */
    private String creator;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改人
     */
    private String modifier;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * id
     * @return 
     */
    public String getId() {
        return id;
    }

    /**
     * id
     * @param id
     */
    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    /**
     * 被保险人id
     * @return 
     */
    public String getInsuredId() {
        return insuredId;
    }

    /**
     * 被保险人id
     * @param insuredId
     */
    public void setInsuredId(String insuredId) {
        this.insuredId = insuredId == null ? null : insuredId.trim();
    }

    /**
     * 被保险人监护人id
     * @return 
     */
    public String getGuardianId() {
        return guardianId;
    }

    /**
     * 被保险人监护人id
     * @param guardianId
     */
    public void setGuardianId(String guardianId) {
        this.guardianId = guardianId == null ? null : guardianId.trim();
    }

    /**
     * 保单归属省
     * @return 
     */
    public String getPolicyProvince() {
        return policyProvince;
    }

    /**
     * 保单归属省
     * @param policyProvince
     */
    public void setPolicyProvince(String policyProvince) {
        this.policyProvince = policyProvince == null ? null : policyProvince.trim();
    }

    /**
     * 保单归属市
     * @return 
     */
    public String getPolicyCity() {
        return policyCity;
    }

    /**
     * 保单归属市
     * @param policyCity
     */
    public void setPolicyCity(String policyCity) {
        this.policyCity = policyCity == null ? null : policyCity.trim();
    }

    /**
     * 保单号
     * @return 
     */
    public String getPolicyNo() {
        return policyNo;
    }

    /**
     * 保单号
     * @param policyNo
     */
    public void setPolicyNo(String policyNo) {
        this.policyNo = policyNo == null ? null : policyNo.trim();
    }

    /**
     * 方案/计划id
     * @return 
     */
    public String getPlanId() {
        return planId;
    }

    /**
     * 方案/计划id
     * @param planId
     */
    public void setPlanId(String planId) {
        this.planId = planId == null ? null : planId.trim();
    }

    /**
     * 分组id
     * @return 
     */
    public String getPlanGroupId() {
        return planGroupId;
    }

    /**
     * 分组id
     * @param planGroupId
     */
    public void setPlanGroupId(String planGroupId) {
        this.planGroupId = planGroupId == null ? null : planGroupId.trim();
    }

    /**
     * 起保日期
     * @return 
     */
    public Date getStartDate() {
        return startDate;
    }

    /**
     * 起保日期
     * @param startDate
     */
    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    /**
     * 结束日期
     * @return 
     */
    public Date getEndDate() {
        return endDate;
    }

    /**
     * 结束日期
     * @param endDate
     */
    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    /**
     * 购买份数
     * @return 
     */
    public Integer getCopies() {
        return copies;
    }

    /**
     * 购买份数
     * @param copies
     */
    public void setCopies(Integer copies) {
        this.copies = copies;
    }

    /**
     * 保费
     * @return 
     */
    public BigDecimal getPremium() {
        return premium;
    }

    /**
     * 保费
     * @param premium
     */
    public void setPremium(BigDecimal premium) {
        this.premium = premium;
    }

    /**
     * 有无社保（0：无社保：1：有社保）
     * @return 
     */
    public String getSocialInsurance() {
        return socialInsurance;
    }

    /**
     * 有无社保（0：无社保：1：有社保）
     * @param socialInsurance
     */
    public void setSocialInsurance(String socialInsurance) {
        this.socialInsurance = socialInsurance == null ? null : socialInsurance.trim();
    }

    /**
     * 是否有效（0：否；1：是）
     * @return 
     */
    public Integer getIsEffective() {
        return isEffective;
    }

    /**
     * 是否有效（0：否；1：是）
     * @param isEffective
     */
    public void setIsEffective(Integer isEffective) {
        this.isEffective = isEffective;
    }

    /**
     * 保单状态（0：退保；1：在保）
     * @return 
     */
    public String getStatus() {
        return status;
    }

    /**
     * 保单状态（0：退保；1：在保）
     * @param status
     */
    public void setStatus(String status) {
        this.status = status == null ? null : status.trim();
    }

    /**
     * 备注
     * @return 
     */
    public String getRemark() {
        return remark;
    }

    /**
     * 备注
     * @param remark
     */
    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    /**
     * 创建人
     * @return 
     */
    public String getCreator() {
        return creator;
    }

    /**
     * 创建人
     * @param creator
     */
    public void setCreator(String creator) {
        this.creator = creator == null ? null : creator.trim();
    }

    /**
     * 创建时间
     * @return 
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 创建时间
     * @param createTime
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 修改人
     * @return 
     */
    public String getModifier() {
        return modifier;
    }

    /**
     * 修改人
     * @param modifier
     */
    public void setModifier(String modifier) {
        this.modifier = modifier == null ? null : modifier.trim();
    }

    /**
     * 修改时间
     * @return 
     */
    public Date getModifyTime() {
        return modifyTime;
    }

    /**
     * 修改时间
     * @param modifyTime
     */
    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }
}