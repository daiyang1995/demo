package com.qucai.kp.entity;

import java.util.Date;

/**
 * 理赔申请表
 * 
 * @version 1.0 2017-07-31
 */
public class ClaimApply {
    /**
     * id
     */
    private String id;

    /**
     * 案件流水号
     */
    private String claimNo;

    /**
     * 保单id
     */
    private String policyId;

    /**
     * 理赔类型
     */
    private String claimType;

    /**
     * 申请人
     */
    private String applier;

    /**
     * 手机号
     */
    private String mobile;

    /**
     * 电子邮箱
     */
    private String email;

    /**
     * 开户行
     */
    private String bankName;

    /**
     * 银行账户名
     */
    private String bankAccount;

    /**
     * 银行卡号
     */
    private String bankCard;

    /**
     * 申请日期
     */
    private Date applyDate;

    /**
     * 理赔是否需要提交物理件（0：否；1：是）
     */
    private Integer isClaimNeedFile;

    /**
     * 状态（0:草稿；10:案件受理：11:辅助理赔案件审核通过：12:辅助理赔案件审核不通过：13:影像审核不通过：20:影像审核：30:影像录入：40:数据发送：50:数据回盘：60:待划账：61:已划账：62:划账失败：63:划账成功：100：已完成；-1:已终止：）
     */
    private Integer status;

    /**
     * 物理件接收状态（-1：无需提交；0：待提交；1：已提交；2：已接收；3：已退回）
     */
    private Integer fileRecieveStatus;

    /**
     * 疾病审核是否通过（1：通过；0：不通过）
     */
    private Integer isDiseaseVerify;

    /**
     * 备注
     */
    private String remark;

    /**
     * 辅助理赔审核备注、影像审核备注
     */
    private String verifyRemark;

    /**
     * 创建人
     */
    private String creator;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改人
     */
    private String modifier;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * id
     * @return 
     */
    public String getId() {
        return id;
    }

    /**
     * id
     * @param id
     */
    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    /**
     * 案件流水号
     * @return 
     */
    public String getClaimNo() {
        return claimNo;
    }

    /**
     * 案件流水号
     * @param claimNo
     */
    public void setClaimNo(String claimNo) {
        this.claimNo = claimNo == null ? null : claimNo.trim();
    }

    /**
     * 保单id
     * @return 
     */
    public String getPolicyId() {
        return policyId;
    }

    /**
     * 保单id
     * @param policyId
     */
    public void setPolicyId(String policyId) {
        this.policyId = policyId == null ? null : policyId.trim();
    }

    /**
     * 理赔类型
     * @return 
     */
    public String getClaimType() {
        return claimType;
    }

    /**
     * 理赔类型
     * @param claimType
     */
    public void setClaimType(String claimType) {
        this.claimType = claimType == null ? null : claimType.trim();
    }

    /**
     * 申请人
     * @return 
     */
    public String getApplier() {
        return applier;
    }

    /**
     * 申请人
     * @param applier
     */
    public void setApplier(String applier) {
        this.applier = applier == null ? null : applier.trim();
    }

    /**
     * 手机号
     * @return 
     */
    public String getMobile() {
        return mobile;
    }

    /**
     * 手机号
     * @param mobile
     */
    public void setMobile(String mobile) {
        this.mobile = mobile == null ? null : mobile.trim();
    }

    /**
     * 电子邮箱
     * @return 
     */
    public String getEmail() {
        return email;
    }

    /**
     * 电子邮箱
     * @param email
     */
    public void setEmail(String email) {
        this.email = email == null ? null : email.trim();
    }

    /**
     * 开户行
     * @return 
     */
    public String getBankName() {
        return bankName;
    }

    /**
     * 开户行
     * @param bankName
     */
    public void setBankName(String bankName) {
        this.bankName = bankName == null ? null : bankName.trim();
    }

    /**
     * 银行账户名
     * @return 
     */
    public String getBankAccount() {
        return bankAccount;
    }

    /**
     * 银行账户名
     * @param bankAccount
     */
    public void setBankAccount(String bankAccount) {
        this.bankAccount = bankAccount == null ? null : bankAccount.trim();
    }

    /**
     * 银行卡号
     * @return 
     */
    public String getBankCard() {
        return bankCard;
    }

    /**
     * 银行卡号
     * @param bankCard
     */
    public void setBankCard(String bankCard) {
        this.bankCard = bankCard == null ? null : bankCard.trim();
    }

    /**
     * 申请日期
     * @return 
     */
    public Date getApplyDate() {
        return applyDate;
    }

    /**
     * 申请日期
     * @param applyDate
     */
    public void setApplyDate(Date applyDate) {
        this.applyDate = applyDate;
    }

    /**
     * 理赔是否需要提交物理件（0：否；1：是）
     * @return 
     */
    public Integer getIsClaimNeedFile() {
        return isClaimNeedFile;
    }

    /**
     * 理赔是否需要提交物理件（0：否；1：是）
     * @param isClaimNeedFile
     */
    public void setIsClaimNeedFile(Integer isClaimNeedFile) {
        this.isClaimNeedFile = isClaimNeedFile;
    }

    /**
     * 状态（0:草稿；10:案件受理：11:辅助理赔案件审核通过：12:辅助理赔案件审核不通过：13:影像审核不通过：20:影像审核：30:影像录入：40:数据发送：50:数据回盘：60:待划账：61:已划账：62:划账失败：63:划账成功：100：已完成；-1:已终止：）
     * @return 
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * 状态（0:草稿；10:案件受理：11:辅助理赔案件审核通过：12:辅助理赔案件审核不通过：13:影像审核不通过：20:影像审核：30:影像录入：40:数据发送：50:数据回盘：60:待划账：61:已划账：62:划账失败：63:划账成功：100：已完成；-1:已终止：）
     * @param status
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     * 物理件接收状态（-1：无需提交；0：待提交；1：已提交；2：已接收；3：已退回）
     * @return 
     */
    public Integer getFileRecieveStatus() {
        return fileRecieveStatus;
    }

    /**
     * 物理件接收状态（-1：无需提交；0：待提交；1：已提交；2：已接收；3：已退回）
     * @param fileRecieveStatus
     */
    public void setFileRecieveStatus(Integer fileRecieveStatus) {
        this.fileRecieveStatus = fileRecieveStatus;
    }

    /**
     * 疾病审核是否通过（1：通过；0：不通过）
     * @return 
     */
    public Integer getIsDiseaseVerify() {
        return isDiseaseVerify;
    }

    /**
     * 疾病审核是否通过（1：通过；0：不通过）
     * @param isDiseaseVerify
     */
    public void setIsDiseaseVerify(Integer isDiseaseVerify) {
        this.isDiseaseVerify = isDiseaseVerify;
    }

    /**
     * 备注
     * @return 
     */
    public String getRemark() {
        return remark;
    }

    /**
     * 备注
     * @param remark
     */
    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    /**
     * 辅助理赔审核备注、影像审核备注
     * @return 
     */
    public String getVerifyRemark() {
        return verifyRemark;
    }

    /**
     * 辅助理赔审核备注、影像审核备注
     * @param verifyRemark
     */
    public void setVerifyRemark(String verifyRemark) {
        this.verifyRemark = verifyRemark == null ? null : verifyRemark.trim();
    }

    /**
     * 创建人
     * @return 
     */
    public String getCreator() {
        return creator;
    }

    /**
     * 创建人
     * @param creator
     */
    public void setCreator(String creator) {
        this.creator = creator == null ? null : creator.trim();
    }

    /**
     * 创建时间
     * @return 
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 创建时间
     * @param createTime
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 修改人
     * @return 
     */
    public String getModifier() {
        return modifier;
    }

    /**
     * 修改人
     * @param modifier
     */
    public void setModifier(String modifier) {
        this.modifier = modifier == null ? null : modifier.trim();
    }

    /**
     * 修改时间
     * @return 
     */
    public Date getModifyTime() {
        return modifyTime;
    }

    /**
     * 修改时间
     * @param modifyTime
     */
    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }
}