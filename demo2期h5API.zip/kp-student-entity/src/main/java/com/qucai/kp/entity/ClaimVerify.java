package com.qucai.kp.entity;

import java.util.Date;

/**
 * 案件任务表
 * 
 * @version 1.0 2017-07-22
 */
public class ClaimVerify {
    /**
     * id
     */
    private String id;

    /**
     * 理赔id
     */
    private String claimApplyId;

    /**
     * 审核人id
     */
    private String verifyId;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 审核认领时间
     */
    private Date verifyTime;

    /**
     * 审核完成时间
     */
    private Date verifyFinishTime;

    /**
     * 录入人id
     */
    private String enterId;

    /**
     * 录入认领时间
     */
    private Date enterTime;

    /**
     * 录入完成时间
     */
    private Date enterFinishTime;

    /**
     * 是否需要录入审核（1：是；0：否）
     */
    private String isEnterVerify;

    /**
     * 录入审核人id
     */
    private String enterVerifyId;

    /**
     * 录入审核认领时间
     */
    private Date enterVerifyTime;

    /**
     * 录入审核完成时间
     */
    private Date enterVerifyFinishTime;

    /**
     * 是否需要理赔审核（1：是；0：否）
     */
    private String isSettlementVerfy;

    /**
     * 理赔审核人id
     */
    private String settlementVerifyId;

    /**
     * 理赔审核认领时间
     */
    private Date settlementVerifyTime;

    /**
     * 理赔审核完成时间
     */
    private Date settlementVerifyFinshTime;

    /**
     * id
     * @return 
     */
    public String getId() {
        return id;
    }

    /**
     * id
     * @param id
     */
    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    /**
     * 理赔id
     * @return 
     */
    public String getClaimApplyId() {
        return claimApplyId;
    }

    /**
     * 理赔id
     * @param claimApplyId
     */
    public void setClaimApplyId(String claimApplyId) {
        this.claimApplyId = claimApplyId == null ? null : claimApplyId.trim();
    }

    /**
     * 审核人id
     * @return 
     */
    public String getVerifyId() {
        return verifyId;
    }

    /**
     * 审核人id
     * @param verifyId
     */
    public void setVerifyId(String verifyId) {
        this.verifyId = verifyId == null ? null : verifyId.trim();
    }

    /**
     * 创建时间
     * @return 
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 创建时间
     * @param createTime
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 审核认领时间
     * @return 
     */
    public Date getVerifyTime() {
        return verifyTime;
    }

    /**
     * 审核认领时间
     * @param verifyTime
     */
    public void setVerifyTime(Date verifyTime) {
        this.verifyTime = verifyTime;
    }

    /**
     * 审核完成时间
     * @return 
     */
    public Date getVerifyFinishTime() {
        return verifyFinishTime;
    }

    /**
     * 审核完成时间
     * @param verifyFinishTime
     */
    public void setVerifyFinishTime(Date verifyFinishTime) {
        this.verifyFinishTime = verifyFinishTime;
    }

    /**
     * 录入人id
     * @return 
     */
    public String getEnterId() {
        return enterId;
    }

    /**
     * 录入人id
     * @param enterId
     */
    public void setEnterId(String enterId) {
        this.enterId = enterId == null ? null : enterId.trim();
    }

    /**
     * 录入认领时间
     * @return 
     */
    public Date getEnterTime() {
        return enterTime;
    }

    /**
     * 录入认领时间
     * @param enterTime
     */
    public void setEnterTime(Date enterTime) {
        this.enterTime = enterTime;
    }

    /**
     * 录入完成时间
     * @return 
     */
    public Date getEnterFinishTime() {
        return enterFinishTime;
    }

    /**
     * 录入完成时间
     * @param enterFinishTime
     */
    public void setEnterFinishTime(Date enterFinishTime) {
        this.enterFinishTime = enterFinishTime;
    }

    /**
     * 是否需要录入审核（1：是；0：否）
     * @return 
     */
    public String getIsEnterVerify() {
        return isEnterVerify;
    }

    /**
     * 是否需要录入审核（1：是；0：否）
     * @param isEnterVerify
     */
    public void setIsEnterVerify(String isEnterVerify) {
        this.isEnterVerify = isEnterVerify == null ? null : isEnterVerify.trim();
    }

    /**
     * 录入审核人id
     * @return 
     */
    public String getEnterVerifyId() {
        return enterVerifyId;
    }

    /**
     * 录入审核人id
     * @param enterVerifyId
     */
    public void setEnterVerifyId(String enterVerifyId) {
        this.enterVerifyId = enterVerifyId == null ? null : enterVerifyId.trim();
    }

    /**
     * 录入审核认领时间
     * @return 
     */
    public Date getEnterVerifyTime() {
        return enterVerifyTime;
    }

    /**
     * 录入审核认领时间
     * @param enterVerifyTime
     */
    public void setEnterVerifyTime(Date enterVerifyTime) {
        this.enterVerifyTime = enterVerifyTime;
    }

    /**
     * 录入审核完成时间
     * @return 
     */
    public Date getEnterVerifyFinishTime() {
        return enterVerifyFinishTime;
    }

    /**
     * 录入审核完成时间
     * @param enterVerifyFinishTime
     */
    public void setEnterVerifyFinishTime(Date enterVerifyFinishTime) {
        this.enterVerifyFinishTime = enterVerifyFinishTime;
    }

    /**
     * 是否需要理赔审核（1：是；0：否）
     * @return 
     */
    public String getIsSettlementVerfy() {
        return isSettlementVerfy;
    }

    /**
     * 是否需要理赔审核（1：是；0：否）
     * @param isSettlementVerfy
     */
    public void setIsSettlementVerfy(String isSettlementVerfy) {
        this.isSettlementVerfy = isSettlementVerfy == null ? null : isSettlementVerfy.trim();
    }

    /**
     * 理赔审核人id
     * @return 
     */
    public String getSettlementVerifyId() {
        return settlementVerifyId;
    }

    /**
     * 理赔审核人id
     * @param settlementVerifyId
     */
    public void setSettlementVerifyId(String settlementVerifyId) {
        this.settlementVerifyId = settlementVerifyId == null ? null : settlementVerifyId.trim();
    }

    /**
     * 理赔审核认领时间
     * @return 
     */
    public Date getSettlementVerifyTime() {
        return settlementVerifyTime;
    }

    /**
     * 理赔审核认领时间
     * @param settlementVerifyTime
     */
    public void setSettlementVerifyTime(Date settlementVerifyTime) {
        this.settlementVerifyTime = settlementVerifyTime;
    }

    /**
     * 理赔审核完成时间
     * @return 
     */
    public Date getSettlementVerifyFinshTime() {
        return settlementVerifyFinshTime;
    }

    /**
     * 理赔审核完成时间
     * @param settlementVerifyFinshTime
     */
    public void setSettlementVerifyFinshTime(Date settlementVerifyFinshTime) {
        this.settlementVerifyFinshTime = settlementVerifyFinshTime;
    }
}