package com.qucai.kp.entity;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 理赔录入结果信息表
 * 
 * @version 1.0 2017-08-04
 */
public class ClaimSettlement {
    /**
     * id
     */
    private String id;

    /**
     * 理赔录入信息表id
     */
    private String claimReceiptId;

    /**
     * 免赔额
     */
    private BigDecimal deductionMoney;

    /**
     * 扣除金额
     */
    private BigDecimal refusedMoney;

    /**
     * 赔付金额
     */
    private BigDecimal approvedMoney;

    /**
     * 使用住院津贴金额
     */
    private BigDecimal usedAllowMoney;

    /**
     * 使用住院津贴天数
     */
    private Integer usedAllowDays;

    /**
     * 理赔类型
     */
    private String settlementType;

    /**
     * 备注
     */
    private String remark;

    /**
     * 创建人
     */
    private String creator;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改人
     */
    private String modifier;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * id
     * @return 
     */
    public String getId() {
        return id;
    }

    /**
     * id
     * @param id
     */
    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    /**
     * 理赔录入信息表id
     * @return 
     */
    public String getClaimReceiptId() {
        return claimReceiptId;
    }

    /**
     * 理赔录入信息表id
     * @param claimReceiptId
     */
    public void setClaimReceiptId(String claimReceiptId) {
        this.claimReceiptId = claimReceiptId == null ? null : claimReceiptId.trim();
    }

    /**
     * 免赔额
     * @return 
     */
    public BigDecimal getDeductionMoney() {
        return deductionMoney;
    }

    /**
     * 免赔额
     * @param deductionMoney
     */
    public void setDeductionMoney(BigDecimal deductionMoney) {
        this.deductionMoney = deductionMoney;
    }

    /**
     * 扣除金额
     * @return 
     */
    public BigDecimal getRefusedMoney() {
        return refusedMoney;
    }

    /**
     * 扣除金额
     * @param refusedMoney
     */
    public void setRefusedMoney(BigDecimal refusedMoney) {
        this.refusedMoney = refusedMoney;
    }

    /**
     * 赔付金额
     * @return 
     */
    public BigDecimal getApprovedMoney() {
        return approvedMoney;
    }

    /**
     * 赔付金额
     * @param approvedMoney
     */
    public void setApprovedMoney(BigDecimal approvedMoney) {
        this.approvedMoney = approvedMoney;
    }

    /**
     * 使用住院津贴金额
     * @return 
     */
    public BigDecimal getUsedAllowMoney() {
        return usedAllowMoney;
    }

    /**
     * 使用住院津贴金额
     * @param usedAllowMoney
     */
    public void setUsedAllowMoney(BigDecimal usedAllowMoney) {
        this.usedAllowMoney = usedAllowMoney;
    }

    /**
     * 使用住院津贴天数
     * @return 
     */
    public Integer getUsedAllowDays() {
        return usedAllowDays;
    }

    /**
     * 使用住院津贴天数
     * @param usedAllowDays
     */
    public void setUsedAllowDays(Integer usedAllowDays) {
        this.usedAllowDays = usedAllowDays;
    }

    /**
     * 理赔类型
     * @return 
     */
    public String getSettlementType() {
        return settlementType;
    }

    /**
     * 理赔类型
     * @param settlementType
     */
    public void setSettlementType(String settlementType) {
        this.settlementType = settlementType == null ? null : settlementType.trim();
    }

    /**
     * 备注
     * @return 
     */
    public String getRemark() {
        return remark;
    }

    /**
     * 备注
     * @param remark
     */
    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    /**
     * 创建人
     * @return 
     */
    public String getCreator() {
        return creator;
    }

    /**
     * 创建人
     * @param creator
     */
    public void setCreator(String creator) {
        this.creator = creator == null ? null : creator.trim();
    }

    /**
     * 创建时间
     * @return 
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 创建时间
     * @param createTime
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 修改人
     * @return 
     */
    public String getModifier() {
        return modifier;
    }

    /**
     * 修改人
     * @param modifier
     */
    public void setModifier(String modifier) {
        this.modifier = modifier == null ? null : modifier.trim();
    }

    /**
     * 修改时间
     * @return 
     */
    public Date getModifyTime() {
        return modifyTime;
    }

    /**
     * 修改时间
     * @param modifyTime
     */
    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }
}