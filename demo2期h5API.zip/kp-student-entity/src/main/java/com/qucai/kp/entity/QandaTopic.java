package com.qucai.kp.entity;

import java.util.Date;

/**
 * 咨询主题表
 * 
 * @version 1.0 2017-07-22
 */
public class QandaTopic {
    /**
     * id
     */
    private String id;

    /**
     * 类型
     */
    private String type;

    /**
     * 子项
     */
    private String subitem;

    /**
     * 业务信息url
     */
    private String bizUrl;

    /**
     * 手机号
     */
    private String mobile;

    /**
     * 电子邮箱
     */
    private String email;

    /**
     * 标题
     */
    private String title;

    /**
     * 状态（0：待反馈；1：已答复）
     */
    private Integer status;

    /**
     * 创建人
     */
    private String creator;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * id
     * @return 
     */
    public String getId() {
        return id;
    }

    /**
     * id
     * @param id
     */
    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    /**
     * 类型
     * @return 
     */
    public String getType() {
        return type;
    }

    /**
     * 类型
     * @param type
     */
    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    /**
     * 子项
     * @return 
     */
    public String getSubitem() {
        return subitem;
    }

    /**
     * 子项
     * @param subitem
     */
    public void setSubitem(String subitem) {
        this.subitem = subitem == null ? null : subitem.trim();
    }

    /**
     * 业务信息url
     * @return 
     */
    public String getBizUrl() {
        return bizUrl;
    }

    /**
     * 业务信息url
     * @param bizUrl
     */
    public void setBizUrl(String bizUrl) {
        this.bizUrl = bizUrl == null ? null : bizUrl.trim();
    }

    /**
     * 手机号
     * @return 
     */
    public String getMobile() {
        return mobile;
    }

    /**
     * 手机号
     * @param mobile
     */
    public void setMobile(String mobile) {
        this.mobile = mobile == null ? null : mobile.trim();
    }

    /**
     * 电子邮箱
     * @return 
     */
    public String getEmail() {
        return email;
    }

    /**
     * 电子邮箱
     * @param email
     */
    public void setEmail(String email) {
        this.email = email == null ? null : email.trim();
    }

    /**
     * 标题
     * @return 
     */
    public String getTitle() {
        return title;
    }

    /**
     * 标题
     * @param title
     */
    public void setTitle(String title) {
        this.title = title == null ? null : title.trim();
    }

    /**
     * 状态（0：待反馈；1：已答复）
     * @return 
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * 状态（0：待反馈；1：已答复）
     * @param status
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     * 创建人
     * @return 
     */
    public String getCreator() {
        return creator;
    }

    /**
     * 创建人
     * @param creator
     */
    public void setCreator(String creator) {
        this.creator = creator == null ? null : creator.trim();
    }

    /**
     * 创建时间
     * @return 
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 创建时间
     * @param createTime
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
}