package com.qucai.kp.entity;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 方案分组险种表
 * 
 * @version 1.0 2017-08-09
 */
public class PlanGroupClass {
    /**
     * id
     */
    private String id;

    /**
     * 方案组ID
     */
    private String planGroupId;

    /**
     * 险种名称
     */
    private String name;

    /**
     * 险种代码
     */
    private String code;

    /**
     * 理赔类型（1：理赔；2：辅助理赔）
     */
    private String type;

    /**
     * 险种额度
     */
    private BigDecimal coverage;

    /**
     * 险种他方额度
     */
    private BigDecimal coverageSchool;

    /**
     * 每日津贴金额
     */
    private BigDecimal allowFee;

    /**
     * 最高津贴天数
     */
    private Integer allowDays;

    /**
     * 触发险种名称
     */
    private String triggerName;

    /**
     * 免赔类型（1：年；2：次）
     */
    private String deductionType;

    /**
     * 免赔金额
     */
    private BigDecimal deductionFee;

    /**
     * 固定比例类型（使用社保身份（0：无社保；1：有社保））
     */
    private String rateType;

    /**
     * 固定比例
     */
    private Integer rate;

    /**
     * 阶段比例类型（使用社保身份（0：无社保；1：有社保））
     */
    private String rateStageType;

    /**
     * 阶段比例id
     */
    private String rateStageId;

    /**
     * 创建人
     */
    private String creator;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改人
     */
    private String modifier;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * id
     * @return 
     */
    public String getId() {
        return id;
    }

    /**
     * id
     * @param id
     */
    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    /**
     * 方案组ID
     * @return 
     */
    public String getPlanGroupId() {
        return planGroupId;
    }

    /**
     * 方案组ID
     * @param planGroupId
     */
    public void setPlanGroupId(String planGroupId) {
        this.planGroupId = planGroupId == null ? null : planGroupId.trim();
    }

    /**
     * 险种名称
     * @return 
     */
    public String getName() {
        return name;
    }

    /**
     * 险种名称
     * @param name
     */
    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    /**
     * 险种代码
     * @return 
     */
    public String getCode() {
        return code;
    }

    /**
     * 险种代码
     * @param code
     */
    public void setCode(String code) {
        this.code = code == null ? null : code.trim();
    }

    /**
     * 理赔类型（1：理赔；2：辅助理赔）
     * @return 
     */
    public String getType() {
        return type;
    }

    /**
     * 理赔类型（1：理赔；2：辅助理赔）
     * @param type
     */
    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    /**
     * 险种额度
     * @return 
     */
    public BigDecimal getCoverage() {
        return coverage;
    }

    /**
     * 险种额度
     * @param coverage
     */
    public void setCoverage(BigDecimal coverage) {
        this.coverage = coverage;
    }

    /**
     * 险种他方额度
     * @return 
     */
    public BigDecimal getCoverageSchool() {
        return coverageSchool;
    }

    /**
     * 险种他方额度
     * @param coverageSchool
     */
    public void setCoverageSchool(BigDecimal coverageSchool) {
        this.coverageSchool = coverageSchool;
    }

    /**
     * 每日津贴金额
     * @return 
     */
    public BigDecimal getAllowFee() {
        return allowFee;
    }

    /**
     * 每日津贴金额
     * @param allowFee
     */
    public void setAllowFee(BigDecimal allowFee) {
        this.allowFee = allowFee;
    }

    /**
     * 最高津贴天数
     * @return 
     */
    public Integer getAllowDays() {
        return allowDays;
    }

    /**
     * 最高津贴天数
     * @param allowDays
     */
    public void setAllowDays(Integer allowDays) {
        this.allowDays = allowDays;
    }

    /**
     * 触发险种名称
     * @return 
     */
    public String getTriggerName() {
        return triggerName;
    }

    /**
     * 触发险种名称
     * @param triggerName
     */
    public void setTriggerName(String triggerName) {
        this.triggerName = triggerName == null ? null : triggerName.trim();
    }

    /**
     * 免赔类型（1：年；2：次）
     * @return 
     */
    public String getDeductionType() {
        return deductionType;
    }

    /**
     * 免赔类型（1：年；2：次）
     * @param deductionType
     */
    public void setDeductionType(String deductionType) {
        this.deductionType = deductionType == null ? null : deductionType.trim();
    }

    /**
     * 免赔金额
     * @return 
     */
    public BigDecimal getDeductionFee() {
        return deductionFee;
    }

    /**
     * 免赔金额
     * @param deductionFee
     */
    public void setDeductionFee(BigDecimal deductionFee) {
        this.deductionFee = deductionFee;
    }

    /**
     * 固定比例类型（使用社保身份（0：无社保；1：有社保））
     * @return 
     */
    public String getRateType() {
        return rateType;
    }

    /**
     * 固定比例类型（使用社保身份（0：无社保；1：有社保））
     * @param rateType
     */
    public void setRateType(String rateType) {
        this.rateType = rateType == null ? null : rateType.trim();
    }

    /**
     * 固定比例
     * @return 
     */
    public Integer getRate() {
        return rate;
    }

    /**
     * 固定比例
     * @param rate
     */
    public void setRate(Integer rate) {
        this.rate = rate;
    }

    /**
     * 阶段比例类型（使用社保身份（0：无社保；1：有社保））
     * @return 
     */
    public String getRateStageType() {
        return rateStageType;
    }

    /**
     * 阶段比例类型（使用社保身份（0：无社保；1：有社保））
     * @param rateStageType
     */
    public void setRateStageType(String rateStageType) {
        this.rateStageType = rateStageType == null ? null : rateStageType.trim();
    }

    /**
     * 阶段比例id
     * @return 
     */
    public String getRateStageId() {
        return rateStageId;
    }

    /**
     * 阶段比例id
     * @param rateStageId
     */
    public void setRateStageId(String rateStageId) {
        this.rateStageId = rateStageId == null ? null : rateStageId.trim();
    }

    /**
     * 创建人
     * @return 
     */
    public String getCreator() {
        return creator;
    }

    /**
     * 创建人
     * @param creator
     */
    public void setCreator(String creator) {
        this.creator = creator == null ? null : creator.trim();
    }

    /**
     * 创建时间
     * @return 
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 创建时间
     * @param createTime
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 修改人
     * @return 
     */
    public String getModifier() {
        return modifier;
    }

    /**
     * 修改人
     * @param modifier
     */
    public void setModifier(String modifier) {
        this.modifier = modifier == null ? null : modifier.trim();
    }

    /**
     * 修改时间
     * @return 
     */
    public Date getModifyTime() {
        return modifyTime;
    }

    /**
     * 修改时间
     * @param modifyTime
     */
    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }
}